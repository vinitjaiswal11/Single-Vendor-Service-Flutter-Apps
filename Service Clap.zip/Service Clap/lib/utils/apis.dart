class Apis{
  static const String BASE_URL = "https://myservice.thedigitalkranti.com/api/v1/";
  static const String API_KEY = "0k8kws08ggw4okgskcw4gc0w4cs448gc88g4g0sc";
  static const String PAYTM_KEY = "rzp_test_gxXdHsXsGPtTvp";
//  static const String API_KEY = "0k8kws08ggw4okgskcw4gc0w4cs448gc88g4g0sc";

  static const String ACCEPT = "Accept";
  static const String HEADER_TYPE = "application/json";
}