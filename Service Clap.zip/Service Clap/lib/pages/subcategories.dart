import 'dart:io';

import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:service_app/utils/apis.dart';
import 'package:shimmer/shimmer.dart';
import 'package:service_app/animators/navianimator.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:service_app/pages/vendors.dart';

class SubcatsPage extends StatefulWidget{
  final catid;
  final catname;
  SubcatsPage({Key key, this.catid,this.catname})
: super(key: key);
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return SubcatsLoader();
  }

}

class SubcatsLoader extends State<SubcatsPage>{
  List subcats = [];
  var subcatslen = 0;
  var loading = true;
  getSubcats() async{
    var url = Apis.BASE_URL + "Categories/getSubCategory";
    var data = {"category_id":widget.catid};
    var res = await apiPostRequest(url,data);
    print(json.decode(res));
    setState(() {
      subcats = json.decode(res)['records'];
      subcatslen = subcats.length;
      loading = false;
    });
  }

  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  @override
  void initState(){
    super.initState();
    getSubcats();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color.fromRGBO(243, 244, 251, 1),
        body: new Stack(
          children: <Widget>[
            new Container(
              child: new CustomScrollView(
                slivers: <Widget>[
                  SliverAppBar(
                    title: Text(
                      widget.catname,
                      style: TextStyle(
                          color: Colors.black
                      ),
                    ),
                    backgroundColor: Colors.white,
                    leading: IconButton(
                      onPressed: (){
                        Navigator.pop(context);
                      },
                      icon: Icon(
                        FontAwesomeIcons.arrowLeft,
                        color: Colors.black,
                      ),
                    ),
                    elevation: 1,
                    pinned: true,
                  ),
                  SliverPadding(
                    padding: EdgeInsets.only(
                        top: 10
                    ),
                    sliver: _lists(),
                  ),
//                  SliverPadding(
//                    padding: EdgeInsets.only(top: 40, bottom: 100),
//                    sliver: SliverToBoxAdapter(
//                      child: new Column(
//                        children: <Widget>[
//                          new Container(
//                            width: 45,
//                            height: 35,
//
//                            decoration: BoxDecoration(
//                              borderRadius: BorderRadius.only(
//                                  topRight: Radius.circular(10),
//                                  bottomLeft: Radius.circular(10)
//                              ),
//                              image: DecorationImage(
//                                  image: AssetImage("assets/image/logo.png"),
//                                  fit: BoxFit.cover,
//                                  colorFilter: ColorFilter.mode(Colors.black, BlendMode.dstIn)
//                              ),
//                            ),
//                          ),
//                          new Container(
//                            padding: EdgeInsets.only(
//                                top: 10
//                            ),
//                            child: new Center(
//                              child: new Text(
//                                "Serve On Door",
//                                style: TextStyle(
//                                    color: Color.fromRGBO(67, 91, 111, 0.4),
//                                    fontSize: 16,
//                                    fontFamily: "opensan",
//                                    fontWeight: FontWeight.w700
//                                ),
//                              ),
//                            ),
//                          ),
//                        ],
//                      ),
//                    ),
//                  ),
                ],
              ),
            ),
            Positioned(
                top: MediaQuery.of(context).size.height/10,
                bottom: 0,
                left: 0,
                right: 0,
                child: loading == true
                    ? Container(
                  padding: EdgeInsets.only(
                    left: 20,
                    right: 20,
                  ),
//                  color: Colors.white,
                  child: Shimmer.fromColors(
                    baseColor: Colors.grey,
                    highlightColor: Colors.white,
                    child: new Column(
                      children: <Widget>[
                        Container(
                            padding: EdgeInsets.only(
                                top: 20
                            ),
                            child: new Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                new Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.black.withOpacity(0.3),
                                ),
                                new Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width/1.4,
                                  color: Colors.black.withOpacity(0.3),
                                )
                              ],
                            )
                        ),
                        Container(
                            padding: EdgeInsets.only(
                                top: 20
                            ),
                            child: new Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                new Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.black.withOpacity(0.3),
                                ),
                                new Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width/1.4,
                                  color: Colors.black.withOpacity(0.3),
                                )
                              ],
                            )
                        ),
                        Container(
                            padding: EdgeInsets.only(
                                top: 20
                            ),
                            child: new Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                new Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.black.withOpacity(0.3),
                                ),
                                new Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width/1.4,
                                  color: Colors.black.withOpacity(0.3),
                                )
                              ],
                            )
                        )
                      ],
                    ),
                  ),
                )
                    : Container()),
          ],
        ),
      ),
    );
  }


//  Container(
//  child: Container(
//  decoration: BoxDecoration(
//  color: Colors.white,
//  border: Border(
//  bottom: BorderSide(
//  color: Colors.black12
//  )
//  )
//  ),
//  padding: EdgeInsets.only(
//  top: 10,
//  bottom: 10
//  ),
//  child: Column(
//  children: [
//  new ListTile(
//
//  // onTap: (){
//  //   var name = cats[index]['category'];
//  //   var id = cats[index]['cat_id'];
//  //   var image = cats[index]['cimage'];
//  //   showdet(name, id, image);
//  // },
//  contentPadding: index == 0? EdgeInsets.only(
//  top: 20,
//  left: 18
//  ):null,
//  leading: new Container(
//  width: 50,
//  padding: EdgeInsets.only(
//  top: 10
//  ),
//  height: MediaQuery.of(context).size.height,
//  child: new Align(
//  alignment: Alignment.topRight,
//  child: Image(
//  image: NetworkImage(subcats[index]['subcategory_image']),
//  ),
//  ),
//  ),
//  title: Text(subcats[index]['subcategory_name'],
//  style: TextStyle(
//  fontFamily: "opensan",
//  color: Color.fromRGBO(67, 91, 111, 1),
//  fontWeight: FontWeight.bold
//  ),
//  ),
//
//  )
//  ],
//  ),
//
//
//  )
//  )

  _lists() {
    return SliverList(
      delegate: SliverChildBuilderDelegate(
            (BuildContext context, int index) {
          return Container(
            padding: EdgeInsets.only(
              bottom: 10
            ),
            child: Container(
              height : 100,
              color: Colors.white,
              child: new Stack(
                children: [
                  Positioned(
                    left : 0,
                    top : 0,
                    child: Container(
                      height : 200,
                      width : 150,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                            colors: [Colors.white,Colors.white]
                        ),
                      ),
                      child: Container(
                        height : 200,
                        width : 160,
                        decoration: BoxDecoration(

                          image: DecorationImage(
                            image: NetworkImage(subcats[index]['subcategory_image']),
                            alignment: Alignment.centerLeft,
                            fit: BoxFit.cover
                          ),
                        ),
                        child: Container(
                          height : 200,
                          width : 160,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.white.withOpacity(0.0),Colors.white],
                              tileMode: TileMode.repeated
                            )
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
//                    color: Colors.white10,
                    height: MediaQuery.of(context).size.height,
                    child: Center(
                      child: ListTile(
                        onTap: (){
                          Navigator.push(context, EnterExitRoute(enterPage: VendorsPage(subcats[index]['subcategory_id'])));
                        },
                        contentPadding: EdgeInsets.only(
                            left: 130
                        ),
                        title: Text(
                          subcats[index]['subcategory_name'],
                          style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.bold
                          ),
                        ),
                        subtitle: Row(
                          children: [
                            InkWell(
                              onTap: (){
                                Navigator.push(context, EnterExitRoute(enterPage: VendorsPage(subcats[index]['subcategory_id'])));
                              },
//                              color: Colors.black54,
                              child: Container(
//                                paddin,
//                                decoration: BoxDecoration(
//                                  gradient: LinearGradient(
//                                    colors : [Colors.white,Colors.white]
//                                  )
//                                ),
                                child: Row(
                                  children: [
                                    Text(
                                      "View Partners",
                                      style: TextStyle(
                                          color: Colors.blue,
                                        fontWeight: FontWeight.bold
                                      ),
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(
                                        left : 5
                                      ),
                                      child: Icon(
                                        Icons.chevron_right,
                                        color: Colors.blue,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          );
        },
        /// Set childCount to limit no.of items
        childCount: subcatslen,
      ),
    );
  }

}