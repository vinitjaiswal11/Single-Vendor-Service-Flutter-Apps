import 'package:flutter/material.dart';
import 'package:service_app/pages/orderdetails.dart';
import 'package:shimmer/shimmer.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:service_app/animators/navianimator.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:service_app/utils/apis.dart';
import 'dart:io';
import 'package:shimmer/shimmer.dart';
import 'package:intl/intl.dart';
import 'dart:core';
// import 'package:flutter_svg/flutter_svg.dart';

class OrderPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return OrderLoader();
  }
}

class OrderLoader extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return OrderView();
  }
}

class OrderView extends State<OrderLoader> {
  var orderlen = 0;
  List orders = [];
  List partners = [];
  var loading = false;
  var data = true;

  Future _orders() async{
    setState((){
      loading = true;
    });
    var sp = await SharedPreferences.getInstance();
    var userid = sp.getString("userid");
    var url = Apis.BASE_URL +"orders";
    var datas = {
      "user_id" : userid
    };
    print(datas);
    var res = await apiPostRequest(url,datas);
    if(json.decode(res)['status'] == "1"){
      setState((){
        loading = false;
        data = true;
        orders = json.decode(res)['orders_data'];
        orderlen = orders.length;
      });
    }
    if(json.decode(res)['status'] == "0"){
      setState((){
        loading = false;
        data = false;
      });
    }
    print(res);
  }

  
  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  @override
  void initState(){
    super.initState();
    _orders();
  }
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color.fromRGBO(236, 239, 241, 1),
        body: new Stack(
          children: <Widget>[
            new CustomScrollView(
              slivers: <Widget>[
                SliverAppBar(
                  title: Text("Bookings",
                      style: TextStyle(
                          color: Colors.black,
                          fontFamily: "opensan",
                          fontWeight: FontWeight.bold)),
                  backgroundColor: Colors.white,
                  elevation: 1,
                  actions: <Widget>[
                    IconButton(
                      onPressed: (){},
                      icon: Icon(
                        FontAwesomeIcons.history,
                        color: Colors.black,
                      ),
                    )
                  ],
                  floating: false,
                  pinned: true,
                ),
                _listReviews()
              ],
            ),
            Positioned(
                top: MediaQuery.of(context).size.height/10,
                bottom: 0,
                left: 0,
                right: 0,
                child: loading == true
                    ? Container(
                  padding: EdgeInsets.only(
                    left: 20,
                    right: 20,
                  ),
//                  color: Colors.white,
                  child: Shimmer.fromColors(
                    baseColor: Colors.grey,
                    highlightColor: Colors.white,
                    child: new Column(
                      children: <Widget>[
                        Container(
                            padding: EdgeInsets.only(
                                top: 20
                            ),
                            child: new Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                new Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.black.withOpacity(0.3),
                                ),
                                new Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width/1.4,
                                  color: Colors.black.withOpacity(0.3),
                                )
                              ],
                            )
                        ),
                        Container(
                            padding: EdgeInsets.only(
                                top: 20
                            ),
                            child: new Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                new Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.black.withOpacity(0.3),
                                ),
                                new Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width/1.4,
                                  color: Colors.black.withOpacity(0.3),
                                )
                              ],
                            )
                        ),
                        Container(
                            padding: EdgeInsets.only(
                                top: 20
                            ),
                            child: new Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                new Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.black.withOpacity(0.3),
                                ),
                                new Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width/1.4,
                                  color: Colors.black.withOpacity(0.3),
                                )
                              ],
                            )
                        )
                      ],
                    ),
                  ),
                )
                    : Container())
            ,Positioned(
              top : 60,
              bottom: 0,
              left : 0,
              right : 0,
              child: data == false?Container(
                color: Colors.white,
                child: Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // child : SvgPicture.asset(
                        //   'assets/image/no-order.svg',
                        //   height: 250,
                        // )
                      ),
                      Container(
                        padding: EdgeInsets.only(
                          top:10
                        ),
                        child : Text(
                          "You do not have any orders"
                        )
                      ),
                      Container(
                        padding: EdgeInsets.only(
                          top:10
                        ),
                        child : FlatButton(
                          onPressed: (){},
                          child: Text(
                            "Order Now",
                            style: TextStyle(
                              color: Colors.white
                            ),  
                          ),
                          color: Colors.black87,
                        )
                      )
                    ],
                  ),
                ),
              ):Container(),
            )
          ],
        ),
      ),
    );
  }

  _listReviews() {
    return SliverList(
      delegate: SliverChildBuilderDelegate(
            (BuildContext context, int index) {
          return new Container(
            padding: EdgeInsets.only(
              // left: 20,
              // right: 20,
              top: 10,
            ),
            child: new Column(
              children: <Widget>[
                orders[index]['vendor_name'] != null?new Material(
                    child: new Container(
                      // height: 80,
                      padding: EdgeInsets.only(top: 10, bottom: 10),
                      decoration: BoxDecoration(
                          color: Colors.white,
//                          border: Border(
//                              bottom: BorderSide(
//                                  color: Colors.black45, width: 0.4))
                                  ),
                      child: SizedBox(
                        child: ListTile(
                          leading: new Container(
                              width: 60.0,
                              height: 60.0,
                              child: CircleAvatar(
                                child: Icon(
                                    FontAwesomeIcons.user
                                ),
                              ),
//                              decoration: new BoxDecoration(
//                                  shape: BoxShape.rectangle,
//                                  image: new DecorationImage(
//                                      fit: BoxFit.fill,
//                                      image: new NetworkImage(
//                                          "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTp0bwUxYW5jRkv9nDhaXCGyAo6BekDenATQUZgeFu0A8g_-n66")))
                          ),
                          title: Text(
                            orders[index]['vendor_name'],
                            style: TextStyle(
                                fontFamily: "opensan",
                                fontSize: 17,
                                fontWeight: FontWeight.bold),
                          ),
                          subtitle: new Padding(
                            padding: EdgeInsets.only(top: 5),
                            child: new Row(
                              children: <Widget>[
                                new Container(
                                    height: 25,
                                    padding: EdgeInsets.only(
                                        top: 2,
                                        bottom: 2,
                                        left: 5,
                                        right: 5),
                                    decoration: BoxDecoration(
                                        color: Color.fromRGBO(
                                            0, 150, 136, 0.2)),
                                    child: Center(
                                      child: new Row(
                                        children: <Widget>[
                                          new Icon(
                                            FontAwesomeIcons.solidStar,
                                            size: 13,
                                            color: Color.fromRGBO(
                                                0, 150, 136, 1),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(
                                                left: 5),
                                            child: Text(
                                              "4.5",
                                              style: TextStyle(
                                                  fontFamily: "opensan",
                                                  color: Color.fromRGBO(
                                                      0, 150, 136, 1),
                                                  fontWeight:
                                                  FontWeight.bold),
                                            ),
                                          )
                                        ],
                                      ),
                                    )),
                                new Padding(
                                  padding: EdgeInsets.only(left: 10),
                                  child: Text(
                                    "120 Rattings",
                                    style: TextStyle(
                                        fontFamily: "opensan",
                                        color: Colors.black54,
                                        fontSize: 12),
                                  ),
                                )
                              ],
                            ),
                          ),
                          trailing: SizedBox(
                            width: 40,
                            height: 40,
                            child: Material(
                              borderRadius: BorderRadius.all(
                                  const Radius.circular(120)),
                              color: Color.fromRGBO(79, 195, 247, 0.4),
                              child: InkWell(
                                onTap: () async {
                                  var number =
                                  "8178616459"; //set the number here
                                  bool res =
                                  await FlutterPhoneDirectCaller
                                      .callNumber(number);
                                },
                                splashColor:
                                Color.fromRGBO(79, 195, 247, 0.7),
                                borderRadius: BorderRadius.all(
                                    const Radius.circular(120)),
                                child: Center(
                                  child: Icon(
                                    FontAwesomeIcons.phoneAlt,
                                    color:
                                    Color.fromRGBO(30, 136, 229, 1),
                                    size: 20,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ) ,
                      ),
                    ),
                  ):Container(),
                new Material(
                  color: Colors.white,
                  child : InkWell(
                    onTap: (){
                      Navigator.push(context, FadeRoute(page: OrderdetailPage(bookingid: orders[index]['order_id'],index : index.toString())));
                    },
                    child: Container(
                  // height: 100,
                  // color: Colors.white,
                  child: new Column(
                    children: <Widget>[
                      new Container(
                        padding: EdgeInsets.only(
                            top: 10, left: 15, bottom: 10),
                        child: new Row(
                          mainAxisAlignment:
                          MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text(
                              orders[index]['category_name'] != null?orders[index]['category_name']:"",
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: "opensan"),
                            ),
                            Material(
                              child: new Container(
                                    width: 100,
                                    height: 30,
                                    child: Stack(
                                      children: <Widget>[
                                        Shimmer.fromColors(
                                          baseColor: Colors.black,
                                          highlightColor: Colors.grey,
                                          child: new Container(
                                            decoration: BoxDecoration(
                                              color: Colors.black,
                                              // borderRadius: BorderRadius.all(
                                              //   const Radius.circular(3)
                                              // )
                                            ),
                                            padding: EdgeInsets.only(
                                                left: 10,
                                                right: 10,
                                                top: 5,
                                                bottom: 5),
                                          ),
                                        ),
                                        Positioned(
                                            child: new Center(
                                              child: new Text(
                                                "Booked",
                                                style: TextStyle(
                                                    fontSize: 16,
                                                    fontWeight:
                                                    FontWeight.bold,
                                                    color: Colors.white,
                                                    fontFamily: "opensan"),
                                                textAlign: TextAlign.center,
                                              ),
                                            ))
                                      ],
                                    ),
                                  ),
                            )
                          ],
                        ),
                      ),
                      new Container(
                        padding: EdgeInsets.only(left: 15),
                        child: new Row(
                          children: <Widget>[
                            new Padding(
                              padding: EdgeInsets.only(right: 5),
                              child: new Icon(
                                FontAwesomeIcons.clock,
                                size: 15,
                              ),
                            ),
                            new Text(
                              getdates(orders[index]['delivery_date'].toString())+" "+getdays(orders[index]['delivery_date'].toString())+" at "+orders[index]['delivery_time'].toString(),
                              // getdates(orders[index]['order_date'].toString())+" "+getdays(orders[index]['order_date'].toString())+" at "+ getTime(orders[index]['order_date'].toString()),
                              style: TextStyle(fontFamily: "opensan"),
                            )
                          ],
                        ),
                      ),
                      new Container(
                        padding: EdgeInsets.only(
                          top: 20,
                        ),
                      ),
                      new Container(
                        decoration: BoxDecoration(
                            border: Border(
                              top: BorderSide(
                                color: Colors.grey,
                                width: 0.5,
                              ),
                            )),
                        child: new Row(
                          mainAxisAlignment:
                          MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Flexible(
                              child: new Row(
                                children: <Widget>[
                                  new Container(
                                    padding: EdgeInsets.only(
                                        right: 5, left: 10),
                                    // child: Icon(
                                    //   FontAwesomeIcons.locationArrow,
                                    //   size: 15,
                                    // ),
                                  ),
                                  Flexible(
                                    child: new Text(
                                      "",
                                      style:
                                      TextStyle(
                                        fontFamily: "opensan",

                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  )
                                ],
                              ),
                            ),
                            new Material(
                              color: Colors.white,
                              child: InkWell(
                                // onTap: () {
                                //   Navigator.push(
                                //       context,
                                //       FadeRoute(
                                //           page: OrderdetailPage(category: ordes[index]['category'],index: index.toString(),bookingid: ordes[index]['booking_id'],addres: ordes[index]['location'],)));
                                // },
                                child: new Container(
                                  decoration: BoxDecoration(
                                      border: Border(
                                        left: BorderSide(
                                          color: Colors.grey,
                                          width: 0.5,
                                        ),
                                      )),
                                  padding: EdgeInsets.only(
                                      top: 10,
                                      bottom: 10,
                                      left: 20,
                                      right: 20),
                                  child: new Center(
                                    child: Text(
                                      "View Detail",
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontFamily: "opensan"),
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),  
                  )
                )
              ],
            ),
          );
      },
        childCount: orderlen,
      ),
    );
  }

  getdates(String text) {
    var string = text;
//    var now = new DateTime.now();
    var formatter = new DateFormat('E');
    String formatted = formatter.format(DateTime.parse(string));
    return formatted.toUpperCase();
  }

  getdays(String text) {
    var string = text;
//    var now = new DateTime.now();
    var formatter = new DateFormat('d MMM');
    String formatted = formatter.format(DateTime.parse(string));
    return formatted.toUpperCase();
  }

  getTime(String text){
    var string = text;
    var formatter = new DateFormat().add_jm();
    String formatted = formatter.format(DateTime.parse(string));
    return formatted;
  }

}
