import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_html/flutter_html.dart';

class ItemsLoader extends StatefulWidget{
  final productname,productimage,productprice,productmrp,description;
  ItemsLoader(this.productname,this.productimage,this.productprice,this.productmrp,this.description);
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return ItemsView();
  }

}

class ItemsView extends State<ItemsLoader>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text("Description",
          style: TextStyle(color: Colors.black,
          fontSize: 15),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: IconThemeData(
          color: Colors.black
        ),
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            child: new Container(
              //height: 60,
              padding: EdgeInsets.only(
                top: 0
              ),
              child: Column(
                children: [
                  Container(
                    // padding: EdgeInsets.only(
                    //     top: 0
                    // ),
                    height: 200,
                    // width: 400,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      image: DecorationImage(
                        image: NetworkImage(widget.productimage),
                        fit: BoxFit.cover,
                      ),
                    ),

                  ),
               new Container(

                 decoration: BoxDecoration(
                   color: Colors.white,
                 ),
                 child: new ListTile(
                   // contentPadding: EdgeInsets.only(
                   //     left: 95,
                   //     right: 20
                   // ),
                   title: Padding(
                     padding: EdgeInsets.only(
                       top: 0,
                     ),
                     child: Text(
                       widget.productname,
                       style: TextStyle(
                           fontSize: 11,
                           fontWeight: FontWeight.w600,
                           fontFamily: "opensan"
                       ),
                     ),
                   ),

                   subtitle: new Row(
                     mainAxisAlignment:
                     MainAxisAlignment
                         .spaceBetween,
                     children: <Widget>[
                       Align(
                         alignment: Alignment
                             .centerLeft,
                         child: new Row(
                           children: <Widget>[
                             Padding(
                               padding:
                               EdgeInsets.only(
                                   top: 5),
                               child: new Container(
                                   child:
                                   new Container(
                                     padding:
                                     EdgeInsets.only(
                                       left: 10,
                                       right: 10,
                                       top: 2,
                                       bottom: 2,
                                     ),
                                     color:
                                     Colors.red[50],
                                     child: Text(
                                       "\u20B9 " +widget.productprice.toString()
                                           .toString(),
                                       style: TextStyle(
                                           fontFamily:
                                           "opensan",
                                           color: Colors
                                               .black,
                                           fontWeight:
                                           FontWeight
                                               .bold),
                                     ),
                                   )),
                             ),
                             Padding(
                               padding:
                               EdgeInsets.only(
                                   top: 5),
                               child: new Container(
                                   child:
                                   new Container(
                                     padding:
                                     EdgeInsets.only(
                                       left: 10,
                                       right: 10,
                                       top: 2,
                                       bottom: 2,
                                     ),
                                     child: Text(
                                       "\u20B9" +widget.productmrp.toString(),
                                       style: TextStyle(
                                           fontFamily:
                                           "opensan",
                                           color: Colors
                                               .black.withOpacity(0.7),
                                           decoration: TextDecoration.lineThrough
                                       ),
                                     ),
                                   )),),
                           ],
                         ),
                       ),
                       SizedBox(
                           width: 70,
                           height: 30,
                           child:Material(
                             borderRadius:
                             BorderRadius.all(
                                 Radius
                                     .circular(
                                     5)),
                             child: InkWell(
                               borderRadius:
                               BorderRadius
                                   .all(Radius
                                   .circular(
                                   5)),
                               onTap: () {
                                 //  var subid =
                                 //     package[item]
                                 //           ['subid'];
                                 //   var packageid =
                                 //       package[item][
                                 //           'packageid'];
                                 //    var price =
                                 //        package[item]
                                 //            ['price'];
                                 //    addTocart(
                                 //        item,
                                 //        subid,
                                 //        packageid,
                                 //        price);
                               },
                              // child:
                               // new Container(
                               //   decoration: BoxDecoration(
                               //       border: Border.all(
                               //           color: Color.fromRGBO(
                               //               79,
                               //               155,
                               //               247,
                               //               1),
                               //           width: 1),
                               //       borderRadius:
                               //       BorderRadius.all(
                               //           Radius.circular(
                               //               5))),
                               //   child: new Row(
                               //     mainAxisAlignment:
                               //     MainAxisAlignment
                               //         .spaceBetween,
                               //     children: <
                               //         Widget>[
                               //       Expanded(
                               //         child: Center(
                               //           child: new Container(
                               //             // padding: EdgeInsets
                               //             //     .only(
                               //             //     left:
                               //             //     10),
                               //             child: Text( " ADD",
                               //               style: TextStyle(
                               //                   fontFamily:
                               //                   "opensan",
                               //                   fontWeight: FontWeight
                               //                       .w600,
                               //                   fontSize: 12,
                               //                   color: Color.fromRGBO(
                               //                       79,
                               //                       155,
                               //                       247,
                               //                       1)),
                               //             ),
                               //           ),
                               //         ),
                               //       ),
                               //       new Container(
                               //         width: 25,
                               //         height: MediaQuery.of(
                               //             context)
                               //             .size
                               //             .height,
                               //         decoration: BoxDecoration(
                               //             color: Colors
                               //                 .blue
                               //                 .withOpacity(
                               //                 0.1),
                               //             borderRadius:
                               //             BorderRadius.all(Radius.circular(5))),
                               //         child:
                               //         Center(
                               //           child:
                               //           Text(
                               //             "+",
                               //             style: TextStyle(
                               //                 fontFamily:
                               //                 "opensan",
                               //
                               //                 fontWeight: FontWeight
                               //                     .bold,
                               //                 color: Color.fromRGBO(
                               //                     79,
                               //                     155,
                               //                     247,
                               //                     1),
                               //                 fontSize:
                               //                 15),
                               //           ),
                               //         ),
                               //       )
                               //     ],
                               //   ),
                               // ),
                             ),
                           )

                       )
                     ],
                   ),
                 ),
               ),
               new Container(

                padding: EdgeInsets.only(
                   top: 10),
                child: Container(
                  color: Colors.white,
                  padding: EdgeInsets.only(
                      top: 10,
                    left: 20,
                    right: 20,
                    bottom: 10
                  ),
                  // child: Text(
                  //   widget.description,
                  //   style: TextStyle(fontSize: 11,
                  //       color: Colors.black45
                  //       ,fontWeight: FontWeight.w400),
                  //   maxLines: 3,
                  // ),
                  child: Html(
                    data : widget.description,
//                    style: TextStyle(fontSize: 11,
//                        color: Colors.black45
//                        ,fontWeight: FontWeight.w400),
//                    maxLines: 3,
                    defaultTextStyle: TextStyle(fontSize: 11,
                      color: Colors.black45
                      ,fontWeight: FontWeight.w400,
                    ),

                  ),
                ),
               )
                ],
              ),


            ),


          )
        ],
      ),
      //bottomNavigationBar: _showPay(),






    );
  }
  _showPay() {
    //if (shows == true) {
      return new Container(
        height: 60,
        padding: EdgeInsets.only(top: 5, left: 5, right: 5, bottom: 5),
        color: Colors.white,
        child: FlatButton(
          splashColor: Colors.blueAccent,
          color: Colors.black,

          onPressed: () {
            // setState(() => loading = true);
           // if(loading == true){

           // }
            //else{
            //  Navigator.push(context, EnterExitRoute(enterPage: FinalbillPage()));
          //  }
          },
          child:new Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              new Row(
                children: <Widget>[
                  new Container(
                    padding: EdgeInsets.only(
                        right: 10
                    ),
                    child: new CircleAvatar(
                      radius: 15,
                      backgroundColor: Colors.red,
                      child: new Text(
                        "1",
                        style: TextStyle(
                            fontFamily: "opensan",
                            fontWeight: FontWeight.bold,
                            color: Colors.white
                        ),
                      ),
                    ),
                  ),
                  new Container(
                    child: Text("Items",
                    //  qty != '1'?"Items":"Item",
                      style: TextStyle(
                          color : Colors.white
                      ),
                    ),
                  )
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  new Padding(
                    padding: EdgeInsets.only(
                        right: 10
                    ),
                    child: Text(
                      "Continue",
                      style: TextStyle(
                          color: Colors.white, fontFamily: "opensan", fontSize: 15),
                    ),
                  ),
                  new Icon(FontAwesomeIcons.arrowRight, color: Colors.white)
                ],
              )
            ],
          ),
        ),
      );
    }
    //else if (shows == false) {
    //  return null;
   // }
  }




