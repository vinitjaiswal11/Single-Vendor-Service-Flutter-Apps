import 'package:flutter/material.dart';
import 'package:service_app/pages/location.dart';
import 'package:service_app/animators/navianimator.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

import 'dart:io';
import 'package:google_maps_webservice/places.dart';
import 'package:geocoder/geocoder.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:service_app/pages/categories.dart';
import 'dart:ui' as ui;
import 'package:service_app/pages/categorydetail.dart';
import 'package:service_app/pages/subcategories.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
//import 'package:flare_flutter/flare_actor.dart';
import 'package:shimmer/shimmer.dart';
import 'package:service_app/pages/locations.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:service_app/utils/apis.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return HomepageLoader();
  }
}

class HomepageLoader extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return HomepageView();
  }
}

class HomepageView extends State<HomepageLoader> {
  var location = TextEditingController();
  Future getCurrentLocation() async {
    Position position = await Geolocator()
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    var lattitude = position.latitude;
    var longitude = position.longitude;
    final coordinates = new Coordinates(lattitude, longitude);
    var addresses =
    await Geocoder.local.findAddressesFromCoordinates(coordinates);
    var first = addresses.first;
    print("${first.featureName} : ${first.addressLine}");
    setState(() {
      locations = first.addressLine.trimRight();
    });
  }

  var kGoogleApiKey = "AIzaSyAYnX4A3PFsD3me_DOR8mQ_Z8sqLkT_Xr8";

  var locations = "What is your location";
  Future _getLocations() async {
    Prediction p = await PlacesAutocomplete.show(
        context: context, apiKey: kGoogleApiKey, mode: Mode.overlay);
    setState(() {
      locations = p.description.toString();
    });
    // Navigator.pop(context);
  }

  void _handleTap() async {
    Prediction p = await _getLocations();

    if (p == null) return;

    print(p.description);
  }

  Future showdet(name, id, image) async {
    Navigator.push(
        context,
        EnterExitRoute(
            enterPage: CategorydetailPage(vendorid: 1,)));
  }

  Future getLocation() async {
    var sp = await SharedPreferences.getInstance();
    var loc = sp.getString("location");
    print(loc);
    setState(() {
      locations = loc;
    });
  }

  bool loading = false;
  List cats = [];
  List offers = [];
  List mostused = [];
  List demanded = [];
  var catslength = 2;
  var offrslen = 0;
  var mostusedlen = 0;
  var demandlen = 0;
  Future getCategory() async {
    var url = Apis.BASE_URL + "Categories";
    var data = {};
    var res = await apiRequest(url);
//    print(json.decode(res)['records']);
    setState(() {
      cats = json.decode(res)['records'];
      catslength = cats.length;
      loading = false;
    });
  }


  List slider = [];
  var sliderlen = 0;

  Future getSlider() async{
    setState(() {
      loading = true;
    });
    var url = Apis.BASE_URL + "HomeScreen";
    // var data = {};
    var res = await apiRequest(url);
    print(json.decode(res));
    setState(() {
    //  cats = json.decode(res)['records'];
    //  catslength = cats.length;
      slider = json.decode(res)['slider1'];
      sliderlen = slider.length;
      loading = false;
    });
    getCategory();
  }


  List usedservice = [];
  var usedservicelen = 0;

  getMostusedServices() async{
    var url = Apis.BASE_URL + "HomeScreen/getHomeCategory";
    var data = {"limit":"4"};
    var res = await apiPostRequest(url,data);
    print(json.decode(res));
    setState(() {
//      cats = json.decode(res)['records'];
//      catslength = cats.length;
      usedservice = json.decode(res)['records'];
      usedservicelen = usedservice.length;
//      loading = false;
    });
  }

  Future<String> apiRequest(String url) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.getUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
//    request.add(utf8.encode(json.encode(jsonMap)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  @override
  void initState() {
    super.initState();
    getCurrentLocation();
    getSlider();
    getMostusedServices();
    // getLocation();
    // getCategory();
  }

  @override
  Widget build(BuildContext context) {

    var size = MediaQuery.of(context).size;

    /*24 is for notification bar on Android*/
    final double itemHeight = (size.height - kToolbarHeight - 24) / 4;
    final double itemWidth = size.width / 2;

    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color.fromRGBO(243, 244, 251, 1),
        body: Stack(
          children: <Widget>[
            new Container(
              child: loading == true ?CustomScrollView(
                slivers: <Widget>[
                  SliverAppBar(
                        title: new Container(
                          height: 50,
                          child: Material(
                              color: Colors.black,
                              child:InkWell(
                                onTap: (){
                                  // Navigator.push(context, FadeRoute(page: LocationPage()))
                                  //  .then((value) {
                                  //   // getLocation();
                                  // });
                                },
                                child:  new Row(
                                  children: <Widget>[
                                    new Container(
                                      child: Icon(
                                        Icons.location_on,
                                        color: Colors.white,
                                      ),
                                    ),
                                    new Flexible(
                                      flex: 1,
                                      child: Container(
                                        padding: EdgeInsets.only(
                                            left: 5
                                        ),
                                        child: Text(
                                          locations,
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 17,
                                            fontFamily: "opensan",
                                          ),
                                          maxLines: 1,
                                          textAlign: TextAlign.left,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              )
                          ),
                        ),
                        backgroundColor: Colors.black,
                        elevation: 5,
                        floating: false,
                        pinned: true,
                        actions: <Widget>[
                          IconButton(
                            onPressed: () {
                              getCurrentLocation();
                            },
                            icon: Icon(
                              Icons.my_location,
                              color: Colors.white,
                            ),
                          )
                        ],
                        bottom: new PreferredSize(
                          preferredSize: Size.fromHeight(4),
                          child: new Container(
                            padding: EdgeInsets.only(
                                left: 10, right: 10, bottom: 10,top: 0),
                            child: new Container(
                              decoration: BoxDecoration(
                                  color: Color.fromRGBO(244, 244, 244, 1),
                                  borderRadius:
                                  BorderRadius.all(Radius.circular(5)),
                                  border: Border.all(color: Colors.black12)),
                              child: Hero(
                                tag: 'search',
                                child: Material(
                                  borderRadius:
                                  BorderRadius.all(Radius.circular(5)),
                                  child: new TextField(
                                    decoration: InputDecoration(
                                      prefixIcon: Icon(
                                        FontAwesomeIcons.search,
                                        size: 14,
                                      ),
                                      hintText: "Search Services",
                                      border: InputBorder.none,
                                      contentPadding: EdgeInsets.only(left: 20,top: 12),
                                      hintStyle: TextStyle(
                                          fontFamily: "opensan",
                                          fontWeight: FontWeight.w600,
                                          color: Colors.black26),
                                    ),
                                    readOnly: true,
                                    onTap: () {
                                      Navigator.push(context,
                                          FadeRoute(page: LoactionsPage()));
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        expandedHeight: 120,
                      ),
                  SliverFillRemaining(
                    child: Container(
                        padding: EdgeInsets.only(left: 20, right: 20, top: 10),
                        color: Colors.white,
                        child: Shimmer.fromColors(
                          baseColor: Colors.white,
                          highlightColor: Colors.blueGrey,
                          
                          child: new Column(
                            children: <Widget>[
                              Container(
                                padding: EdgeInsets.only(top: 20),
                                child: new Container(
                                  height: 150,
                                  color: Colors.black.withOpacity(0.3),
                                ),
                              ),
                              new Container(
                                  padding: EdgeInsets.only(top: 20),
                                  child: new Column(
                                    children: <Widget>[
                                      new Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: <Widget>[
                                          new Flexible(
                                              flex: 1,
                                              child: new Container(
                                                height: 100,
                                                width: 100,
                                                color: Colors.black
                                                    .withOpacity(0.2),
                                              )),
                                          new Flexible(
                                              flex: 1,
                                              child: new Container(
                                                height: 100,
                                                width: 100,
                                                color: Colors.black
                                                    .withOpacity(0.2),
                                              )),
                                          new Flexible(
                                              flex: 1,
                                              child: new Container(
                                                height: 100,
                                                width: 100,
                                                color: Colors.black
                                                    .withOpacity(0.2),
                                              ))
                                        ],
                                      ),
                                      new Container(
                                        padding: EdgeInsets.only(top: 20),
                                        child: new Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: <Widget>[
                                            new Flexible(
                                                flex: 1,
                                                child: new Container(
                                                  height: 100,
                                                  width: 100,
                                                  color: Colors.black
                                                      .withOpacity(0.2),
                                                )),
                                            new Flexible(
                                                flex: 1,
                                                child: new Container(
                                                  height: 100,
                                                  width: 100,
                                                  color: Colors.black
                                                      .withOpacity(0.2),
                                                )),
                                            new Flexible(
                                                flex: 1,
                                                child: new Container(
                                                  height: 100,
                                                  width: 100,
                                                  color: Colors.black
                                                      .withOpacity(0.2),
                                                ))
                                          ],
                                        ),
                                      )
                                    ],
                                  ))
                            ],
                          ),
                        ),
                      ),
                  )
                ],
              ) : new Container(),
            ),
            new Center(
              child: new RefreshIndicator(
                child: Container(
                  child: loading == false  ? CustomScrollView(
                    slivers: <Widget>[
                      SliverAppBar(
                        title: new Container(
                          height: 50,
                          child: Material(
                              color: Colors.black,
                              child:InkWell(
                                onTap: (){
                                  Navigator.push(context, FadeRoute(page: LocationPage()))
                                   .then((value) {
                                    getLocation();
                                  });
                                },
                                child:  new Row(
                                  children: <Widget>[
                                    new Container(
                                      child: Icon(
                                        Icons.location_on,
                                        color: Colors.white,
                                      ),
                                    ),
                                    new Flexible(
                                      flex: 1,
                                      child: Container(
                                        padding: EdgeInsets.only(
                                            left: 5
                                        ),
                                        child: Text(
                                          locations,
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 17,
                                            fontFamily: "opensan",
                                          ),
                                          maxLines: 1,
                                          textAlign: TextAlign.left,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              )
                          ),
                        ),
                        backgroundColor: Colors.black,
                        elevation: 5,
                        floating: false,
                        pinned: true,
                        actions: <Widget>[
                          IconButton(
                            onPressed: () {
                              getCurrentLocation();
                            },
                            icon: Icon(
                              Icons.my_location,
                              color: Colors.white,
                            ),
                          )
                        ],
                        bottom: new PreferredSize(
                          preferredSize: Size.fromHeight(4),
                          child: new Container(
                            padding: EdgeInsets.only(
                                left: 10, right: 10, bottom: 10,top: 0),
                            child: new Container(
                              decoration: BoxDecoration(
                                  color: Color.fromRGBO(244, 244, 244, 1),
                                  borderRadius:
                                  BorderRadius.all(Radius.circular(5)),
                                  border: Border.all(color: Colors.black12)),
                              child: Hero(
                                tag: 'search',
                                child: Material(
                                  borderRadius:
                                  BorderRadius.all(Radius.circular(5)),
                                  child: new TextField(
                                    decoration: InputDecoration(
                                      prefixIcon: Icon(
                                        FontAwesomeIcons.search,
                                        size: 14,
                                      ),
                                      hintText: "Search Services",
                                      border: InputBorder.none,
                                      contentPadding: EdgeInsets.only(left: 20,top: 12),
                                      hintStyle: TextStyle(
                                          fontFamily: "opensan",
                                          fontWeight: FontWeight.w600,
                                          color: Colors.black26),
                                    ),
                                    readOnly: true,
                                    onTap: () {
                                      Navigator.push(context,
                                          FadeRoute(page: LoactionsPage()));
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        expandedHeight: 120,
                      ),
                      
                      SliverToBoxAdapter(
                        child: new Container(
                          color: Colors.white,

                          padding: EdgeInsets.only(
                              bottom: 10,
                              top: 10,
//                              left : 10,
//                            right : 10
                          ),
                          child: CarouselSlider(
                            height: 200.0,
                            initialPage: 0,
                            autoPlay: true,
                            aspectRatio: 2,
                            autoPlayAnimationDuration: Duration(seconds: 1),
                            autoPlayInterval: Duration(seconds: 1000),
                            viewportFraction: 0.9,
                            enableInfiniteScroll: false,
//                            scrollDirection: Axis.vertical,
                            enlargeCenterPage: false,
                            items: slider.map((i) {
                              return Builder(
                                builder: (BuildContext context) {
                                  return InkWell(
                                    borderRadius:
                                    BorderRadius.all(Radius.circular(3)),
                                    // onTap: (){
                                    //   var name = i['category'];
                                    //   var id = i['cat_id'];
                                    //   var image = i['cimage'];
                                    //   showdet(name, id, image);
                                    // },
                                    child: Container(
                                      width: MediaQuery.of(context).size.width,
                                      margin: EdgeInsets.symmetric(horizontal: 5.0),
                                      decoration: BoxDecoration(
                                          color: Colors.amber,
                                            image: DecorationImage(
                                                image: NetworkImage(i['slider_image']),
                                                fit: BoxFit.cover,
                                            ),
                                          borderRadius:
                                          BorderRadius.all(Radius.circular(3))),
//                                      child: Image(
//                                        image: NetworkImage(
//                                            "http://serveondoor.com/servernew/uploads/category/"+i['image']),
//                                        height: 200,
//                                        width: 10,
//                                      ),
                                    ),
                                  );

                                },
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                      // SliverToBoxAdapter(
                      //   child: new Container(
                      //     padding: EdgeInsets.only(
                      //         top: 20, right: 20, left: 20, bottom: 20),
                      //     decoration: BoxDecoration(
                      //       gradient: RadialGradient(
                      //         colors: [
                      //           Color.fromRGBO(2, 119, 189, 1),
                      //           Colors.black,
                      //           Colors.black,
                      //           Color.fromRGBO(2, 119, 189, 1)
                      //         ],
                      //         stops: [0.5, 0.5, 1, 2],
                      //         center: Alignment(0.1, 1),
                      //         focal: Alignment(-1, 0.6),
                      //         focalRadius: 2,
                      //       ),
                      //     ),
                      //     child: new Column(
                      //       children: <Widget>[
                      //         Material(
                      //           color: Colors.black.withOpacity(0.7),
                      //           borderRadius: BorderRadius.all(Radius.circular(10)),
                      //           child: InkWell(
                      //             borderRadius:
                      //             BorderRadius.all(Radius.circular(10)),
                      //             onTap: () {
                      //               Navigator.push(context,
                      //                   EnterExitRoute(enterPage: CategoryPage()));
                      //             },
                      //             child: new Container(
                      //               height: 140,
                      //               decoration: BoxDecoration(
                      //                   borderRadius:
                      //                   BorderRadius.all(Radius.circular(10))),
                      //               child: Stack(
                      //                 children: <Widget>[
                      //                   new Positioned(
                      //                     child: new Image(
                      //                       image: AssetImage(
                      //                           "assets/image/services.png"),
                      //                       width: 190,
                      //                     ),
                      //                     right: -10,
                      //                     top: -8,
                      //                   ),
                      //                   new Positioned(
                      //                     child: new Text(
                      //                       "All Services",
                      //                       style: TextStyle(
                      //                         color: Colors.white,
                      //                         fontWeight: FontWeight.bold,
                      //                         fontSize: 25,
                      //                         fontFamily: "opensan",
                      //                       ),
                      //                     ),
                      //                     left: 20,
                      //                     top: 30,
                      //                   ),
                      //                   new Positioned(
                      //                       child: Container(
                      //                         height: 100,
                      //                         width: 100,
                      //                         padding: EdgeInsets.only(
                      //                           right: 190,
                      //                           left: 50,
                      //                         ),
                      //                         child: new Row(
                      //                           mainAxisAlignment:
                      //                           MainAxisAlignment.spaceBetween,
                      //                           children: <Widget>[
                      //                             new Container(
                      //                               child: Text(
                      //                                 "View All",
                      //                                 style: TextStyle(
                      //                                     color: Colors.white,
                      //                                     fontFamily: "opensan",
                      //                                     fontSize: 18),
                      //                               ),
                      //                             ),
                      //                             new Container(
                      //                               child: new Icon(
                      //                                 FontAwesomeIcons.arrowRight,
                      //                                 color: Colors.white,
                      //                                 size: 15,
                      //                               ),
                      //                             )
                      //                           ],
                      //                         ),
                      //                       ),
                      //                       bottom: 0,
                      //                       width:
                      //                       MediaQuery.of(context).size.width /
                      //                           1.1)
                      //                 ],
                      //               ),
                      //             ),
                      //           ),
                      //         )
                      //       ],
                      //     ),
                      //   ),
                      // ),
                     SliverPadding(
                       padding: EdgeInsets.only(bottom: 20, top: 10),
                       sliver: new SliverGrid(
                         gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                           crossAxisCount: 3,
                           mainAxisSpacing: 1.0,
                           crossAxisSpacing: 1.0,
                         ),
                         delegate: SliverChildBuilderDelegate(
                               (BuildContext context, int index) {
                             return index > 7
                                 ? Material(
                               color: Colors.white,
                               child: InkWell(
                                 splashColor: Colors.amberAccent,
//                                 focusColor: Color.fromRGBO(79, 195, 247, 1),
//                                 highlightColor: Colors.amberAccent,
                                 onTap: () {
                                    Navigator.push(context, EnterExitRoute(enterPage: CategoryPage()));
                                 },
                                 child: Container(
                                   alignment: Alignment.center,
                                   child: new Container(
                                     height : 250,
                                     child: new Center(
                                         child : new Column(
                                           mainAxisAlignment: MainAxisAlignment.center,
                                           crossAxisAlignment: CrossAxisAlignment.center,
                                           children: <Widget>[
                                             new Container(
                                                 height: 80,
                                                 child: new Center(
                                                   child: Icon(
                                                     Icons.chevron_right,
                                                     size : 60
                                                   ),
                                                 )),
                                             new Expanded(
                                               // color: Colors.black,
                                               child: Text(
                                                 "More",
                                                 style: TextStyle(
                                                   color: Colors.black,
                                                   fontFamily: "opensan",
                                                 ),
                                                 textAlign: TextAlign.center,
                                               ),
                                             )

                                           ],

                                         )
                                     ),
                                   ),

                                 ),

                               ),
                             )
                                 :Material(
                               color: Colors.white,
                               child: InkWell(
                                 splashColor: Colors.amberAccent,
                                 focusColor: Colors.white,
//                                 highlightColor: Colors.white,
                                 onTap: () {
                                   // var name = cats[index]['category'];
                                   // var id = cats[index]['cat_id'];
                                   // var image = cats[index]['cimage'];
                                   // showdet(name, id, image);
                                   Navigator.push(context, EnterExitRoute(enterPage: SubcatsPage(catid: cats[index]['category_id'],catname: cats[index]['category_name'],)));
                                 },
                                 child: Container(
                                   alignment: Alignment.center,
                                   child: new Container(
                                     height : 250,
                                     child: new Center(
                                         child : new Column(
                                           mainAxisAlignment: MainAxisAlignment.center,
                                           crossAxisAlignment: CrossAxisAlignment.center,
                                           children: <Widget>[
                                             new Container(
                                                 height: 80,
                                                 child: new Center(
                                                   child: Image(
                                                     image: NetworkImage(cats[index]['category_image']),
                                                     height: 40,
                                                     width: 40,
                                                   ),
                                                 )),
                                             new Expanded(
                                               // color: Colors.black,
                                               child: Text(
                                                 cats[index]['category_name'],
                                                 style: TextStyle(
                                                   color: Colors.black,
                                                   fontFamily: "opensan",
                                                 ),
                                                 textAlign: TextAlign.center,
                                               ),
                                             )

                                           ],

                                         )
                                     ),
                                   ),

                                 ),

                               ),
                             );

                           },
                           childCount: catslength > 8?9:catslength,
                         ),
                       ),
                     ),
                      SliverPadding(
                          padding: EdgeInsets.only(
                            top: 20,
                          ),
                          sliver: SliverToBoxAdapter(
                            child: new Container(
                              padding: EdgeInsets.only(
                                  right: 18, left: 18, top: 20, bottom: 20),
                              decoration: BoxDecoration(color: Colors.white),
                              child: new Column(
                                children: <Widget>[
                                  new Container(
                                    child: new Center(
                                      child: Text(
                                        "Most Used Services",
                                        style: TextStyle(
                                            color: Color.fromRGBO(67, 91, 111, 1),
                                            fontSize: 22,
                                            fontFamily: "opensan",
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                  ),
                                 // new Container(
                                 //   padding: EdgeInsets.only(top: 10),
                                 //   child: new Center(
                                 //     child: Container(
                                 //       padding: EdgeInsets.only(
                                 //           left: 10, right: 10, top: 7, bottom: 7),
                                 //       decoration: BoxDecoration(
                                 //           color: Color.fromRGBO(67, 91, 111, 1),
                                 //           borderRadius: BorderRadius.all(
                                 //               Radius.circular(3))),
                                 //       child: Text(
                                 //         "Bathroom cleaning",
                                 //         style: TextStyle(
                                 //             color: Colors.white,
                                 //             fontSize: 16,
                                 //             fontFamily: "opensan",
                                 //             fontWeight: FontWeight.bold),
                                 //       ),
                                 //     ),
                                 //   ),
                                 // )
                                ],
                              ),
                            ),
                          )),
                      SliverPadding(
                        padding: EdgeInsets.only(top: 0),
                        sliver: new SliverGrid(
                          gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                            maxCrossAxisExtent: 300.0,
                            mainAxisSpacing: 0.0,
                            crossAxisSpacing: 0.0,
                            childAspectRatio: 1.1,
                          ),
                          delegate: SliverChildBuilderDelegate(
                                (BuildContext context, int index) {
                              return Material(
                                color: Colors.white,
                                child: InkWell(
                                  splashColor: Colors.black.withOpacity(0.2),
                                  focusColor: Colors.white,
                                  highlightColor: Colors.white,
                                  onTap: () {
                                    // var name = mostused[index]['category'];
                                    // var id = mostused[index]['cat_id'];
                                    // var image = mostused[index]['cimage'];
                                    // showdet(name, id, image);
                                    Navigator.push(context, EnterExitRoute(enterPage: SubcatsPage(catid: cats[index]['category_id'],catname: cats[index]['category_name'],)));
                                  },
                                  child: Container(
                                    padding: EdgeInsets.only(left: 20, right: 20),
                                    alignment: Alignment.center,
                                    child: new Center(
                                      child: new Container(
                                        child: new Column(
                                          mainAxisAlignment:
                                          MainAxisAlignment.center,
                                          children: <Widget>[
                                            new Center(
                                              child: new Container(
                                                  height: 120,
                                                  decoration: BoxDecoration(
                                                    color: Colors.black,
                                                    borderRadius: BorderRadius.all(
                                                        Radius.circular(7)),
                                                    image: DecorationImage(
                                                        image: NetworkImage(usedservice[index]['category_image']),
                                                        fit: BoxFit.cover),
                                                  )),
                                            ),
                                            new Center(
                                              child: Padding(
                                                  padding: EdgeInsets.only(top: 15),
                                                  child: Align(
                                                      alignment: Alignment.center,
                                                      child: Text(
                                                        usedservice[index]['category_name'],
                                                        style: TextStyle(
                                                          color: Colors.black,
                                                          fontFamily: "opensan",
                                                        ),
                                                        textAlign: TextAlign.center,
                                                      ))),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                            childCount: usedservicelen,
                          ),
                        ),
                      ),
                      SliverPadding(
                          padding: EdgeInsets.only(bottom: 20),
                          sliver: SliverToBoxAdapter(
                            child: new Container(
                              padding: EdgeInsets.only(
                                  right: 18, left: 18, top: 20, bottom: 10),
                              decoration: BoxDecoration(color: Colors.white),
                              child: new ButtonBar(
                                children: <Widget>[
                                  new FlatButton(
                                    onPressed: () {
                                      Navigator.push(context,
                                          EnterExitRoute(enterPage: CategoryPage()));
                                    },
                                    child: new Row(
                                      children: <Widget>[
                                        Padding(
                                          padding: EdgeInsets.only(
                                              top: 13,
                                              bottom: 13,
                                              left: 10,
                                              right: 10),
                                          child: Text(
                                            "View all Services",
                                            style: TextStyle(
                                              fontSize: 17,
                                              color:
                                              Color.fromRGBO(79, 195, 247, 1),
                                              fontFamily: "opensan",
                                            ),
                                          ),
                                        ),
                                        new Icon(FontAwesomeIcons.arrowRight,
                                            color: Color.fromRGBO(79, 195, 247, 1))
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            ),
                          )),
                      SliverPadding(
                          padding: EdgeInsets.only(top: 20),
                          sliver: SliverToBoxAdapter(
                            child: new Container(
                              padding: EdgeInsets.only(
                                  right: 18, left: 18, top: 20, bottom: 10),
                              decoration: BoxDecoration(color: Colors.white),
                              child: new Column(
                                children: <Widget>[
                                  new Container(
                                    child: new Center(
                                      child: Text(
                                        "DEMANDED ",
                                        style: TextStyle(
                                            color: Color.fromRGBO(67, 91, 111, 1),
                                            fontSize: 22,
                                            fontFamily: "opensan",
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )),
                      SliverToBoxAdapter(
                        child: new Container(
                          color: Colors.white,
                          padding: EdgeInsets.only(bottom: 10, top: 10),
                          child: CarouselSlider(
                            height: 200.0,
                            initialPage: 0,
                            items: ["assets/image/bac.png","assets/image/digger.png","assets/image/screwdrive.png"].map((i) {
                              return Builder(
                                builder: (BuildContext context) {
                                  return Container(
                                    width: MediaQuery.of(context).size.width,
                                    margin: EdgeInsets.symmetric(horizontal: 5.0),
                                    decoration: BoxDecoration(
                                        color: Colors.blueAccent.withOpacity(0.2),
                                        image: DecorationImage(
                                            image: AssetImage(i),
                                            fit: BoxFit.cover),
                                        borderRadius:
                                        BorderRadius.all(Radius.circular(10))),
//                                     child: Text(i['cimage'], style: TextStyle(fontSize: 16.0),)
                                  );
                                },
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                      SliverPadding(
                          padding: EdgeInsets.only(bottom: 20),
                          sliver: SliverToBoxAdapter(
                            child: new Container(
                              padding: EdgeInsets.only(
                                  right: 18, left: 18, top: 20, bottom: 10),
                              decoration: BoxDecoration(color: Colors.white),
                              child: new ButtonBar(
                                children: <Widget>[
                                  new FlatButton(
                                    onPressed: () {
                                      Navigator.push(context,
                                          EnterExitRoute(enterPage: CategoryPage()));
                                    },
                                    child: new Row(
                                      children: <Widget>[
                                        Padding(
                                          padding: EdgeInsets.only(
                                              top: 13,
                                              bottom: 13,
                                              left: 10,
                                              right: 10),
                                          child: Text(
                                            "View All Services",
                                            style: TextStyle(
                                              fontSize: 17,
                                              color:
                                              Color.fromRGBO(79, 195, 247, 1),
                                              fontFamily: "opensan",
                                            ),
                                          ),
                                        ),
                                        new Icon(FontAwesomeIcons.arrowRight,
                                            color: Color.fromRGBO(79, 195, 247, 1))
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            ),
                          )),
//                      SliverPadding(
//                          padding: EdgeInsets.only(top: 20),
//                          sliver: SliverToBoxAdapter(
//                            child: new Container(
//                              padding: EdgeInsets.only(
//                                  right: 18, left: 18, top: 20, bottom: 10),
//                              decoration: BoxDecoration(color: Colors.white),
//                              child: new Column(
//                                children: <Widget>[
//                                  new Container(
//                                    child: new Center(
//                                      child: Text(
//                                        "Customer Reviews",
//                                        style: TextStyle(
//                                            color: Color.fromRGBO(67, 91, 111, 1),
//                                            fontSize: 22,
//                                            fontFamily: "opensan",
//                                            fontWeight: FontWeight.w600),
//                                      ),
//                                    ),
//                                  ),
//                                ],
//                              ),
//                            ),
//                          )),
//                      _listReviews(),
//                      SliverPadding(
//                          padding: EdgeInsets.only(bottom: 10),
//                          sliver: SliverToBoxAdapter(
//                            child: new Container(
//                              padding: EdgeInsets.only(
//                                  right: 18, left: 18, top: 20, bottom: 10),
//                              decoration: BoxDecoration(color: Colors.white),
//                            ),
//                          )),
                      SliverPadding(
                        padding: EdgeInsets.only(top: 20, bottom: 100),
                        sliver: SliverToBoxAdapter(
                          child: new Column(
                            children: <Widget>[
                              new Container(
                                width: 45,
                                height: 35,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(10),
                                      bottomLeft: Radius.circular(10)),
                                  image: DecorationImage(
                                      image: AssetImage("assets/image/logo.png"),
                                      fit: BoxFit.cover,
                                      colorFilter: ColorFilter.mode(
                                          Colors.black, BlendMode.dstIn)),
                                ),
                              ),
                              new Container(
                                padding: EdgeInsets.only(top: 10),
                                child: new Center(
                                  child: new Text(
                                    "Service Clap",
                                    style: TextStyle(
                                        color: Color.fromRGBO(67, 91, 111, 0.4),
                                        fontSize: 16,
                                        fontFamily: "opensan",
                                        fontWeight: FontWeight.w700),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ) : Container(),
                ),
                onRefresh: getCategory,
                color: Colors.black,
              ),
            ),

            // Positioned(
            //     top: MediaQuery.of(context).size.height / 6.4,
            //     bottom: 0,
            //     left: 0,
            //     right: 0,
            //     child: loading == true
            //         ? Container(
            //             padding: EdgeInsets.only(left: 20, right: 20, top: 10),
            //             color: Colors.white,
            //             child: Shimmer.fromColors(
            //               baseColor: Colors.grey,
            //               highlightColor: Colors.white,
                          
            //               child: new Column(
            //                 children: <Widget>[
            //                   Container(
            //                     padding: EdgeInsets.only(top: 20),
            //                     child: new Container(
            //                       height: 150,
            //                       color: Colors.black.withOpacity(0.3),
            //                     ),
            //                   ),
            //                   new Container(
            //                       padding: EdgeInsets.only(top: 20),
            //                       child: new Column(
            //                         children: <Widget>[
            //                           new Row(
            //                             mainAxisAlignment:
            //                                 MainAxisAlignment.spaceBetween,
            //                             children: <Widget>[
            //                               new Flexible(
            //                                   flex: 1,
            //                                   child: new Container(
            //                                     height: 100,
            //                                     width: 100,
            //                                     color: Colors.black
            //                                         .withOpacity(0.2),
            //                                   )),
            //                               new Flexible(
            //                                   flex: 1,
            //                                   child: new Container(
            //                                     height: 100,
            //                                     width: 100,
            //                                     color: Colors.black
            //                                         .withOpacity(0.2),
            //                                   )),
            //                               new Flexible(
            //                                   flex: 1,
            //                                   child: new Container(
            //                                     height: 100,
            //                                     width: 100,
            //                                     color: Colors.black
            //                                         .withOpacity(0.2),
            //                                   ))
            //                             ],
            //                           ),
            //                           new Container(
            //                             padding: EdgeInsets.only(top: 20),
            //                             child: new Row(
            //                               mainAxisAlignment:
            //                                   MainAxisAlignment.spaceBetween,
            //                               children: <Widget>[
            //                                 new Flexible(
            //                                     flex: 1,
            //                                     child: new Container(
            //                                       height: 100,
            //                                       width: 100,
            //                                       color: Colors.black
            //                                           .withOpacity(0.2),
            //                                     )),
            //                                 new Flexible(
            //                                     flex: 1,
            //                                     child: new Container(
            //                                       height: 100,
            //                                       width: 100,
            //                                       color: Colors.black
            //                                           .withOpacity(0.2),
            //                                     )),
            //                                 new Flexible(
            //                                     flex: 1,
            //                                     child: new Container(
            //                                       height: 100,
            //                                       width: 100,
            //                                       color: Colors.black
            //                                           .withOpacity(0.2),
            //                                     ))
            //                               ],
            //                             ),
            //                           )
            //                         ],
            //                       ))
            //                 ],
            //               ),
            //             ),
            //           )
            //         : Container()),
                    
          ],
        ),
      ),
    );
  }

  _listReviews() {
    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (BuildContext context, int index) {
          return new Container(
              child: Container(
            color: Colors.white,
            child: new ListTile(
              leading: new Container(
                width: 30,
                height: MediaQuery.of(context).size.height,
                child: new Align(
                  alignment: Alignment.topRight,
                  child: Text(
                    "Mr",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontFamily: "opensan",
                    ),
                  ),
                ),
              ),
              title: new Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(
                    "Customer name",
                    style: TextStyle(
                        fontFamily: "opensan",
                        color: Color.fromRGBO(67, 91, 111, 1),
                        fontWeight: FontWeight.bold),
                  ),
                  new Container(
                    padding: EdgeInsets.only(
                      top: 10,
                    ),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Container(
                        padding: EdgeInsets.only(
                            left: 8, right: 8, top: 5, bottom: 5),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(3)),
                            border: Border.all(
                                color: Color.fromRGBO(238, 247, 250, 1)),
                            color: Color.fromRGBO(224, 247, 250, 1)),
                        child: Text(
                          "Hair Cutting",
                          style: TextStyle(
                              fontFamily: "opensan",
                              color: Color.fromRGBO(67, 91, 111, 1),
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  )
                ],
              ),
              subtitle: Padding(
                padding: EdgeInsets.only(top: 10),
                child: new Column(
                  children: <Widget>[
                    Text(
                      'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry',
                      style: TextStyle(
                        fontFamily: "noto",
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    new Padding(
                      padding: EdgeInsets.only(top: 10),
                      child: Divider(
                        color: Colors.grey,
                      ),
                    )
                  ],
                ),
              ),
            ),
          ));
        },

        /// Set childCount to limit no.of items
        childCount: 5,
      ),
    );
  }
}
