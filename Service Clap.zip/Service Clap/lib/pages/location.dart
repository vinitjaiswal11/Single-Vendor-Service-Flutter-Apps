import 'package:flutter/material.dart';
import 'dart:async';

import 'package:google_maps_webservice/places.dart';
import 'package:flutter_google_places/flutter_google_places.dart';

import 'dart:io';
import 'package:google_maps_webservice/places.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:service_app/utils/apis.dart';
import 'dart:core';
import 'package:service_app/pages/vendors.dart';
import 'package:service_app/pages/subcategories.dart';
import 'dart:convert';


class LoactionsPage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return LocationLoader();
  }

}

class LocationLoader extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return LocationView();
  }

}

class LocationView extends State<LocationLoader>{
  // var search ;
  var sear = TextEditingController();
  List searches = [];
  var searlen = 0;

  Future getproduct() async {
    var url = Apis.BASE_URL + "products/search";
    var data = {
      "search_value": sear.text
    };
    var res = await apiPostRequest(url,data);
    print(res);
    setState(() {
      searches = json.decode(res)['record'];
      searlen = searches.length;
    });
  }


  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  // var kGoogleApiKey = "AIzaSyAYnX4A3PFsD3me_DOR8mQ_Z8sqLkT_Xr8";
  // List places;
  //
  // void getplaces(places){
  //   places = Mode.values;
  // }

  // Future _getLocations(text) async{
  //   Prediction p = await PlacesAutocomplete.show(
  //       context: context,
  //       apiKey: kGoogleApiKey,
  //       mode: Mode.overlay , // Mode.fullscreen
  //       language: "fr",
  //       components: [new Component(Component.country, "fr")]);
  //   debugPrint(Mode.values.toString());
  // }



  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      body: CustomScrollView(
        slivers: <Widget>[
          SliverAppBar(
            title: new Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(
                      Radius.circular(5)
                  )
              ),
              child: Hero(
                tag: 'search',
                child: new Material(
                  borderRadius: BorderRadius.all(
                    Radius.circular(
                      5
                    )
                  ),
                  child: TextField(
                    controller: sear,
                    decoration: InputDecoration(
                      hintText: "Search",
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.only(
                        left: 10,
                        right: 10
                      ),
                      hintStyle: TextStyle(
                        fontFamily: "opensan",
                        fontWeight: FontWeight.bold,
                        color: Colors.grey
                      )
                    ),
                    autofocus: true,
                    style: TextStyle(
                        fontFamily: "opensan",
                        fontWeight: FontWeight.bold,
                      ),
                    onChanged: (val){
                      getproduct();
                    },
                  ),
                ),
              ),
            ),
            backgroundColor: Colors.black,

          ),
          SliverToBoxAdapter(
            child: Listv(),
          )


        ],


      ),

    );
  }
  Widget Listv()
  {
    return Container(
      child: ListView.builder(
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        itemCount: searlen,
        itemBuilder: (context, i){
          return Container(
            child: ListTile(
              onTap: (){
                if (searches[i]['type'] == "category")
                {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>SubcatsPage(catid:searches[i]['id'],catname:searches[i]['name'])));
                }
                else {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>VendorsPage(searches[i]['id'])));

                }

              },
              title: Text(searches[i]['name']),
              leading:  Image(
              image: NetworkImage(searches[i]['image']),
              width: 60,
            ),
          ));
        }



      ),

    );
  }


}