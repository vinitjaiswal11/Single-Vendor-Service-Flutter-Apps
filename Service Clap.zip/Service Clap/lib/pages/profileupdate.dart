import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_icons/flutter_icons.dart';
import 'package:flutter_icons/flutter_icons.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:io';
import 'package:service_app/utils/apis.dart';

class ProfileUpdate extends StatelessWidget {
  final name;
  final email;
  final phone;
  ProfileUpdate({Key key, this.name, this.email, this.phone}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return ProfileUpdateLoader(
      email: this.email,
      name: this.name,
      phone: this.phone,
    );
  }
}

class ProfileUpdateLoader extends StatefulWidget {
  final name;
  final email;
  final phone;
  ProfileUpdateLoader({Key key, this.name, this.email, this.phone})
      : super(key: key);
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return ProfileUpdateView();
  }
}

class ProfileUpdateView extends State<ProfileUpdateLoader> {
  var name = TextEditingController();
  var email = TextEditingController();
  var phone = TextEditingController();

  var loading = false;

  var nameerror = null;
  var emailerror = null;
  var phoneerror = null;

  Future _updateProfile() async {
    if (name.text == "" && email.text == "") {
      setState(() {
        nameerror = "Name cannot be blank";
        emailerror = "Email cannot be blank";
        loading = false;
      });
    } else if (name.text == "") {
      setState(() {
        nameerror = "Name cannot be blank";
        loading = false;
      });
    } else if (email.text == "") {
      setState(() {
        emailerror = "Email cannot be blank";
        loading = false;
      });
    } else {
      if(widget.name == name.text && widget.email == email.text) {

      }else{
        setState(() {
          loading = true;
        });
        var url = Apis.BASE_URL+"Login/updateProfile";
        var sp = await SharedPreferences.getInstance();
        var userid = sp.getString("userid");
        var data = {
          'first_name' : name.text,
          'last_name' :'',
          'email' : email.text,
          'user_id': userid
        };
        var res = await apiPostRequest(url, data);
        print(res);
        Navigator.pop(context);
      }

    }
  }

  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  Future _getProfile() async {
    setState(() {
      name.text = widget.name.toString();
      email.text = widget.email.toString();
      phone.text = widget.phone.toString();
    });
  }
  Color color;
  Future onChange() async{
    setState(() {
//      color = widget.name == name.text ? Colors.blueAccent.withOpacity(0.5) :
//              widget.email == email.text ? Colors.blueAccent.withOpacity(0.5) :
//              Colors.blueAccent;
      if(widget.name == name.text && widget.email == email.text){
        color = Colors.blueAccent.withOpacity(0.5);
      }else{
        color = Colors.blueAccent;
      }

    });
  }


  @override
  void initState() {
    super.initState();
    _getProfile();
    onChange();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Container(
            child: loading == true
                ? FlatButton(
                    child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 5,
                        backgroundColor: Colors.black12,
                      ),
                    ),
                  )
                : Text(
                    "Edit Profile",
                    style:
                        TextStyle(color: Colors.black, fontFamily: "opensan"),
                  ),
          ),
          backgroundColor: Colors.white,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              AntDesign.close,
              color: Colors.redAccent,
            ),
          ),
          centerTitle: true,
          elevation: 0.3,
          actions: <Widget>[
            new Container(
              child: loading == true
                  ? Container()
                  : IconButton(
                      icon: Icon(
                        AntDesign.check,
                        color: color
                      ),
                      onPressed: () {
                        _updateProfile();
                      },
                    ),
            )
          ],
        ),
        backgroundColor: Color.fromRGBO(243, 244, 251, 1),
        body: SingleChildScrollView(
          padding: EdgeInsets.only(top: 10),
          child: new Container(
            color: Colors.white,
            padding: EdgeInsets.only(top: 20, bottom: 40),
            child: new Column(
              children: <Widget>[
                new Container(
                  padding: EdgeInsets.only(left: 20, right: 20, bottom: 10),
                  child: new TextField(
                    controller: name,
                    decoration: InputDecoration(
                        labelText: "Full Name",
                        labelStyle: TextStyle(fontFamily: "opensan"),
                        errorText: nameerror,
                        errorStyle: TextStyle(fontFamily: "opensan")),
                    onChanged: (value){
                      if(value != ""){
                        setState(() {
                          nameerror = null;
                        });
                      }else{
                        setState(() {
                          nameerror = "Name cannot be blank";
                        });
                      }
                      onChange();
                    },
                  ),
                ),
                new Container(
                  padding: EdgeInsets.only(left: 20, right: 20, bottom: 10),
                  child: new TextField(
                    controller: email,
                    decoration: InputDecoration(
                        labelText: "Email",
                        labelStyle: TextStyle(fontFamily: "opensan"),
                        errorText: emailerror,
                        errorStyle: TextStyle(fontFamily: "opensan")),
                    onChanged: (value){
                      if(value != ""){
                        setState(() {
                          emailerror = null;
                        });
                      }else{
                        setState(() {
                          emailerror = "Email cannot be blank";
                        });
                      }
                      onChange();
                    },
                  ),
                ),
                new Container(
                  padding: EdgeInsets.only(left: 20, right: 20, bottom: 10),
                  child: new TextField(
                    readOnly: true,
                    controller: phone,
                    decoration: InputDecoration(
                        labelText: "Phone",
                        labelStyle: TextStyle(fontFamily: "opensan")),
                  ),
                ),
                new Container(
                  padding: EdgeInsets.only(left: 20, right: 20, top: 10),
                  child: new Text(
                    "All the above information will be use for delivery profile option",
                    style:
                        TextStyle(fontFamily: "opensan", color: Colors.black45),
                    textAlign: TextAlign.center,
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
