import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:service_app/animators/navianimator.dart';

//import 'package:service_app/pages/itemsdescription.dart';
import 'package:sticky_headers/sticky_headers.dart';
import 'package:flutter_sticky_header/flutter_sticky_header.dart';
import 'dart:convert';
import 'package:service_app/pages/finalbill.dart';
import 'dart:io';
import 'dart:ui' as ui;
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:service_app/utils/apis.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:service_app/database/vendorcart.dart';
import 'package:service_app/database/vendordb_helper.dart';
import 'package:service_app/pages/itemsdescription.dart';
//import 'package:flare_flutter/flare_actor.dart';

class CategorydetailPage extends StatelessWidget {
//  final categoryname;
//  final catid;
//  final bannimage;

    final vendorid;
    final vendorname;
    final vendorimage;
  CategorydetailPage({Key key, this.vendorid, this.vendorname, this.vendorimage})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return CategorydetailLoader(
        vendorid: this.vendorid, vendorname :this.vendorname, vendorimage: this.vendorimage,);
  }
}

class CategorydetailLoader extends StatefulWidget {
  final vendorid;
  final vendorname;
  final vendorimage;
  CategorydetailLoader({Key key, this.vendorid,this.vendorname,this.vendorimage})
      : super(key: key);
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return CategorydetailView();
  }
}

class CategorydetailView extends State<CategorydetailLoader> {

  Future<List<Vendorcart>> cart;
  var dbHelper;

  List services;
  var servicelen = 0;
  var heading = "";
  bool loading = true;


  var top = 0.0;
  Future _setHeight(tops) async {
    setState(() {
      print(top);
    });
  }

  bool shows = true;

  var ind = 0;

  Future _setInd(indget) async {
    setState(() {
      ind = indget;
    });
  }

  List package = [];
  List package_mirror = [];
  var packalen = 0;
  var subcids;

  var subcatid = "";

  getServices() async{

    var url = Apis.BASE_URL + "Vendors/getServices";
    var data = {"vendor_id":widget.vendorid};
    var res = await apiPostRequest(url,data);
    print(json.decode(res)['records']);
    setState(() {
      package = json.decode(res)['records'];
      package_mirror = json.decode(res)['records'];

      subcatid = json.decode(res)['records'][0]['category_id'];
      packalen = package.length;
      loading = false;
    });
    refreshList();
  }

  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('Content-Type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  ScrollController _scrollController;
  Color _theme;
  bool show = false;

  refreshList() {
    var vendorid = int.parse(widget.vendorid);
    setState(() {
      cart = dbHelper.getCart(vendorid);
    });
  }

  saveCart(serviceid,categoryid,vendorid,subcatid,servicename,type,mrp,price,qty) async {
    setState(() {
      package = [];
      packalen = 0;
    });
    Vendorcart c = Vendorcart(serviceid,categoryid,vendorid,subcatid,servicename,type,mrp,price,qty);
    dbHelper.save(c);
    setState(() {
      package = package_mirror;
      packalen = package_mirror.length;
    });
    refreshList();
//    getProductsnew();
  }

  checkIncart(serviceid){
    var values = dbHelper.getProduct(int.parse(serviceid));
    print(values);
    return values;
  }

  updateCart(serviceid,categoryid,vendorid,subcatid,servicename,type,mrp,price,qty){
    setState(() {
      package = [];
      packalen = 0;
    });
    Vendorcart c = Vendorcart(serviceid,categoryid,vendorid,subcatid,servicename,type,mrp,price,qty);
    dbHelper.update(c);
    setState(() {
      package = package_mirror;
      packalen = package_mirror.length;
    });
    refreshList();
  }

  deleteCart(serviceid,categoryid){
    setState(() {
      package = [];
      packalen = 0;
    });
    dbHelper.delete(serviceid);
//    Vibration.vibrate();
    setState(() {
      package = package_mirror;
      packalen = package_mirror.length;
    });
    refreshList();
  }

  @override
  void initState() {
    super.initState();
    dbHelper = VendorDbHelper();
    getServices();
    _theme = Colors.black;
    _scrollController = ScrollController()
      ..addListener(
            () => _isAppBarExpanded
            ? _theme != Colors.black
            ? setState(
              () {
            _theme = Colors.black;
            show = true;
          },
        )
            : {}
            : _theme != Colors.black
            ? setState(() {
          _theme = Colors.black;
          show = false;
        })
            : {},
      );
  }

  bool get _isAppBarExpanded {
    return _scrollController.hasClients &&
        _scrollController.offset > (200 - kToolbarHeight);
  }

  Stream<int> _lot;

  Stream<int> bids;

  List<Map<String, dynamic>> send = [];
  var items = null;


//  Future deleteFromcart(ind, subid, packid) async {
//    setState(() {
//      loading = true;
//    });
//    var sp = await SharedPreferences.getInstance();
//    var key = Key;
//    var token = sp.getString("token");
//    print(token.toString());
//    var map = Map<String, dynamic>();
//    map['package_id'] = packid;
//    map['sub_id'] = subid;
//    map['cat_id'] = widget.catid;
////    print(map);
//    var body = json.encode(map);
//    var url = "http://serveondoor.com/servernew/Restapi/cartdelete";
//    http.Response res = await http.post(url,
//        headers: <String, String>{'token': token}, body: map);
////    getPackagesAfterAdd();
//    getPackagesAfterAdd();
////     print(res.body);
//  }

  var qty = "0";

//  getCart() async {
//    var sp = await SharedPreferences.getInstance();
//    var token = sp.getString("token");
//    print(token.toString());
//    var map = Map<String, dynamic>();
//    map['cat_id'] = widget.catid;
//    // print(tok);
//    var body = json.encode(map);
//    var url = "http://serveondoor.com/servernew/Restapi/quantity";
//    http.Response res = await http.post(url,
//        headers: <String, String>{'token': token}, body: map);
//    // setState(() {
//    //   qty = json.decode(res.body)['quantity'];
//    // });
//    print(res.body);
//    if(json.decode(res.body)['quantity'] != 0){
//      setState(() {
//        qty = json.decode(res.body)['quantity'].toString();
//        print("1st "+qty);
//        shows = true;
//        loading = false;
//      });
//    }
//    else if(json.decode(res.body)['quantity'] == 0){
//      setState(() {
//        qty = json.decode(res.body)['quantity'].toString();
//        print("2nd "+qty);
//        shows = false;
//        loading = false;
//        //  qty = 0;
//      });
//    }
//    // return;
//  }

  @override
  Widget build(BuildContext context) {
    Widget productnames;
    _getProducts(text) {
      return ListView.builder(
          itemCount: 1,
          physics: NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemBuilder: (BuildContext ctxt, int ind) {
            return new Align(
                alignment: Alignment.centerLeft,
                child: new Container(
                  padding: EdgeInsets.only(bottom: 10),
                  child: Html(
                    data : text,
//                    style: TextStyle(fontSize: 11,
//                        color: Colors.black45
//                        ,fontWeight: FontWeight.w400),
//                    maxLines: 3,
                    defaultTextStyle: TextStyle(fontSize: 11,
                        color: Colors.black45
                        ,fontWeight: FontWeight.w400,
                    ),

                  ),

                )
            );
          });
      // }
    }

    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color.fromRGBO(243, 244, 251, 1),
        body: Stack(
          children: <Widget>[
            new Container(
              child: CustomScrollView(
                controller: _scrollController,
                slivers: <Widget>[
                  SliverAppBar(
                    // title: top == 56?Text("widget.categoryname"):Text(""),
//                    expandedHeight: 100.0,
                    floating: false,
                    pinned: true,
                    elevation: 1,
                    title: show == true
                        ? AnimatedOpacity(
                      duration: Duration(milliseconds: 2000),
                      opacity: 1.0,
                      child: Text(
//                        widget.categoryname,
                      "",
                        style: TextStyle(
                          color: _theme,
                        ),
                      ),
                    )
                        : Text(""),
                    flexibleSpace: FlexibleSpaceBar(
                        centerTitle: false,
                        title: AnimatedOpacity(
                            duration: Duration(milliseconds: 300),
                            //opacity: top == 80.0 ? 1.0 : 0.0,
                            opacity: 1.0,
                            child: top == 56
                                ? Text(
//                              widget.categoryname,
                              "",
                              style: TextStyle(color: Colors.black),
                            )
                                : Text("")),
//                        background: Image(
//                          image: NetworkImage(widget.bnimage),
//                          fit: BoxFit.cover,
//                        )
                    ),
                    backgroundColor: Colors.white,
                    leading: top == 56
                        ? IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: Icon(
                        FontAwesomeIcons.arrowLeft,
                        color: Colors.black,
                      ),
                    )
                        : IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: Icon(
                        FontAwesomeIcons.arrowLeft,
                        color: _theme,
                      ),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Stack(
                      children: [
                        Container(
                            height : 50,
                            color : Colors.white
                        ),
                        Container(
//                        color: Colors.black,
                          transform: Matrix4.translationValues(0.0, -15.0, 0.0),
                          child: new Column(
                            children: <Widget>[
                              new Center(
                                child: new Padding(
                                    padding: EdgeInsets.only(top: 20, bottom: 10),
                                    child: Container(
                                      height : 80,
                                      width: 80,
                                      padding: EdgeInsets.only(
                                          left: 10, right: 10, top: 7, bottom: 7),
                                      decoration: BoxDecoration(
                                          color: Color.fromRGBO(67, 91, 111, 1),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(120)),
                                          border : Border.all(
                                            color: Color.fromRGBO(243, 244, 251, 1),
                                            width: 5
                                          ),
                                          image: DecorationImage(
                                            image : NetworkImage(widget.vendorimage),
                                          )
                                      ),
                                    )
                                  ),
                              ),
                              new Center(
                                child: Container(
                                  child: Text(
                                      widget.vendorname,
                                    style : TextStyle(
                                      fontWeight: FontWeight.w500,
                                      fontSize: 15
                                    )
                                  )
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
//                  SliverPadding(
//                    padding: EdgeInsets.only(top: 0),
//                    sliver: SliverToBoxAdapter(
//                      child: new ,
//                    ),
//                  ),
                  SliverStickyHeader(
//                    header: Material(
//                        elevation: 1,
//                        child: new Container(
//                          height: 130,
//                          color: Colors.white,
//                          child: ListView.separated(
//                            padding:
//                            EdgeInsets.only(bottom: 10, left: 5, right: 5),
//                            itemCount: 6,
//                            scrollDirection: Axis.horizontal,
//                            separatorBuilder:
//                                (BuildContext context, int index) => Divider(),
//                            itemBuilder: (BuildContext context, int index) {
//                              return new Material(
//                                borderRadius:
//                                BorderRadius.all(Radius.circular(7)),
//                                borderOnForeground: true,
//                                color: ind == index
//                                    ? Color.fromRGBO(225, 245, 254, 1)
//                                    : Colors.white,
//                                child: InkWell(
//                                  onTap: () {
//                                    // _setInd(index);
//                                    // var subid = services[index]['sub_id'];
//                                    // getPackages(subid, index);
//                                  },
//                                  child: Card(
//                                    color: Colors.transparent,
//                                    elevation: 0,
//                                    child: new Column(
//                                      mainAxisAlignment:
//                                      MainAxisAlignment.center,
//                                      children: <Widget>[
//                                        Container(
//                                          width: 70,
//                                          height: 70,
//                                          decoration: BoxDecoration(
//                                              borderRadius: BorderRadius.all(
//                                                  Radius.circular(5)),
//                                              color: Colors.black,
//                                              image: DecorationImage(
//                                                  image: index == 0 ?AssetImage("assets/image/phone.jpg"):
//                                                  index == 1?AssetImage("assets/image/ac.jpg"):
//                                                  index == 2?AssetImage("assets/image/refrigerator.png"):
//                                                  index == 3?AssetImage("assets/image/tv.jpg"):
//                                                  index == 4?AssetImage("assets/image/washing.jpg"):
//                                                  index == 5?AssetImage("assets/image/cooler.jpeg"):null,
//                                                  fit: BoxFit.cover),
//                                              border: Border.all(
//                                                  color: Colors.grey)),
//                                        ),
//                                        Expanded(
//                                          child: new Center(
//                                            child: new Container(
//                                              width: 100,
//                                              // height: 40,
//                                              child: Padding(
//                                                padding: EdgeInsets.only(top: 0),
//                                                child: Text(
//                                                  index == 0
//                                                      ?"Phone":
//                                                  index == 1?"AC":
//                                                  index == 2?"Refrigerator":
//                                                  index == 3?"TV":
//                                                  index == 4?"Washing Machine":
//                                                  index == 5?"Cooler":"",
//                                                  style: TextStyle(
//                                                      color: ind == index
//                                                          ? Colors.black
//                                                          : Colors.black,
//                                                      fontFamily: "opensan"),
//                                                  maxLines: 2,
//                                                  textAlign: TextAlign.center,
//                                                ),
//                                              ),
//                                            ),
//                                          ),
//                                        )
//                                      ],
//                                    ),
//                                  ),
//                                ),
//                              );
//                            },
//                          ),
//                        )),
                  header: Container(),
                    sliver: SliverToBoxAdapter(
                        child: new Container(
                          padding: EdgeInsets.only(top: 20, bottom: 10),
                          child: Container(
                            padding: EdgeInsets.only(left: 5, right: 5),
                            child: ListView.builder(
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemCount: packalen,
                              itemBuilder: (context, item){
                                return Card(
                                  child: Container(
                                    child: new Column(
                                      children: <Widget>[
                                        Container(
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                left : 0,
                                                top : 0,
                                                child: new Container(
                                                  height: 90,
                                                  width: 90,
                                                  padding:
                                                  EdgeInsets.only(top: 5),
                                                  child: Align(
                                                    alignment:
                                                    Alignment.topCenter,
                                                    child: new Container(
                                                      width: 80,
                                                      height: 80,
                                                      decoration: BoxDecoration(
                                                        // color: Colors.cyan,
                                                          image: DecorationImage(
                                                              image : NetworkImage(package[item]['image_url']),
                                                              fit: BoxFit.contain),
                                                          borderRadius:
                                                          BorderRadius
                                                              .all(Radius
                                                              .circular(
                                                              5))),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              new ListTile(
                                                contentPadding: EdgeInsets.only(
                                                    left: 95,
                                                    right: 20
                                                ),
                                                title: Padding(
                                                  padding: EdgeInsets.only(
                                                    top: 0,
                                                  ),
                                                  child: Text(
                                                    package[item]['name'],
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w600,
                                                        fontFamily: "opensan"
                                                    ),
                                                  ),
                                                ),

                                                subtitle: new Row(
                                                  mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                                  children: <Widget>[
                                                    Align(
                                                      alignment: Alignment
                                                          .centerLeft,
                                                      child: new Row(
                                                        children: <Widget>[
                                                          Padding(
                                                            padding:
                                                            EdgeInsets.only(
                                                                top: 5),
                                                            child: new Container(
                                                                child:
                                                                new Container(
                                                                  padding:
                                                                  EdgeInsets.only(
                                                                    left: 10,
                                                                    right: 10,
                                                                    top: 2,
                                                                    bottom: 2,
                                                                  ),
                                                                  color:
                                                                  Colors.red[50],
                                                                  child: Text(
                                                                    "\u20B9 "+roundofPrice(package[item]['price'])
                                                                        .toString(),
                                                                    style: TextStyle(
                                                                        fontFamily:
                                                                        "opensan",
                                                                        color: Colors
                                                                            .black,
                                                                        fontWeight:
                                                                        FontWeight
                                                                            .bold),
                                                                  ),
                                                                )),
                                                          ),
                                                          Padding(
                                                            padding:
                                                            EdgeInsets.only(
                                                                top: 5),
                                                            child: new Container(
                                                                child:
                                                                new Container(
                                                                  padding:
                                                                  EdgeInsets.only(
                                                                    left: 10,
                                                                    right: 10,
                                                                    top: 2,
                                                                    bottom: 2,
                                                                  ),
                                                                  child: Text(
                                                                    "\u20B9" +roundofPrice(package[item]['mrp']),
                                                                    style: TextStyle(
                                                                        fontFamily:
                                                                        "opensan",
                                                                        color: Colors
                                                                            .black.withOpacity(0.7),
                                                                        decoration: TextDecoration.lineThrough
                                                                    ),
                                                                  ),
                                                                )),),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                        width: 70,
                                                        height: 30,
                                                        child:FutureBuilder(
                                                          future: checkIncart(package[item]['service_id']),
                                                          builder : (context, AsyncSnapshot snapshot){
                                                            print("Data : "+snapshot.data[0].toString());
                                                            if(snapshot.hasData){
                                                              return Container(
                                                                child : snapshot.data[0].toString() == "Instance of 'Vendorcart'"
                                                                    ?Material(
                                                                  borderRadius:
                                                                  BorderRadius.all(
                                                                      Radius
                                                                          .circular(
                                                                          5)),
                                                                  child: InkWell(
                                                                    borderRadius:
                                                                    BorderRadius
                                                                        .all(Radius
                                                                        .circular(
                                                                        5)),
//                                                                  onTap: () {
//////                                                              serviceid,categoryid,vendorid,subcatid,servicename,mrp,price,qty
////                                                              print(int.parse(widget.vendorid));
//                                                                    var mrp = int.parse(roundofPrice(package[item]['mrp']));
//                                                                    var price = int.parse(roundofPrice(package[item]['price']));
//                                                                    saveCart(
//                                                                        int.parse(package[item]['service_id'])
//                                                                        ,int.parse(package[item]['category_id'])
//                                                                        ,int.parse(widget.vendorid)
//                                                                        ,int.parse(package[item]['subcategory_id'])
//                                                                        ,package[item]['name'].toString()
//                                                                        ,mrp
//                                                                        ,price
//                                                                        ,1);
//                                                                  },
                                                                    child:
                                                                    new Container(
                                                                      decoration: BoxDecoration(
                                                                          border: Border.all(
                                                                              color: Color.fromRGBO(
                                                                                  79,
                                                                                  155,
                                                                                  247,
                                                                                  1),
                                                                              width: 1),
                                                                          borderRadius:
                                                                          BorderRadius.all(
                                                                              Radius.circular(
                                                                                  5))),
                                                                      child: new Row(
                                                                        mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceBetween,
                                                                        children: <Widget>[
                                                                          Material(
                                                                            borderRadius:
                                                                            BorderRadius.all(
                                                                                Radius
                                                                                    .circular(
                                                                                    5)),
                                                                            child: InkWell(
                                                                              borderRadius:
                                                                              BorderRadius.all(
                                                                                  Radius
                                                                                      .circular(
                                                                                      5)),
                                                                              onTap: (){
                                                                                int qty = snapshot.data[0].qty - 1;
                                                                                var mrp = int.parse(roundofPrice(package[item]['mrp']));
                                                                                var price = int.parse(roundofPrice(package[item]['price']));
                                                                                if(qty > 0){
                                                                                  updateCart(
                                                                                      int.parse(package[item]['service_id'])
                                                                                      ,int.parse(package[item]['category_id'])
                                                                                      ,int.parse(widget.vendorid)
                                                                                      ,int.parse(package[item]['subcategory_id'])
                                                                                      ,package[item]['name'].toString()
                                                                                      ,package[item]['product_type'].toString()
                                                                                      ,mrp
                                                                                      ,price
                                                                                      ,qty);
                                                                                }else{
                                                                                  deleteCart(int.parse(package[item]['service_id']), int.parse(package[item]['category_id']));
                                                                                }
                                                                              },
                                                                              child: new Container(
                                                                                width: 25,
                                                                                height: MediaQuery.of(
                                                                                    context)
                                                                                    .size
                                                                                    .height,
                                                                                decoration: BoxDecoration(

                                                                                    borderRadius:
                                                                                    BorderRadius.all(Radius.circular(5))),
                                                                                child:
                                                                                Center(
                                                                                  child:
                                                                                  Icon(
                                                                                    Icons.remove,
                                                                                    color: Color.fromRGBO(
                                                                                        79,
                                                                                        155,
                                                                                        247,
                                                                                        1),
                                                                                    size: 15,

                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Expanded(
                                                                            child: Center(
                                                                              child: new Container(
                                                                                // padding: EdgeInsets
                                                                                //     .only(
                                                                                //     left:
                                                                                //     10),
                                                                                child: Text( snapshot.data[0].qty.toString(),
                                                                                  style: TextStyle(
                                                                                      fontFamily:
                                                                                      "opensan",
                                                                                      fontWeight: FontWeight
                                                                                          .w600,
                                                                                      fontSize: 12,
                                                                                      color: Color.fromRGBO(
                                                                                          79,
                                                                                          155,
                                                                                          247,
                                                                                          1)),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          new Material(
                                                                            borderRadius:
                                                                            BorderRadius.all(
                                                                                Radius
                                                                                    .circular(
                                                                                    5)),
                                                                            child: InkWell(
                                                                              borderRadius:
                                                                              BorderRadius.all(
                                                                                  Radius
                                                                                      .circular(
                                                                                      5)),
                                                                              onTap: (){
                                                                                int qty = snapshot.data[0].qty + 1;
                                                                                var mrp = int.parse(roundofPrice(package[item]['mrp']));
                                                                                var price = int.parse(roundofPrice(package[item]['price']));
                                                                                updateCart(
                                                                                    int.parse(package[item]['service_id'])
                                                                                    ,int.parse(package[item]['category_id'])
                                                                                    ,int.parse(widget.vendorid)
                                                                                    ,int.parse(package[item]['subcategory_id'])
                                                                                    ,package[item]['name'].toString()
                                                                                    ,package[item]['product_type'].toString()
                                                                                    ,mrp
                                                                                    ,price
                                                                                    ,qty);
                                                                              },
                                                                              child: Container(
                                                                                width: 25,
                                                                                height: MediaQuery.of(
                                                                                    context)
                                                                                    .size
                                                                                    .height,
                                                                                decoration: BoxDecoration(
                                                                                    borderRadius:
                                                                                    BorderRadius.all(Radius.circular(5))),
                                                                                child:
                                                                                Center(
                                                                                  child:
                                                                                  Icon(
                                                                                    Icons.add,
                                                                                    color: Color.fromRGBO(
                                                                                        79,
                                                                                        155,
                                                                                        247,
                                                                                        1),
                                                                                    size: 15,

                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          )
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                )
                                                                    :Material(
                                                                  borderRadius:
                                                                  BorderRadius.all(
                                                                      Radius
                                                                          .circular(
                                                                          5)),
                                                                  child: InkWell(
                                                                    borderRadius:
                                                                    BorderRadius
                                                                        .all(Radius
                                                                        .circular(
                                                                        5)),
                                                                    onTap: () {
////                                                              serviceid,categoryid,vendorid,subcatid,servicename,mrp,price,qty
//                                                              print(int.parse(widget.vendorid));
                                                                      var mrp = int.parse(roundofPrice(package[item]['mrp']));
                                                                      var price = int.parse(roundofPrice(package[item]['price']));
                                                                      saveCart(
                                                                          int.parse(package[item]['service_id'])
                                                                          ,int.parse(package[item]['category_id'])
                                                                          ,int.parse(widget.vendorid)
                                                                          ,int.parse(package[item]['subcategory_id'])
                                                                          ,package[item]['name'].toString()
                                                                          ,package[item]['product_type'].toString()
                                                                          ,mrp
                                                                          ,price
                                                                          ,1);
                                                                    },
                                                                    child:
                                                                    new Container(
                                                                      decoration: BoxDecoration(
                                                                          border: Border.all(
                                                                              color: Color.fromRGBO(
                                                                                  79,
                                                                                  155,
                                                                                  247,
                                                                                  1),
                                                                              width: 1),
                                                                          borderRadius:
                                                                          BorderRadius.all(
                                                                              Radius.circular(
                                                                                  5))),
                                                                      child: new Row(
                                                                        mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceBetween,
                                                                        children: <
                                                                            Widget>[
                                                                          Expanded(
                                                                            child: Center(
                                                                              child: new Container(
                                                                                // padding: EdgeInsets
                                                                                //     .only(
                                                                                //     left:
                                                                                //     10),
                                                                                child: Text( " ADD",
                                                                                  style: TextStyle(
                                                                                      fontFamily:
                                                                                      "opensan",
                                                                                      fontWeight: FontWeight
                                                                                          .w600,
                                                                                      fontSize: 12,
                                                                                      color: Color.fromRGBO(
                                                                                          79,
                                                                                          155,
                                                                                          247,
                                                                                          1)),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          new Container(
                                                                            width: 25,
                                                                            height: MediaQuery.of(
                                                                                context)
                                                                                .size
                                                                                .height,
                                                                            decoration: BoxDecoration(
                                                                                color: Colors
                                                                                    .blue
                                                                                    .withOpacity(
                                                                                    0.1),
                                                                                borderRadius:
                                                                                BorderRadius.all(Radius.circular(5))),
                                                                            child:
                                                                            Center(
                                                                              child:
                                                                              Text(
                                                                                "+",
                                                                                style: TextStyle(
                                                                                    fontFamily:
                                                                                    "opensan",

                                                                                    fontWeight: FontWeight
                                                                                        .bold,
                                                                                    color: Color.fromRGBO(
                                                                                        79,
                                                                                        155,
                                                                                        247,
                                                                                        1),
                                                                                    fontSize:
                                                                                    15),
                                                                              ),
                                                                            ),
                                                                          )
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                )

                                                              );
                                                            }
                                                            if(null == snapshot.data || snapshot.data.length == 0){
                                                              return Material(
                                                                borderRadius:
                                                                BorderRadius.all(
                                                                    Radius
                                                                        .circular(
                                                                        5)),
                                                                child: InkWell(
                                                                  borderRadius:
                                                                  BorderRadius
                                                                      .all(Radius
                                                                      .circular(
                                                                      5)),
                                                                  onTap: () {
////                                                              serviceid,categoryid,vendorid,subcatid,servicename,mrp,price,qty
//                                                              print(int.parse(widget.vendorid));
                                                                    var mrp = int.parse(roundofPrice(package[item]['mrp']));
                                                                    var price = int.parse(roundofPrice(package[item]['price']));
                                                                    saveCart(
                                                                        int.parse(package[item]['service_id'])
                                                                        ,int.parse(package[item]['category_id'])
                                                                        ,int.parse(widget.vendorid)
                                                                        ,int.parse(package[item]['subcategory_id'])
                                                                        ,package[item]['name'].toString()
                                                                        ,package[item]['product_type'].toString()
                                                                        ,mrp
                                                                        ,price
                                                                        ,1);
                                                                  },
                                                                  child:
                                                                  new Container(
                                                                    decoration: BoxDecoration(
                                                                        border: Border.all(
                                                                            color: Color.fromRGBO(
                                                                                79,
                                                                                155,
                                                                                247,
                                                                                1),
                                                                            width: 1),
                                                                        borderRadius:
                                                                        BorderRadius.all(
                                                                            Radius.circular(
                                                                                5))),
                                                                    child: new Row(
                                                                      mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .spaceBetween,
                                                                      children: <
                                                                          Widget>[
                                                                        Expanded(
                                                                          child: Center(
                                                                            child: new Container(
                                                                              // padding: EdgeInsets
                                                                              //     .only(
                                                                              //     left:
                                                                              //     10),
                                                                              child: Text( " ADD",
                                                                                style: TextStyle(
                                                                                    fontFamily:
                                                                                    "opensan",
                                                                                    fontWeight: FontWeight
                                                                                        .w600,
                                                                                    fontSize: 12,
                                                                                    color: Color.fromRGBO(
                                                                                        79,
                                                                                        155,
                                                                                        247,
                                                                                        1)),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        new Container(
                                                                          width: 25,
                                                                          height: MediaQuery.of(
                                                                              context)
                                                                              .size
                                                                              .height,
                                                                          decoration: BoxDecoration(
                                                                              color: Colors
                                                                                  .blue
                                                                                  .withOpacity(
                                                                                  0.1),
                                                                              borderRadius:
                                                                              BorderRadius.all(Radius.circular(5))),
                                                                          child:
                                                                          Center(
                                                                            child:
                                                                            Text(
                                                                              "+",
                                                                              style: TextStyle(
                                                                                  fontFamily:
                                                                                  "opensan",

                                                                                  fontWeight: FontWeight
                                                                                      .bold,
                                                                                  color: Color.fromRGBO(
                                                                                      79,
                                                                                      155,
                                                                                      247,
                                                                                      1),
                                                                                  fontSize:
                                                                                  15),
                                                                            ),
                                                                          ),
                                                                        )
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                              );
                                                            }
                                                            return CircularProgressIndicator();
                                                          }
                                                        )

                                                    )
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        new Padding(
                                          padding: EdgeInsets.only(
                                              top: 10,
                                              bottom: 10,
                                              left: 20,
                                              right: 20),
                                          child: const MySeparator(
                                            color: Color.fromRGBO(
                                                207, 216, 220, 1),
                                          ),
                                        ),
                                        new Container(
                                          padding: EdgeInsets.only(
                                              left: 20,
                                              right: 20,
                                              bottom: 10),
                                          child: new Column(
                                            children: <Widget>[
                                              Align(
                                                  alignment: Alignment
                                                      .centerLeft,
                                                  child: new Container(
                                                    padding:
                                                    EdgeInsets.only(
                                                        bottom: 10),
                                                    child:
                                                    //Text("All Detail")
                                                    _getProducts(package[item]['details']),
                                                  )
                                              ),
                                              InkWell(
                                                onTap: (){
                                                  var mrp = int.parse(roundofPrice(package[item]['mrp']));
                                                  var price = int.parse(roundofPrice(package[item]['price']));
                                                     Navigator.push(context, MaterialPageRoute(builder: (context)=>ItemsLoader(
                                                         package[item]['name'].toString()
                                                         ,package[item]['image_url'].toString()
                                                         ,price
                                                         ,mrp,
                                                         package[item]['details']
                                                     )));

                                                },
                                                child: new Row(
                                                  children: [
                                                    Text("View Details",
                                                      style: TextStyle(fontSize: 10,
                                                        color: Colors.deepPurpleAccent,
                                                      ),

                                                      //package[index]['products'][ind]['product_name'].toString()),
                                                    ),
                                                    Icon(
                                                      Icons.chevron_right,
                                                      color: Colors.deepPurpleAccent,
                                                      size: 19,
                                                    )
                                                  ],
                                                ),
                                              )
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        )),
                  ),
//                  SliverToBoxAdapter(
//                    child: new Container(
//                      padding: EdgeInsets.only(top: 15, bottom: 5),
//                      child: new Container(
//                        decoration: BoxDecoration(
//                          gradient: RadialGradient(
//                            colors: [
//                              Color.fromRGBO(3, 22, 49, 1),
//                              Color.fromRGBO(10, 59, 155, 1),
//                              Color.fromRGBO(10, 59, 155, 1),
//                              Color.fromRGBO(3, 22, 49, 1)
//                            ],
//                            stops: [0.2, 0.2, 1, 2],
//                            center: Alignment(0.1, 0.3),
//                            focal: Alignment(-1, 0.6),
//                            focalRadius: 2,
//                          ),
//                        ),
//                        child: new Container(
//                          height: 200,
//                          padding: EdgeInsets.only(left: 20, top: 20),
//                          color: Colors.black.withOpacity(0.5),
//                          child: new Column(
//                            children: <Widget>[
//                              Align(
//                                alignment: Alignment.centerLeft,
//                                child: new Container(
//                                  padding: EdgeInsets.only(top: 10, bottom: 20),
//                                  child: new Row(
//                                    children: <Widget>[
//                                      new Container(
//                                        padding: EdgeInsets.only(right: 10),
//                                        child: Icon(
//                                            FontAwesomeIcons.checkDouble,
//                                            color: Colors.white),
//                                      ),
//                                      new Text(
//                                        "Fulfilled under this service",
//                                        style: TextStyle(
//                                            color: Colors.white,
//                                            fontFamily: "opensan",
//                                            fontSize: 20,
//                                            fontWeight: FontWeight.bold,
//                                            fontStyle: FontStyle.italic),
//                                      )
//                                    ],
//                                  ),
//                                ),
//                              ),
//                              Align(
//                                alignment: Alignment.centerLeft,
//                                child: new Container(
//                                  padding: EdgeInsets.only(bottom: 5),
//                                  child: new Row(
//                                    children: <Widget>[
//                                      new Container(
//                                        padding: EdgeInsets.only(right: 5),
//                                        child: Icon(
//                                          FontAwesomeIcons.check,
//                                          color: Colors.white,
//                                          size: 15,
//                                        ),
//                                      ),
//                                      Text(
//                                        "Avilable from 7am to 9pm all days",
//                                        style: TextStyle(
//                                            color: Colors.white,
//                                            fontFamily: "opensan",
//                                            fontStyle: FontStyle.italic,
//                                            fontSize: 15),
//                                      )
//                                    ],
//                                  ),
//                                ),
//                              ),
//                              Align(
//                                alignment: Alignment.centerLeft,
//                                child: new Container(
//                                  padding: EdgeInsets.only(bottom: 5),
//                                  child: new Row(
//                                    children: <Widget>[
//                                      new Container(
//                                        padding: EdgeInsets.only(right: 5),
//                                        child: Icon(
//                                          FontAwesomeIcons.check,
//                                          color: Colors.white,
//                                          size: 15,
//                                        ),
//                                      ),
//                                      Text(
//                                        "No mess after hair cut",
//                                        style: TextStyle(
//                                            color: Colors.white,
//                                            fontFamily: "opensan",
//                                            fontStyle: FontStyle.italic,
//                                            fontSize: 15),
//                                      )
//                                    ],
//                                  ),
//                                ),
//                              )
//                            ],
//                          ),
//                        ),
//                      ),
//                    ),
//                  ),
//                  SliverPadding(
//                      padding: EdgeInsets.only(top: 20),
//                      sliver: SliverToBoxAdapter(
//                        child: new Container(
//                          padding: EdgeInsets.only(
//                              right: 18, left: 18, top: 20, bottom: 10),
//                          decoration: BoxDecoration(color: Colors.white),
//                          child: new Column(
//                            children: <Widget>[
//                              new Container(
//                                child: new Center(
//                                  child: Text(
//                                    "Customer Reviews",
//                                    style: TextStyle(
//                                        color: Color.fromRGBO(67, 91, 111, 1),
//                                        fontSize: 22,
//                                        fontFamily: "opensan",
//                                        fontWeight: FontWeight.w600),
//                                  ),
//                                ),
//                              ),
//                            ],
//                          ),
//                        ),
//                      )),
//                  _listReviews(),
                ],
              ),
            ),
            Positioned(
              top: 0,
              bottom: 0,
              left: 0,
              right: 0,
              child: loading == true
                  ? new Container(
                color: Colors.white.withOpacity(0.8),
                child: new Center(
                  child: new Container(
                    // color: Colors.black26,
                    width: 200,
                    height: 200,
//                    child: FlareActor(
//                      "assets/animations/loadKnife.flr",
//                      animation: "Untitled",
//                      // color: Colors.blueAccent.withOpacity(0.5),
//                      // isPaused: true,
//                    ),
                  ),
                ),
              )
                  : new Container(),
            )
          ],
        ),
        bottomNavigationBar: _showPay(),
      ),
    );
  }

  _showPay() {
    return FutureBuilder(
      future: cart,
      builder: (context, snapshot){
        // print("Cart value: "+snapshot.data.length.toString());
        if(snapshot.data.length == 0){
          return Container(
              height: 0
          );
        }else{
          return new Container(
            height: 60,
            padding: EdgeInsets.only(top: 5, left: 5, right: 5, bottom: 5),
            color: Colors.white,
            child: FlatButton(
              splashColor: Colors.blueAccent,
              color: Colors.black,

              onPressed: () {
                // setState(() => loading = true);
                if(loading == true){

                }else{
                  Navigator.push(context, EnterExitRoute(enterPage: FinalbillPage(vendorid: widget.vendorid,)));
                }
              },
              child:new Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  new Row(
                    children: <Widget>[
                      new Container(
                        padding: EdgeInsets.only(
                            right: 10
                        ),
                        child: new CircleAvatar(
                          radius: 15,
                          backgroundColor: Colors.red,
                          child: new Text(
                            snapshot.data.length.toString(),
                            style: TextStyle(
                                fontFamily: "opensan",
                                fontWeight: FontWeight.bold,
                                color: Colors.white
                            ),
                          ),
                        ),
                      ),
                      new Container(
                        child: Text(
                          qty != '1'?"Items":"Item",
                          style: TextStyle(
                              color : Colors.white
                          ),
                        ),
                      )
                    ],
                  ),
                  new Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      new Padding(
                        padding: EdgeInsets.only(
                            right: 10
                        ),
                        child: Text(
                          "Continue",
                          style: TextStyle(
                              color: Colors.white, fontFamily: "opensan", fontSize: 15,fontWeight:FontWeight.bold),
                        ),
                      ),
                      new Icon(FontAwesomeIcons.arrowRight, color: Colors.white)
                    ],
                  )
                ],
              ),
            ),
          );
        }
        return Container(
          height: 0
        );
      },
    );
    if (shows == false) {
      return new Container(
        height: 60,
        padding: EdgeInsets.only(top: 5, left: 5, right: 5, bottom: 5),
        color: Colors.white,
        child: FlatButton(
          splashColor: Colors.blueAccent,
          color: Colors.black,

          onPressed: () {
            // setState(() => loading = true);
            if(loading == true){

            }else{
              Navigator.push(context, EnterExitRoute(enterPage: FinalbillPage()));
            }
          },
          child:new Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              new Row(
                children: <Widget>[
                  new Container(
                    padding: EdgeInsets.only(
                        right: 10
                    ),
                    child: new CircleAvatar(
                      radius: 15,
                      backgroundColor: Colors.red,
                      child: new Text(
                        "1",
                        style: TextStyle(
                            fontFamily: "opensan",
                            fontWeight: FontWeight.bold,
                            color: Colors.white
                        ),
                      ),
                    ),
                  ),
                  new Container(
                    child: Text(
                      qty != '1'?"Items":"Item",
                      style: TextStyle(
                          color : Colors.white
                      ),
                    ),
                  )
                ],
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  new Padding(
                    padding: EdgeInsets.only(
                        right: 10
                    ),
                    child: Text(
                      "Continue",
                      style: TextStyle(
                          color: Colors.white, fontFamily: "opensan", fontSize: 15),
                    ),
                  ),
                  new Icon(FontAwesomeIcons.arrowRight, color: Colors.white)
                ],
              )
            ],
          ),
        ),
      );
    }
    else if (shows == false) {
      return null;
    }
  }

  _listReviews() {
    return SliverList(
      delegate: SliverChildBuilderDelegate(
            (BuildContext context, int index) {
          return new Container(
              child: Container(
                color: Colors.white,
                child: new ListTile(
                  leading: new Container(
                    width: 30,
                    height: MediaQuery.of(context).size.height,
                    child: new Align(
                      alignment: Alignment.topRight,
                      child: Text(
                        "Mr",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontFamily: "opensan",
                        ),
                      ),
                    ),
                  ),
                  title: new Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        "Customer name",
                        style: TextStyle(
                            fontFamily: "opensan",
                            color: Color.fromRGBO(67, 91, 111, 1),
                            fontWeight: FontWeight.bold),
                      ),
                      new Container(
                        padding: EdgeInsets.only(
                          top: 10,
                        ),
                        child: Align(
                          alignment: Alignment.centerRight,
                          child: Container(
                            padding: EdgeInsets.only(
                                left: 8, right: 8, top: 5, bottom: 5),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.all(Radius.circular(3)),
                                border: Border.all(
                                    color: Color.fromRGBO(238, 247, 250, 1)),
                                color: Color.fromRGBO(224, 247, 250, 1)),
                            child: Text(
                              "4.5",
                              style: TextStyle(
                                  fontFamily: "opensan",
                                  color: Color.fromRGBO(67, 91, 111, 1),
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                  subtitle: Padding(
                    padding: EdgeInsets.only(top: 10),
                    child: new Column(
                      children: <Widget>[
                        Text(
                          'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry',
                          style: TextStyle(
                            fontFamily: "noto",
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        new Padding(
                          padding: EdgeInsets.only(top: 10),
                          child: Divider(
                            color: Colors.grey,
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ));
        },

        /// Set childCount to limit no.of items
        childCount: 10,
      ),
    );
  }

  roundofPrice(price){
    var j = (double.parse(price)).round();
//    var i = j.round();
    return j.toString();
  }

}

class MySeparator extends StatelessWidget {
  final double height;
  final Color color;

  const MySeparator({this.height = 1, this.color = Colors.black});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final boxWidth = constraints.constrainWidth();
        final dashWidth = 2.5;
        final dashHeight = height;
        final dashCount = (boxWidth / (2 * dashWidth)).floor();
        return Flex(
          children: List.generate(dashCount, (_) {
            return SizedBox(
              width: dashWidth,
              height: dashHeight,
              child: DecoratedBox(
                decoration: BoxDecoration(color: color),
              ),
            );
          }),
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          direction: Axis.horizontal,
        );
      },
    );
  }
}
