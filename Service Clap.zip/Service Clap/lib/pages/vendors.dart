import 'dart:io';

import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:service_app/pages/categorydetail.dart';
import 'package:service_app/utils/apis.dart';
import 'package:shimmer/shimmer.dart';
import 'package:service_app/animators/navianimator.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class VendorsPage extends StatefulWidget{
  final subcatid;
  VendorsPage(this.subcatid);
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return VendorsLoader();
  }

}

class VendorsLoader extends State<VendorsPage>{

  bool loading = true;
  List cats=[];
  var catslength = 0;
  var datafound=0;

  Future getCategory() async {
    var url = Apis.BASE_URL + "Vendors";
    var data = {"subcategory_id":widget.subcatid};
    print(data);
    var res = await apiPostRequest(url,data);
    print(json.decode(res));
    if(json.decode(res)['status'].toString() == "0"){
      setState(() {
        datafound=2;

        loading = false;
      });
    }else{
      setState(() {
        cats = json.decode(res)['records'];
        catslength = cats.length;
        datafound=1;
        loading = false;
      });
    }
  }

  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  @override
  void initState(){
    super.initState();
    getCategory();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color.fromRGBO(243, 244, 251, 1),
        body: new Stack(
          children: <Widget>[
            new Container(
              child: new CustomScrollView(
                slivers: <Widget>[
                  SliverAppBar(
                    title: Text(
                      "All Vendors",
                      style: TextStyle(
                          color: Colors.black
                      ),
                    ),
                    backgroundColor: Colors.white,
                    leading: IconButton(
                      onPressed: (){
                        Navigator.pop(context);
                      },
                      icon: Icon(
                        FontAwesomeIcons.arrowLeft,
                        color: Colors.black,
                      ),
                    ),
                    elevation: 1,
                    pinned: true,
                  ),
                  SliverPadding(
                    padding: EdgeInsets.only(
                        top: 10
                    ),
                    sliver: _lists(),
                  ),

                ],
              ),
            ),
            Positioned(
                top: MediaQuery.of(context).size.height/13,
                bottom: 0,
                left: 0,
                right: 0,
                child: loading == true
                    ? Container(
                  padding: EdgeInsets.only(
                    left: 20,
                    right: 20,
                  ),
                  color: Colors.white,
                  child: Shimmer.fromColors(
                    baseColor: Colors.grey,
                    highlightColor: Colors.white,
                    child: new Column(
                      children: <Widget>[
                        Container(
                            padding: EdgeInsets.only(
                                top: 20
                            ),
                            child: new Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                new Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.black.withOpacity(0.3),
                                ),
                                new Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width/1.4,
                                  color: Colors.black.withOpacity(0.3),
                                )
                              ],
                            )
                        ),
                        Container(
                            padding: EdgeInsets.only(
                                top: 20
                            ),
                            child: new Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                new Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.black.withOpacity(0.3),
                                ),
                                new Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width/1.4,
                                  color: Colors.black.withOpacity(0.3),
                                )
                              ],
                            )
                        ),
                        Container(
                            padding: EdgeInsets.only(
                                top: 20
                            ),
                            child: new Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                new Container(
                                  height: 50,
                                  width: 50,
                                  color: Colors.black.withOpacity(0.3),
                                ),
                                new Container(
                                  height: 50,
                                  width: MediaQuery.of(context).size.width/1.4,
                                  color: Colors.black.withOpacity(0.3),
                                )
                              ],
                            )
                        )
                      ],
                    ),
                  ),
                )
                    : Container()),
            Positioned(
                top: MediaQuery.of(context).size.height/13,
                bottom: 0,
                left: 0,
                right: 0,
                child: datafound == 1
                    ? Container()
                    : datafound == 2 ?Container(
                    color: Colors.white,

                    child: Center(

                    child: Image(

                      image: AssetImage("assets/image/dd.jpeg"),
                     // width: 100,

                  ),)

                ):Container()
            ),

          ],
        ),
      ),
    );
  }

  _lists() {
    return SliverList(
      delegate: SliverChildBuilderDelegate(
            (BuildContext context, int index) {
          return new Container(
              child: Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border(
                        bottom: BorderSide(
                            color: Colors.black12
                        )
                    )
                ),
                padding: EdgeInsets.only(
                    top: 10,
                    bottom: 10
                ),
                child: Column(
                  children: [
                    new ListTile(

                       onTap: (){
//                         var name = cats[index]['category'];
////                         var id = cats[index]['cat_id'];
////                         var image = cats[index]['cimage'];
////                         showdet(name, id, image);

                          Navigator.push(context, EnterExitRoute(enterPage: CategorydetailPage(vendorid: cats[index]['vendor_id'],vendorname: cats[index]['name'], vendorimage: cats[index]['image'],)));

                       },
                      contentPadding: index == 0? EdgeInsets.only(
                          top: 20,
                          left: 18
                      ):null,
                      leading: new Container(
                        width: 50,
                        padding: EdgeInsets.only(
                            top: 10
                        ),
                        height: MediaQuery.of(context).size.height,
                        child: new Align(
                          alignment: Alignment.topRight,
                          child: Image(
                            image: NetworkImage(cats[index]['image']),
                          ),
                        ),
                      ),
                      title: Text(cats[index]['name'],
                        style: TextStyle(
                            fontFamily: "opensan",
                            color: Color.fromRGBO(67, 91, 111, 1),
                            fontWeight: FontWeight.bold
                        ),
                      ),

                    )
                  ],
                ),


              )
          );
        },
        /// Set childCount to limit no.of items
        childCount: catslength,
      ),
    );
  }

}