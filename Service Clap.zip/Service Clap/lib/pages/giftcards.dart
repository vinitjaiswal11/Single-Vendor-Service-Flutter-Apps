import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:flutter_icons/flutter_icons.dart';
import 'package:animated_text_kit/animated_text_kit.dart';

class GiftcradPage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return GiftcardLoader();
  }

}

class GiftcardLoader extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return GiftcardView();
  }

}

class GiftcardView extends State<GiftcardLoader>{
  var loading = false;
  var texts = [
    "Vouchers",
  ];


  Future _orders() async{
//    var sp = await SharedPreferences.getInstance();
//    var token = sp.getString("token");
    var url = "http://serveondoor.com/servernew/Restapi/voucher";

//    var map = Map<String, dynamic>();
    http.Response res = await http.post(url);

    print(res.body);
  }


  @override
  void initState(){
    super.initState();
    _orders();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color.fromRGBO(236, 239, 241, 1),
        body: new Container(
          child: new CustomScrollView(
            slivers: <Widget>[
              SliverAppBar(
//                title: Text(
//                  "Gift cards",
//                  style: TextStyle(
//                    fontFamily: "opensan",
//                    color: Colors.black
//                  ),
//                ),
                backgroundColor: Colors.white,
                leading: IconButton(
                  icon: Icon(
                    AntDesign.arrowleft,
                    color: Colors.black,
                  ),
                  onPressed: (){
                    Navigator.pop(context);
                  },
                ),
              ),
              new SliverToBoxAdapter(
                child: loading == false ?
                new Container(
                  child: new Column(
                    children: <Widget>[
                      new Container(
                        color: Colors.white,

                        child: new Center(
                          child: new Column(
                            children: <Widget>[
                              new Text(
                                  "SOD",
                                style: TextStyle(
                                  fontSize: 25.0,
                                  fontFamily: "opensan",
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black45
                                ),
                              ),
                              SizedBox(
                                width : 400,
                                child: TyperAnimatedTextKit(
                                    onTap: () {
                                      print("Tap Event");
                                    },
                                    text: texts,
                                    textStyle: TextStyle(
                                        fontSize: 40.0,
                                        fontFamily: "lobs",
                                      color: Color.fromRGBO(115, 158, 8, 1),
                                    ),
                                    textAlign: TextAlign.center,
                                    isRepeatingAnimation: false,
                                    displayFullTextOnTap: true,
                                    speed: Duration(milliseconds: 100),
                                    alignment: AlignmentDirectional.topStart, // or Alignment.topLeft
                                ),
                              ),
                              new Container(
                                padding: EdgeInsets.only(
                                    top: 20,
                                ),
                                child: new Divider(
                                  color: Colors.black,
                                  thickness: 3,
                                  height: 3,
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                      new Container(
                        padding: EdgeInsets.only(
                          top: 10,
                          left: 10,
                          right: 10
                        ),
                        child: new Container(
                          decoration: BoxDecoration(
                            color: Colors.blueAccent.withOpacity(0.15),
                            borderRadius: BorderRadius.all(
                              const Radius.circular(5)
                            ),
                            border: Border.all(
                              color: Colors.blueAccent
                            )
                          ),
                          child: new ListTile(
                            title: Text(
                              "My Vouchers",
                              style: TextStyle(
                                fontFamily: "opensan",
                                fontSize: 18,
                              ),
                            ),
                            trailing: new Container(
                              width : 120,
                              child: new Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: <Widget>[
                                  new Container(
                                    padding : EdgeInsets.only(
                                      right: 10
                                    ),
                                      child: Text(
                                        "0",
                                        style: TextStyle(
                                            fontFamily: "opensan",
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 18
                                        ),
                                      )
                                  ),
                                  new Container(
                                      child: new InkWell(
                                        child: new Icon(
                                          AntDesign.rightcircle,
                                          color:Colors.black
                                        ),
                                      )
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ):new Container(),
              )
            ],
          ),
        ),
      ),
    );
  }

}