import 'package:flutter/material.dart';
import 'package:service_app/animators/navianimator.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'dart:io';
import 'package:google_maps_webservice/places.dart';
import 'package:geocoder/geocoder.dart';
import 'package:service_app/pages/locations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:service_app/pages/mainpage.dart';
import 'package:service_app/pages/location.dart';

class SetlocationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SetlocationLoader();
  }
}

class SetlocationLoader extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return SetlocationView();
  }
}

class SetlocationView extends State<SetlocationLoader> {

  Future getCurrentLocation() async {
    var sp = await SharedPreferences.getInstance();
    Position position = await Geolocator()
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    var lattitude = position.latitude;
    var longitude = position.longitude;
    final coordinates = new Coordinates(lattitude, longitude);
    var addresses =
        await Geocoder.local.findAddressesFromCoordinates(coordinates);
    var first = addresses.first;
    print("${first.featureName} : ${first.addressLine}");
    setState(() {
      var locations = first.addressLine.trimRight();
      sp.setString("location", locations);
      sp.setString("lat", lattitude.toString());
      sp.setString("log", longitude.toString());
    });
    Navigator.of(context).pushAndRemoveUntil(
          FadeRoute(page: MainpagePage(pageview: 0)), (Route<dynamic> route) => false);
//      Navigator.push(context, EnterExitRoute(enterPage: MainpagePage(pageview: 0,)));
  }

  Future setLoc() async{
    var sp = await SharedPreferences.getInstance();
    var loc = sp.getString("location");
    if(sp.containsKey("location")){
      Navigator.of(context).pushAndRemoveUntil(
          FadeRoute(page: MainpagePage(pageview: 0)), (Route<dynamic> route) => false);
    }else{

    }
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
          body: new Container(
            color: Colors.white,
        child: new Stack(
          children: <Widget>[
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              child: Image(
                image: AssetImage("assets/icons/location.png"),
                width: 100,
                height: 100,
                color: Colors.blueAccent.withOpacity(0.5),
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              top: 203,
              child: new Container(
                child: new Center(
                  child: new Container(
                    width: 220,
                    height: 220,
                    decoration: BoxDecoration(
                      color: Color.fromRGBO(224,247,250 ,1),
                      borderRadius: BorderRadius.all(
                        Radius.circular(200)
                      ),
                      border: Border.all(
                        color: Colors.white,
                        width: 10
                      )
                    ),
                    child: Center(
                      child: Image(
                        image: AssetImage("assets/image/city.png"),
                        // width: MediaQuery.of(context).size.width/1.25,
                        height: 150,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            
            Positioned(
              bottom: 0,
              child: new Container(
                width: MediaQuery.of(context).size.width,
                height: 120,
                padding: EdgeInsets.only(left: 20, right: 20,bottom: 10),
                child: new Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    SizedBox(
                      height: 50,
                      child: FlatButton(
                        color: Colors.black,
                        splashColor: Colors.blueGrey,
                        onPressed: () {
                          getCurrentLocation();
                        },
                        child: new Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            new Padding(
                              padding: EdgeInsets.only(right: 10),
                              child: Icon(
                                Icons.my_location,
                                color: Colors.white,
                              ),
                            ),
                            new Text(
                              "My Location",
                              style: TextStyle(
                                  color: Colors.white, 
                                  fontFamily: "opensan",
                                  fontWeight: FontWeight.bold
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 50,
                      child: FlatButton(
                        color: Colors.blueAccent,
                        splashColor: Colors.blueGrey,
                        onPressed: () {
                          Navigator.push(context, EnterExitRoute(enterPage: LocationPage())).then((value){
                            setLoc();
                          });
                        },
                        child: new Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            new Padding(
                              padding: EdgeInsets.only(right: 10),
                              child: Icon(
                                Icons.location_on,
                                color: Colors.white,
                              ),
                            ),
                            new Text(
                              "Enter Location",
                              style: TextStyle(
                                  color: Colors.white, 
                                  fontFamily: "opensan",
                                  fontWeight: FontWeight.bold
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      )),
    );
  }
}
