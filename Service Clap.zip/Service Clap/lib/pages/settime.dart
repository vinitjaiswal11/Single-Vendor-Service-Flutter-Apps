import 'package:flutter/material.dart';
import 'package:service_app/animators/navianimator.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_sticky_header/flutter_sticky_header.dart';
import 'package:service_app/pages/payment.dart';
import 'package:service_app/pages/addressadd.dart';
import 'package:intl/intl.dart';
import 'dart:core';
import 'package:service_app/pages/alladdress.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
//import 'package:flare_flutter/flare_actor.dart';
import 'dart:async';
import 'dart:convert';
import 'package:service_app/pages/test.dart';
import 'dart:math' as Math;
import 'dart:io';
import 'package:service_app/utils/apis.dart';
import 'package:service_app/database/vendorcart.dart';
import 'package:service_app/database/vendordb_helper.dart';

class SettimePage extends StatelessWidget {
  final vendorid;
  final price;
  SettimePage({Key key,this.vendorid,this.price}):super(key : key);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SettimeLoader(vendorid: this.vendorid,price: this.price);
  }
}

class SettimeLoader extends StatefulWidget {
  final vendorid;
  final price;
  
  SettimeLoader({Key key,this.vendorid,this.price}):super(key : key);
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return SettimeView();
  }
}

class SettimeView extends State<SettimeLoader> {

  Future<List<Vendorcart>> cart;
  Future<dynamic> price;
  var dbHelper;
  var cartlen = 0;

  var loading = false;
  var timeind;

  var addressname = "";
  var addressid = "";
  getAddress() async{
    var sp = await SharedPreferences.getInstance();
    if(sp.containsKey("addressid")){
      setState((){
        addressname = sp.getString("addressname");
        addressid = sp.getString("addressid");
      });
      print(addressname);
    }else{

    }
    
  }

  List datestime = [];
  var dateslen = 0;
  var timeindex = 0;
  var dateindex = 0;

  getTimes() async{
    var url = Apis.BASE_URL + "Vendors/timeSlots";
    var data = {"vendor_id":widget.vendorid};
    var res = await apiPostRequest(url,data);
    print(res);
    setState(() {
      datestime = json.decode(res)['records'];
      selected_date = json.decode(res)['records'][0]['date'];
      dateslen = datestime.length;
    });
  }

  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  var selected_date = "";
  var selected_time = "";
  var finaldatetime = "";
  var selected_date_ime = "";

  selectDate(index,date) async{
    setState(() {
      timeindex = index;
      dateindex = index;
      selected_date = date;
      slecttime_index = null;
      selected_time = "";
    });
  }

  var slecttime_index;

  selectTime(index,time) async{
    setState(() {
      selected_time = time;
      slecttime_index = index;
    });
  }

  refreshList() {
    setState(() {
      cart = dbHelper.getCart(int.parse(widget.vendorid));
    });
  }
  
  getPrice(){
    setState(() {
      price = dbHelper.getPrice(int.parse(widget.vendorid));
    });
  }

  var cartprice = "";
  var mrp = "";

  setCartprice(price,mrps){
    setState((){
      cartprice = price;
      mrp = mrps;
    });
  }
  
  @override
  void initState() {
    super.initState();
    getTimes();
    dbHelper = VendorDbHelper();
    getPrice();
    refreshList();
    getAddress();
    // print("Cartid : "+widget.cartid.toString());
    // todaysDate();
    // getdates();
    // getAddress();
    // getTimes();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "Set service timming",
            style: TextStyle(color: Colors.black),
          ),
          backgroundColor: Colors.white,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              FontAwesomeIcons.arrowLeft,
              color: Colors.black,
            ),
          ),
          elevation: 0.5,
        ),
        body: Stack(
          children: <Widget>[
            new Container(
              child: CustomScrollView(
                slivers: <Widget>[
                  SliverStickyHeader(
                      header: new Container(
                        height: 60,
                        // padding: EdgeInsets.only(
                        //   left: 20
                        // ),
                        decoration: BoxDecoration(boxShadow: [
                          BoxShadow(blurRadius: 2, color: Colors.grey)
                        ]),
                        child: new ListView.builder(
                          itemCount: dateslen,
                          scrollDirection: Axis.horizontal,
                          itemBuilder: (BuildContext ctx, int index) {
                            return new Material(
                              color:
                              dateindex== index
                                  ? Colors.blueAccent
                                  :
                              Colors.blue[50],
                              child: InkWell(
                                onTap: (){
                                  selectDate(index,datestime[index]['date'].toString());
                                },
                                child: Container(
                              height: MediaQuery.of(context).size.height,
                              // width: 100,
                              padding: EdgeInsets.only(left: 15, right: 15),
                              child: new Center(
                                child: new Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    new Center(
                                      child: new Text(
                                        getdates(datestime[index]['date'].toString()),
                                        // dates[index].toString().substring(0,3),
                                        style: TextStyle(
                                            color:
                                            dateindex == index
                                                ? Colors.white
                                                :
                                            Colors.black,
                                            fontSize: 17,
                                            fontFamily: "opensan",
                                            fontWeight: FontWeight.bold  
                                          ),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                    new Center(
                                      child: new Text(
                                       getdays(datestime[index]['date'].toString()),// dates[index].toString().substring(4),
                                        style: TextStyle(
                                            color:
                                            dateindex == index
                                                ? Colors.white
                                                :
                                            Colors.black,
                                            fontSize: 17,
                                            fontFamily: "opensan"),
                                        textAlign: TextAlign.center,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                              ),
                            );
                          },
                        ),
                      ),
                      sliver: SliverPadding(
                        padding: EdgeInsets.only(
                            top: 10, left: 20, right: 20, bottom: 10),
                        sliver: new SliverGrid(
                          gridDelegate:
                              SliverGridDelegateWithMaxCrossAxisExtent(
                            maxCrossAxisExtent: 200.0,
                            mainAxisSpacing: 5.0,
                            crossAxisSpacing: 5.0,
                            childAspectRatio: 3.0,
                          ),
                          delegate: SliverChildBuilderDelegate(
                            (BuildContext context, int index) {
                              return Container(
                                decoration: BoxDecoration(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(5)),
                                    border: Border.all(
                                        color: Colors.grey.withOpacity(0.2))),
                                child: Material(
                                  color: slecttime_index == index ? Colors.blueAccent:Colors.blue[50].withOpacity(0.2),
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(5)),
                                  child: InkWell(
                                    splashColor:
                                        Color.fromRGBO(79, 195, 247, 1),
                                    focusColor: Color.fromRGBO(79, 195, 247, 1),
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(5)),
                                    highlightColor: Colors.black,
                                    onTap: () {
                                      selectTime(index,datestime[timeindex]['timeslots'][index]);
                                    },
                                    child: new Center(
                                      child: new Text(
                                        // times[index+indplu].toString().substring(0,2) == '13' ? "1:"+times[index].toString().substring(3)+" pm":
                                        // times[index+indplu].toString().substring(0,2) == '14' ? "2:"+times[index].toString().substring(3)+" pm":
                                        // times[index+indplu].toString().substring(0,2) == '15' ? "3:"+times[index].toString().substring(3)+" pm":
                                        // times[index+indplu].toString().substring(0,2) == '16' ? "4:"+times[index].toString().substring(3)+" pm":
                                        // times[index+indplu].toString().substring(0,2) == '17' ? "5:"+times[index].toString().substring(3)+" pm":
                                        // times[index+indplu].toString().substring(0,2) == '18' ? "6:"+times[index].toString().substring(3)+" pm":
                                        // times[index+indplu].toString().substring(0,2) == '19' ? "7:"+times[index].toString().substring(3)+" pm":
                                        // times[index+indplu].toString().substring(0,2) == '20' ? "8:"+times[index].toString().substring(3)+" pm":
                                        // times[index+indplu].toString().substring(0,2) == '21' ? "9:"+times[index].toString().substring(3)+" pm":
                                        // times[index+indplu].toString().substring(0,2) == '12' ? times[index].toString()+" pm":
                                        // times[index+indplu].toString()+" am",
                                        datestime[timeindex]['timeslots'][index],
                                        
                                        style: TextStyle(
                                            fontFamily: "opensan",
                                            fontSize: 17,
                                            fontWeight: FontWeight.bold,
                                            color: slecttime_index == index ? Colors.white :Colors.black54
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                            childCount: datestime[timeindex]['timeslots'].length
                          ),
                        ),
                      ))
                ],
              ),
            ),
            Positioned(
              top: 0,
              bottom: 0,
              left: 0,
              right: 0,
              child: loading == true
                  ? new Container(
                      color: Colors.white.withOpacity(0.8),
                      child: new Center(
                        child: new Container(
                          // color: Colors.black26,
                          width: 200,
                          height: 200,
//                          child: FlareActor(
//                            "assets/animations/loadKnife.flr",
//                            animation: "Untitled",
//                            // color: Colors.blueAccent,
//                            // isPaused: true,
//                          ),
                        ),
                      ),
                    )
                  : new Container(),
            )
          ],
        ),
        bottomNavigationBar: new Container(
          color: Colors.white,
          height: 120,
          child: new Column(
            children: <Widget>[
              new Container(
                decoration: BoxDecoration(
                    color: Color.fromRGBO(236, 239, 241, 1),
                    boxShadow: [BoxShadow(blurRadius: 1, color: Colors.grey)]),
                height: 70,
                width: MediaQuery.of(context).size.width,
                child: new Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    new Container(
                      padding: EdgeInsets.only(
                          left: 20, right: 20, bottom: 5, top: 10),
                      child: Text("Dilevered to this address"),
                    ),
                    new Container(
                      padding: EdgeInsets.only(
                          left: 20, bottom: 5, top: 5, right: 20),
                      child: new Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          new Flexible(
                            child: new Row(
                            children: <Widget>[
                              new Container(
                                padding: EdgeInsets.only(right: 10),
                                child: Icon(
                                  FontAwesomeIcons.home,
                                  size: 20,
                                  color: Colors.indigo,
                                ),
                              ),
                              Flexible(
                                flex: 1,
                                child: Text(
                                  " $addressname",
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.indigo),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              )
                            ],
                          ),
                          ),
                          Material(
                            color: Color.fromRGBO(216, 67, 21, 1),
                            borderRadius: BorderRadius.all(Radius.circular(3)),
                            child: new InkWell(
                              onTap: () async {
                                await Navigator.push(context,
                                        EnterExitRoute(enterPage: AllAddress()))
                                    .then((value) {
                                  getAddress();
                                });
                              },
                              child: Padding(
                                padding: EdgeInsets.only(
                                    left: 5, right: 5, bottom: 5, top: 5),
                                child: Text(
                                  "Change",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
              new Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(left: 20),
                    child: FutureBuilder(
                        future: price,
                        builder : (context, snapshot){
                          
                          if(snapshot.data != null){
                            
                            return snapshot.data[0]['Price'].toString() != "null"
                                ?new Container(
                              color: Colors.white,
                              child: new Text(
                                          "\u20B9 "+snapshot.data[0]['discount_price'].toString(),
                                          style: TextStyle(
                                              fontFamily: "opensan",
                                              fontSize: 17,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black),
                                        ),
                            )
                                :Container();
                          }
                          else if(snapshot.data == null){
                            return new  Container(
                              height: 10,
                            );
                          }
                          return new  Container(
                            height: 10,
                          );
                        },
                      ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(right: 20,top: 2),
                    child: new FlatButton(
                      color: timeind != null ?Colors.blueAccent:Colors.black38,
                      onPressed: (){
                        if(addressid == ""){

                        }else{
                          Navigator.push(context,
                                      EnterExitRoute(enterPage: PaymentsPage(vendorid: widget.vendorid,dateget: selected_date.toString(),time: selected_time.toString(),priceget: widget.price,mrp: mrp,)));
                        }
                      },
                      child: Text(
                        "Continue",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: Colors.white
                        ),
                      ),
                    ),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  getdates(String text) {
    var string = text;
//    var now = new DateTime.now();
    var formatter = new DateFormat('E');
    String formatted = formatter.format(DateTime.parse(string));
    return formatted.toUpperCase();
  }

  getdays(String text) {
    var string = text;
//    var now = new DateTime.now();
    var formatter = new DateFormat('d MMM');
    String formatted = formatter.format(DateTime.parse(string));
    return formatted.toUpperCase();
  }

}
