import 'package:flutter/material.dart';
import 'package:service_app/animators/navianimator.dart';
import 'package:http/http.dart' as http;
//import 'package:flare_flutter/flare_actor.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import 'dart:convert';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:flutter_icons/flutter_icons.dart';
import 'package:service_app/utils/apis.dart';
import 'dart:io';
import 'package:intl/intl.dart';
import 'dart:core';

class WallethistoryPage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return WallethistoryLoader();
  }

}

class WallethistoryLoader extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return WallethistoryView();
  }

}

class WallethistoryView extends State<WallethistoryLoader>{
  List history = [];
  var histlen = 0;
  Future _recharge() async{
    var url = Apis.BASE_URL+"Wallet";
    var sp = await SharedPreferences.getInstance();
    var userid = sp.getString("userid");
    var data = {
      "user_id":userid
    };
    var res = await apiPostRequest(url ,data);
    setState(() {
      history = json.decode(res)['result'];
      histlen = history.length;
    });
    print(json.decode(res));
//    Navigator.pop(context);
  }

  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  @override
  void initState(){
    super.initState();
    _recharge();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color.fromRGBO(236, 239, 241, 1),
        body: new Container(
          child: new CustomScrollView(
            slivers: <Widget>[
              SliverAppBar(
                backgroundColor: Colors.black,
                leading: IconButton(
                  onPressed: (){
                    Navigator.pop(context);
                  },
                  icon: Icon(
                    AntDesign.arrowleft,
                    color: Colors.white,
                  ),
                ),
                title: Text(
                  "History",
                  style: TextStyle(
                    fontFamily: "opensan",
                    color: Colors.white
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: new ListView.builder(
                    itemCount: histlen,
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemBuilder:  (context, int i) {
                      return new Container(
                        color: Colors.white,
                        child: Column(
                          children: <Widget>[
                            ListTile(
                              title: Text(
                                "Ordering Service",
                                style: TextStyle(
                                    fontFamily: "opensan"
                                ),
                              ),
                              subtitle: Text(
                                "Debit",
                                style: TextStyle(
                                    fontFamily: "opensan"
                                ),
                              ),
                              trailing: Text(
                                "\u20B9 200",
                                style: TextStyle(
                                    fontFamily: "opensan",
                                    fontWeight: FontWeight.bold,
                                    fontSize: 17
                                ),
                              ),
                              leading: Icon(
                                AntDesign.wallet
                              ),
                            ),
                            new Container(
                              child: i == histlen-1 ? Container() :  Divider(),
                            )
                          ],
                        )
                      );
                    },
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

}
