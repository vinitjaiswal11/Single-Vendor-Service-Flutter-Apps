import 'package:flutter/material.dart';
import 'package:service_app/animators/navianimator.dart';
import 'package:service_app/pages/mainpage.dart';
class Splashscreen extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return SplashsreenView();
  }


}
class SplashsreenView extends State<Splashscreen>{

  redirectAfter() async{
    new Future.delayed(Duration(seconds: 4),(){
      Navigator.of(context).pushAndRemoveUntil(
          SlideTopRoute(page: MainpagePage(pageview: 0,)), (Route<dynamic> route) => false);
//      Navigator.push(context, SlideTopRoute(page: MainpagePage(pageview: 0,)));
    });
  }

  @override
  void initState(){
    super.initState();
    redirectAfter();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          // child: SizedBox(
          //   width: 30,
          //   height: 30,
          //   child: CircularProgressIndicator(),
          // ),
          child: Image(
              image : AssetImage("assets/image/logo.png"),
              width: 160,
            height: 160,
          ),
        ),
      ),
    );
  }

}