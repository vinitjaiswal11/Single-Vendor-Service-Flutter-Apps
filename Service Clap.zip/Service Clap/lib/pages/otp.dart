import 'package:flutter/material.dart';
import 'package:sms_autofill/sms_autofill.dart';
import 'package:pin_input_text_field/src/decoration/pin_decoration.dart';
import 'dart:async';
import 'dart:convert';
import 'package:service_app/animators/navianimator.dart';
import 'package:service_app/pages/mainpage.dart';
import 'package:http/http.dart' as http;
//import 'package:flare_flutter/flare_actor.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';
import 'package:service_app/pages/setlocation.dart';


class OtpPage extends StatelessWidget {
  final mobile;
  OtpPage({Key key, this.mobile}) : super(key:key);
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return OtpLoader(mobile: this.mobile);
  }
}

class OtpLoader extends StatefulWidget {
  final mobile;
  OtpLoader({Key key,this.mobile}): super(key : key);
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return OtpView();
  }
}

class OtpView extends State<OtpLoader> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  var pincode = TextEditingController();
  bool login = false;

  var otptext = TextEditingController();

  bool loading = false;

  Future matchOtp() async {
    setState(() {
      loading = true;
      login = true;
    });
    var sp = await SharedPreferences.getInstance();
    var token = sp.getString("token");
    var map = Map<String, dynamic>();
    map['otp'] = otptext.text;
    map['mobile'] = widget.mobile;
    print(token);
    var url = "http://serveondoor.com/servernew/Restapi/otpmatch";
    http.Response res =
        await http.post(url, body: map);
    print(res.body.toString());
    if (json.decode(res.body)['statusCode'] == 200) {
      setState(() {
        loading = false;
        login = false;
        sp.setString("token", json.decode(res.body)['result']['token'].toString());
      });
      if(json.decode(res.body)['result']['status'].toString() == "2"){
//          Navigator.of(context).pushAndRemoveUntil(
//          FadeRoute(page: MainpagePage()), (Route<dynamic> route) => false);
        Navigator.of(context).pushAndRemoveUntil(
            FadeRoute(page: SetlocationPage()), (Route<dynamic> route) => false);
      }else{
          Navigator.of(context).pushAndRemoveUntil(
          FadeRoute(page: SetlocationPage()), (Route<dynamic> route) => false);
      }
    } else {
      setState(() {
        loading = false;
        login = false;
      });
      showInSnackBar();
    }
  }

  void showInSnackBar() {
    _scaffoldKey.currentState.showSnackBar(
      new SnackBar(
        content: new Text(
          "Wrong OTP Enterd",
          style: TextStyle(
            fontFamily: "opensan",
            fontWeight: FontWeight.bold
          ),
          textAlign: TextAlign.center,
        ),
        backgroundColor: Colors.redAccent,
      )
    );
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
        child: Scaffold(
          key: _scaffoldKey,
      backgroundColor: Colors.white,
      body: new CustomScrollView(
        slivers: <Widget>[
          SliverAppBar(
            elevation: 0,
            backgroundColor: Colors.white,
          ),
          SliverToBoxAdapter(
            child: new Container(
              padding: EdgeInsets.only(left: 20, right: 20, bottom: 20),
              child: new Center(
                child: new Text(
                  "Varify your mobile number!",
                  style: TextStyle(
                    color: Colors.blue,
                    fontFamily: "opensan",
                    fontSize: 15,
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: new Container(
              padding: EdgeInsets.only(left: 20, right: 20, bottom: 20),
              child: new Center(
                child: new Text(
                  "We have sent an OTP on your number +91 "+widget.mobile,
                  style: TextStyle(
                    color: Colors.black,
                    fontFamily: "opensan",
                    fontSize: 16,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ),
          // SliverToBoxAdapter(
          //   child: new Container(
          //     padding: EdgeInsets.only(left: 20, right: 20),
          //     child: new Column(
          //       children: <Widget>[
          //         new Container(
          //           // height: 70,
          //           padding: EdgeInsets.only(
          //             left: 30,
          //             right: 30,
          //             bottom: 20
          //           ),
          //           decoration: BoxDecoration(
          //             // color: Colors.white,
          //             borderRadius: BorderRadius.all(
          //               Radius.circular(120)
          //             )
          //           ),
          //           child: Center(
          //             child: PinFieldAutoFill(
          //               codeLength: 4,
          //               decoration: BoxLooseDecoration(
          //                 enteredColor: Colors.green,
          //                 solidColor: Color.fromRGBO(225,245,254 ,0.3),
          //                 strokeColor: Colors.blue,
          //                 textStyle: TextStyle(
          //                   fontFamily: "opensan",
          //                   color: Color.fromRGBO(225,245,254 ,1),
          //                   fontSize: 20,
          //                   fontWeight: FontWeight.bold
          //                 ),
          //                 gapSpace: 30.0,
          //                 strokeWidth: 1
          //               ),
          //               onCodeSubmitted: (String otp){
          //                 print(otp);
          //               },
          //               key: _picode,
          //             ),
          //           ),
          //         ),
          //       ],
          //     ),
          //   ),
          // ),
          SliverToBoxAdapter(
            child: new Container(
                padding: EdgeInsets.only(left: 20, right: 20),
                child: new TextField(
                  controller: otptext,
                  textAlign: TextAlign.center,
                  keyboardType: TextInputType.number,
                  style: TextStyle(fontSize: 20, fontFamily: "opensan"),
                )),
          ),
          SliverToBoxAdapter(
            child: new Container(
              padding:
                  EdgeInsets.only(left: 20, right: 20, bottom: 20, top: 20),
              child: new Center(
                child: login == false
                    ? ButtonBar(
                        children: <Widget>[
                          new FlatButton(
                            color: Colors.blueAccent,
                            onPressed: () async {
                              matchOtp();
                            },
                            child: Text(
                              "Confirm",
                              style: TextStyle(color: Colors.white),
                            ),
                          )
                        ],
                      )
                    : Container(
                        width: 80,
                        height: 80,
//                        child: FlareActor(
//                          "assets/animations/Liquid_Loader2.flr",
//                          animation: "Untitled",
//                          color: Colors.black.withOpacity(0.3),
//                        ),
                      ),
              ),
            ),
          )
        ],
      ),
    ));
  }
}
