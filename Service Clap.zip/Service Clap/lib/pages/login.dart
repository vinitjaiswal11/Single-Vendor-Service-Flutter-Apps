import 'package:flutter/material.dart';
import 'package:service_app/pages/home.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
//import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
import 'package:service_app/pages/home.dart';
import 'package:service_app/animators/navianimator.dart';
import 'package:service_app/pages/mainpage.dart';
import 'package:service_app/pages/otp.dart';
import 'package:http/http.dart' as http;
//import 'package:flare_flutter/flare_actor.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:country_icons/country_icons.dart';

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return LoginLoader();
  }
}

class LoginLoader extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return LoginpageView();
  }
}

class LoginpageView extends State<LoginLoader> {
  var mobile = TextEditingController();
  bool loading = false;
  bool ani = false;
  Color _color = Colors.black.withOpacity(0.3);
  bool fail;

  Future getLogin() async {
    var sp = await SharedPreferences.getInstance();
    setState(() {
      loading = true;
      ani = false;
      fail = false;
      _color = Colors.black.withOpacity(0.3);
    });
    var url = "http://serveondoor.com/servernew/Restapi/login";
    var map = Map<String, dynamic>();
    map['mobile'] = "91"+mobile.text;
    http.Response res = await http.post(url, body: map);
    // print(json.decode(res.body)['result']['token']);
    if (json.decode(res.body)['statusCode'] == 400) {
      print("Wrong mobile no");
      setState(() {
        _color = Colors.redAccent.withOpacity(0.3);
        fail = true;
        ani = true;
      });
    } else {
      setState(() {
        loading = false;
        fail = false;
        // sp.setString("token", json.decode(res.body)['result']['token'].toString());
      });
      Navigator.push(context, EnterExitRoute(enterPage: OtpPage(mobile: mobile.text,)));
    }
  }



  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: new Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/image/banner.jpg"),
              fit: BoxFit.cover
            )
          ),
          child: Container(
            color: Colors.white,
          child: Stack(
            children: <Widget>[
//               Positioned(
//                 width: 100,
//                 height: 100,
//                 top: 220.0,
//                 left: 0,
//                 child: new Container(
//                   height: 140,
//                   decoration: BoxDecoration(
//                     image: DecorationImage(
//                       image: AssetImage("assets/image/cut.png"),
//                     ),
// //                    color: Colors.black
//                   ),
//                 ),
//               ),
//               Positioned(
//                 width: 120,
//                 height: 120,
//                 top: 190.0,
//                 right: -20,
//                 child: new Container(
//                   height: 140,
//                   decoration: BoxDecoration(
//                     image: DecorationImage(
//                       image: AssetImage("assets/image/hammer.png"),
//                     ),
// //                    color: Colors.black
//                   ),
//                 ),
//               ),
//               Positioned(
//                 width: 100,
//                 height: 100,
//                 bottom: 10,
//                 left: 20,
//                 child: new Container(
//                   height: 250,
//                   decoration: BoxDecoration(
//                     image: DecorationImage(
//                       image: AssetImage("assets/image/screwdrive.png"),
//                     ),
// //                    color: Colors.black
//                   ),
//                 ),
//               ),
//               Positioned(
//                 width: 100,
//                 height: 100,
//                 top: -10,
//                 right: -10,
//                 child: new Container(
//                   height: 140,
//                   decoration: BoxDecoration(
//                     image: DecorationImage(
//                       image: AssetImage("assets/image/digger.png"),
//                     ),
// //                    color: Colors.black
//                   ),
//                 ),
//               ),
//               Align(
//                 alignment: Alignment.topCenter,
//                 child: new Container(
//                   height: 140,
// //                  width: 400,
//                   decoration: BoxDecoration(
//                     image: DecorationImage(
//                       image: AssetImage("assets/image/tools.png"),
//                     ),
// //                    color: Colors.black
//                   ),
//                 ),
//               ),
              new Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  new Hero(
                    tag: 'logo',
                    child: Container(
                      // height: 220,
                      child: Align(
                        alignment: Alignment.center,
                        child: Container(
                          width: 80,
                          height: 80,
                          child: Center(
                            child: Image(
                              image: AssetImage("assets/image/logo.png"),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  new Container(
                    padding: EdgeInsets.only(top: 20),
                    child: new Center(
                      child: new Text(
                        "Why to vist, We will visit",
                        style: TextStyle(
                            fontSize: 18, 
                            fontWeight: FontWeight.bold,
                            fontFamily: "opensan"
                        ),
                      ),
                    ),
                  ),
                  new Container(
                    padding: EdgeInsets.only(top: 5, bottom: 20),
                    width: 200,
                    child: new Center(
                      child: new Text(
                        "Fast & accurate service",
                        style: TextStyle(
                            fontSize: 18, 
                            // fontWeight: FontWeight.bold,
                            fontFamily: "opensan"
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                  new Container(
                    padding: EdgeInsets.only(left: 20, right: 20),
                    child: new Container(
                      height: 50,
                      decoration: BoxDecoration(
                          border:
                              Border.all(color: Colors.black.withOpacity(0.2)),
                          color: Colors.white.withOpacity(0.8),
                          borderRadius: BorderRadius.all(Radius.circular(6))),
                      child: new Row(
                        children: <Widget>[
                          Flexible(
                            flex: 3,
                            child: new Container(
//                              color: Colors.black,
                              height: MediaQuery.of(context).size.height,
                              width: 70,
                              decoration: BoxDecoration(
                                  border: Border(
                                      right: BorderSide(
                                          width: 1,
                                          color:
                                              Colors.black.withOpacity(0.2)))),
                              child: Center(
                                child: SizedBox(
                                  height: 20,
                                  child: Image.asset('icons/flags/png/in.png', package: 'country_icons'),
                                )
                              ),
                            ),
                          ),
                          Flexible(
                            flex: 2,
                            child: new TextField(
                              keyboardType: TextInputType.number,
                              controller: mobile,
                              decoration: InputDecoration(
                                  counterText: "",
                                  hintText: "Mobile Number",
                                  border: InputBorder.none,
                                  contentPadding: EdgeInsets.only(left: 10),
                                  hintStyle: TextStyle(
                                    fontFamily: "opensan",
                                    fontWeight: FontWeight.w400
                                  )
                              ),
                              style: TextStyle(
                                      color: Colors.black, 
                                      fontSize: 16,
                                      fontFamily: "opensan",
                                      fontWeight: FontWeight.bold
                                  ),
                              maxLength: 10,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  new Container(
                    padding: EdgeInsets.only(left: 20, right: 20, top: 20),
                    child: new SizedBox(
                      width: MediaQuery.of(context).size.width,
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: Material(
                          color: Color.fromRGBO(19, 211, 252, 1),
                          animationDuration: Duration(seconds: 1),
                          borderRadius: BorderRadius.all(Radius.circular(6)),
                          child: InkWell(
                            onTap: () {
                              // getLogin();
                              Navigator.of(context).pushAndRemoveUntil(FadeRoute(page: MainpagePage(pageview:0)), (Route<dynamic> route) => false);
                            },
                            borderRadius: BorderRadius.all(Radius.circular(6)),
                            child: Padding(
                              padding: EdgeInsets.only(
                                  top: 15, bottom: 15, left: 50, right: 50),
                              child: Text(
                                "Login / Sign up",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 16,
                                    fontFamily: "opensan"
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                child: loading == true
                    ? new Container(
                        color: Colors.white.withOpacity(0.9),
                        //  width: MediaQuery.of(context).size.width,
                        //  height : MediaQuery.of(context).size.height,
                        child: new Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              new Container(
                                // color: Colors.black26,
                                width: 150,
                                height: 150,
//                                child: FlareActor(
//                                  "assets/animations/Liquid_Loader2.flr",
//                                  animation: "Untitled",
//                                  color: _color,
//                                  isPaused: ani,
//                                ),
                              ),
                              new Container(
                                child: fail == true ? new Column(
                                  children: <Widget>[
                                    new Container(
                                      child: Center(
                                        child: Text(
                                          "Wrong Mobile number",
                                          style: TextStyle(
                                              fontFamily: "opensan",
                                              fontSize: 16,
                                              color: Color.fromRGBO(
                                                  198, 40, 40, 1),
                                              fontWeight: FontWeight.bold
                                          ),
                                        ),
                                      ),
                                    ),
                                    new Container(
                                      padding: EdgeInsets.only(
                                        top: 10
                                      ),
                                      child: Center(
                                        child: FlatButton(
                                          color: Color.fromRGBO(198, 40, 40, 1),
                                          onPressed: () {
                                            setState(() {
                                              loading = false;
                                            });
                                          },
                                          child: Text(
                                            "Try again",
                                            style: TextStyle(
                                                fontFamily: "opensan",
                                                fontSize: 16,
                                                color: Colors.white),
                                          ),
                                        ),
                                      ),
                                    )
                                  ],
                                ) : Container(),
                              )
                            ],
                          ) ,
                        ),
                      )
                    : Container(),
              ),
            ],
          ),
        ),
        ),
      ),
    );
  }
}
