import 'package:flutter/material.dart';
import 'package:service_app/animators/navianimator.dart';
import 'package:http/http.dart' as http;
//import 'package:flare_flutter/flare_actor.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import 'dart:convert';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:flutter_icons/flutter_icons.dart';

class WalletrechargePage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return WalletrechargeView();
  }

}

class WalletrechargeView extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return WalletrechargeLoader();
  }

}

class WalletrechargeLoader extends State<WalletrechargeView>{

  var amount = TextEditingController();

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  void showInSnackBar(String value) {
    _scaffoldKey.currentState.showSnackBar(new SnackBar(
        content: new Text(value),
      duration: Duration(hours: 1),
      action: new SnackBarAction(label: 'Ok',
        onPressed: (){
          Navigator.pop(context);
        },
      ),
      backgroundColor: Colors.black,
    ));
  }


  Razorpay _razorpay;
  var loading = false;

  Future _placeOrder() async{
    var options = {
      'key': 'rzp_test_gxXdHsXsGPtTvp',
      'amount': int.parse(amount.text)*100,
      'name': 'Serveondoor',
      'description': 'Service ordering',
//      'prefill': {'contact': '8178616459', 'email': 'test@razorpay.com'},
      'external': {
        'wallets': ['paytm']
      }
    };
    try {
      _razorpay.open(options);
    } catch (e) {
      debugPrint(e);
    }
  }
  var transid;

  Future _recharge() async{
    var url = "http://serveondoor.com/servernew/Restapi/walletrecharge";
    var sp = await SharedPreferences.getInstance();
    var token = sp.getString("token");
    var map = Map<String, dynamic>();
    map['amount'] = amount.text;
    map['transaction_id'] = transid.toString();
    http.Response res = await http.post(url,headers: <String, String>{'token': token}, body: map);
    print(res.body.toString());
//    Navigator.pop(context);
    showInSnackBar("Recharge successful");
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    setState(() {
      transid = response.paymentId.toString();
    });
//    _setPayment();
    setState(() {
      transid = response.paymentId.toString();
    });
    _recharge();
//    Fluttertoast.showToast(
//        msg: "SUCCESS: " + response.paymentId, timeInSecForIos: 4);
//    showInSnackBar("SUCCESS: " + response.paymentId);
//    print(response.paymentId);
  }

  void _handlePaymentError(PaymentFailureResponse response) {
     Fluttertoast.showToast(
         msg: "ERROR: " + response.code.toString() + " - " + response.message,
         timeInSecForIos: 4);
//    _ackAlert(context);
//      Navigator.pop(context);
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    Fluttertoast.showToast(
        msg: "EXTERNAL_WALLET: " + response.walletName, timeInSecForIos: 4);
  }

  @override
  void initState(){
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    super.dispose();
    _razorpay.clear();
  }




  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
//      key: _scaffoldKey,
      child: Scaffold(
        key: _scaffoldKey,
        backgroundColor: Color.fromRGBO(236, 239, 241, 1),
        appBar: AppBar(
          backgroundColor: Colors.white,
          leading: IconButton(
            onPressed: (){
              Navigator.pop(context);
            },
            icon: Icon(
                AntDesign.arrowleft,
              color: Colors.black,
            ),
          ),
          elevation: 0.5,
        ),
        body: new CustomScrollView(
          slivers: <Widget>[
            SliverPadding(
              padding: EdgeInsets.only(
                  top: 0,
              ),
              sliver: SliverToBoxAdapter(
                child: new Container(
                  color: Colors.white,
                  child: new Column(
                    children: <Widget>[
                      new Container(
                          padding: EdgeInsets.only(
                              top: 20,
                              left: 20,
                              right: 20
                          ),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: new Text(
                            "Amount".toUpperCase(),
                            style: TextStyle(
                                fontSize: 20,
                                fontFamily: "opensan",
                                fontWeight: FontWeight.bold
                            ),
                            textAlign: TextAlign.left,
                          ),
                        )
                      ),
                      new Container(
                        padding: EdgeInsets.only(
                          top: 10,
                          left: 20,
                          right: 20,
                          bottom: 20
                        ),
                        height: 85,
                        child: new TextField(
                          controller: amount,
                          decoration: InputDecoration(
                            prefix: Text(
                                "\u20B9 ",
                              style: TextStyle(
                                fontSize: 20
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.black.withOpacity(0.3), width: 2.0),
                            ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.black, width: 2.0),
                              ),
                            border: InputBorder.none,
                          ),
                          style: TextStyle(
                            fontSize: 20
                          ),
                          keyboardType: TextInputType.number,
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar: BottomAppBar(
          child: new Container(
            height: 70,
//            color: Colors.black,
          padding: EdgeInsets.only(
            left: 10,
            right: 10,
            bottom: 10,
            top: 10
          ),
            child: new FlatButton(
              splashColor: Colors.white,
              color: Colors.black,
                onPressed: (){
                  _placeOrder();
                },
                child: new Center(
                  child: Text(
                      "Continue".toUpperCase(),
                    style: TextStyle(
                      fontFamily: "opensan",
                      color: Colors.white,
                      fontSize: 18
                    ),
                  ),
                )
            ),
          ),
        ),
      ),
    );
  }

}