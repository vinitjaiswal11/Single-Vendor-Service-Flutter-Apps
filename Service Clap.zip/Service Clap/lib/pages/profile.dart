import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:service_app/pages/login.dart';
import 'package:service_app/animators/navianimator.dart';
import 'package:flutter_icons/flutter_icons.dart';
import 'package:share/share.dart';
import 'package:service_app/pages/mainpage.dart';
import 'package:service_app/pages/profileupdate.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:service_app/utils/apis.dart';
import 'package:sms_autofill/sms_autofill.dart';

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return ProfileLoader();
  }
}

class ProfileLoader extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return ProfileView();
  }
}

class ProfileView extends State<ProfileLoader> with CodeAutoFill{

  String appSignature;
  String otpCode;
  String otpget;
  
  var login = false;
  var loading = false;
  checkLogin() async{
    var sp = await SharedPreferences.getInstance();
     if(sp.containsKey("userid")){
      setState(() {
        login = true;
      });
    }else{
      setState(() {
        login = false;
      });
      print("Login false");
    }
  }

  Future logout() async {
    var sp = await SharedPreferences.getInstance();
    sp.clear();
    Navigator.of(context).pushAndRemoveUntil(FadeRoute(page: MainpagePage(pageview: 0,)), (Route<dynamic> route) => false);
  }

  var name = "";
  var email = "";
  var mobile = "";

  Future _getProfile() async{
    var url = Apis.BASE_URL + "Login/profileDetails";
    var sp = await SharedPreferences.getInstance();
    var userid = sp.getString("userid");
    var data = {
      "user_id" : userid
    };
    var res = await apiPostRequest(url, data);
    if(json.decode(res)['status'] == "1"){
      setState(() {
      name = json.decode(res)['details']['username'].toString();
      email = json.decode(res)['details']['email'];
      mobile = json.decode(res)['details']['phone'];
    });
    }
  }

  Future otpVerified() async{

    _onLoading();
    var sp = await SharedPreferences.getInstance();
    var url = Apis.BASE_URL + "Login/verifyOTP";
    var data = {"user_id" : useridget,"otp":otp.text,"device_type":"Android","device_id":"adssget35464","device_name":"Pixel 4"};
    print(data);
    var res = await apiPostRequest(url,data);
    if(json.decode(res)['status'].toString() == "1"){
        setState((){
          sp.setString("login", "true");
          sp.setString("userid", useridget.toString());
          login = true;
          fillmobile = false;
          _getProfile();
        });
    }else{

    }

    Navigator.pop(context);
    print(res);
  }


  var fillmobile = true;
  var mobiletxt = TextEditingController();
  var otp = TextEditingController();
  var useridget = "";


  Future register() async{
    _onLoading();
    var url = Apis.BASE_URL + "Login/signup";
    var data = {"mobile" : mobiletxt.text,"referral_code":"asdfggg","email":"","first_name":"","last_name":""};
    var res = await apiPostRequest(url,data);
    setState((){
      fillmobile = false;
      useridget = json.decode(res)['user_id'];
    });
    Navigator.pop(context);
    print(res);
  }

  Future loginUser() async{
    if(mobiletxt.text==""){

    }
   else{
     _onLoading();

    var url = Apis.BASE_URL + "Login";
    var data = {"mobile" : mobiletxt.text, "message_key":appSignature};
    var res = await apiPostRequest(url,data);
    setState((){
      fillmobile = false;
      useridget = json.decode(res)['user_id'];
    });
    Navigator.pop(context);
    print(res);
    }
  }

  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  void _onLoading() {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext context) {
      return Dialog(
        child: Padding(
          padding: EdgeInsets.only(
            left:20,
            right:20,
            top : 20,
            bottom: 20
          ),
          child : new Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              new CircularProgressIndicator(
              ),
              new Container(
                padding : EdgeInsets.only(
                  left:30
                ),
                child: new Text("Please wait..."),
              )
            ],
          )
        ),
      );
    },
  );
}

  @override
  void codeUpdated() {
    setState(() {
      otpCode = code;
      otp.text = otpCode;
    });
  }

  @override
  void initState(){
    super.initState();
    listenForCode();
    SmsAutoFill().getAppSignature.then((signature) {
      //("signatures " + signature);
      setState(() {
        appSignature = signature;
      });
      print(appSignature);
    });
    _getProfile();
    checkLogin();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color.fromRGBO(243, 244, 251, 1),
        body: Stack(
          children: [
            login == true ?new CustomScrollView(
              slivers: <Widget>[
                SliverAppBar(
                  title: Text(
                    "Profile",
                    style: TextStyle(color: Colors.black, fontFamily: "opensan"),
                  ),
                  actions: <Widget>[
                    IconButton(
                        icon: Icon(
                          AntDesign.logout,
                          color: Colors.black,
                        ),
                        onPressed: () {
                          logout();
                        }
                    )
                  ],
                  backgroundColor: Colors.white,
                ),
                
                SliverToBoxAdapter(
                  child: new Container(
                    color: Colors.white,
                    child: new Column(
                      children: <Widget>[
                        new ListTile(
                          title: Text(
                            name,
                            style: TextStyle(
                                fontFamily: "opensan",
                                fontSize: 18,
                                fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                            mobile,
                            style: TextStyle(
                                fontFamily: "opensan", fontWeight: FontWeight.bold),
                          ),
                          trailing: InkWell(
                            onTap: (){
                              Navigator.push(context, SlideTopRoute(page: ProfileUpdate(name: name,phone: mobile,email: email,))).
                              then((value){
                                _getProfile();
                              });
                            },
                            child: Text(
                              "Edit".toUpperCase(),
                              style: TextStyle(
                                  fontFamily: "opensan",
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue),
                            ),
                          ),
                        ),
                        new Container(
    //                padding: EdgeInsets.only(
    //                  left: 18,
    //                  right: 18
    //                ),
                          child: new Divider(
                            color: Colors.black,
                            thickness: 3,
                            height: 3,
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: new Container(
                    padding: EdgeInsets.only(
                      top: 10
                    ),
                    child: new Container(
                      color: Colors.white,
                      child: new Column(
                        children: <Widget>[
                          new ListTile(

                            leading: Icon(MaterialIcons.account_balance_wallet,
                                size: 25, color: Colors.black54),
                            title: Text(
                              "My Wallet",
                              style: TextStyle(fontFamily: "opensan"),
                            ),
                            onTap: (){
                              Navigator.of(context).pushAndRemoveUntil(FadeRoute(page: MainpagePage(pageview: 2,)), (Route<dynamic> route) => false);
                            },
                          ),
                          new ListTile(
                            onTap: (){
                              Share.share('check SOD app on play store for ordering essential service to your dor step', subject: 'Essential services at your home');
                            },
                            leading: Icon(MaterialIcons.share,
                                size: 25, color: Colors.black54),
                            title: Text(
                              "Share this app",
                              style: TextStyle(fontFamily: "opensan"),
                            ),
                          ),
                        
                          new ListTile(
                            leading: Image(
                              image:  AssetImage("assets/image/logo.png"),
                              height: 25,
                            ),
                            title: Text(
                              "About Us",
                              style: TextStyle(fontFamily: "opensan"),
                            ),
                          ),

                        ],
                      ),
                    ),
                  ),
                )
              ],
            )
            : CustomScrollView(
              slivers: [
                SliverAppBar(
                  title: Text(
                    "Profile",
                    style: TextStyle(color: Colors.black, fontFamily: "opensan"),
                  ),
                  backgroundColor: Colors.white,
                ),
                SliverPadding(
                  padding: EdgeInsets.only(
                    top: 10
                  ),
                  sliver: SliverToBoxAdapter(
                  child: Container(
                    color:  Colors.white,
                    child: ListTile(
                      onTap: (){},
                      leading: Icon(
                        Icons.share
                      ),
                      title: Text("Share this app"),
                    ),
                  ),
                ),
                )
              ],
            )

            ,Positioned(
              bottom: 0,
              left: 0,
              right : 0,
              child: BottomAppBar(
              child: login == false ?Container(
                child : fillmobile == true ?Container(
              height: 200,
              child: Column(
                children: [
                  new Container(
                    padding: EdgeInsets.only(
                      top: 20
                    ),
                    child: Center(
                      child: Text(
                        "Please Login to proceed",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87
                        ),
                      ),
                    ),
                  ),
                  new Container(
                    padding: EdgeInsets.only(
                      top : 20,
                      left: 20,
                      right : 20
                    ),
                    child: Container(
                      height: 50,
                      child: Row(
                        children: [
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: BoxDecoration(
                                border: Border(
                                  left: BorderSide(
                                    color: Colors.black12
                                  ),
                                  bottom: BorderSide(
                                    color: Colors.black12
                                  ),
                                  top: BorderSide(
                                    color: Colors.black12
                                  ),
                                  right: BorderSide(
                                    color: Colors.black12
                                  ),
                                ),
                                borderRadius: BorderRadius.only(
                                  topLeft : Radius.circular(5),
                                  bottomLeft : Radius.circular(5)
                                )
                              ),
                              child: Center(
                                child : Text(
                                  "+91",
                                  style: TextStyle(
                                    color: Colors.black
                                  ),
                                )
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 4,
                            child: Container(
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: Colors.black12
                                ),
                                borderRadius: BorderRadius.only(
                                  topRight : Radius.circular(5),
                                  bottomRight : Radius.circular(5)
                                )
                              ),
                              child: Center(
                                child : TextField(
                                  controller: mobiletxt,
                                  decoration: InputDecoration(

                                    contentPadding: EdgeInsets.only(
                                      left: 20
                                    ),
                                    counterText: "",
                                    hintText: "Mobile Number",
                                    border: InputBorder.none
                                  ),
                                  keyboardType: TextInputType.number,
                                  maxLength: 10,
                                )
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  
                  new Container(
                    padding: EdgeInsets.only(
                      left:20,
                      right : 20,
                      top: 15
                    ),
                    child: SizedBox(
                      height: 50,
                      width: MediaQuery.of(context).size.width,
                      child: FlatButton(
                      onPressed: (){
                        loginUser();
                      },
                      color: Colors.black,
                      child : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "Login / SignUp",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16
                            ),  
                          ),
                          Container(
                            child: Icon(
                              Icons.chevron_right,
                              color: Colors.white
                            ),
                          )
                        ],
                      )
                      ),
                    ),
                  )
                ],
              ),
            ):Container(
              height: 200,
              child: Column(
                children: [
                  new Container(
                    padding: EdgeInsets.only(
                      top: 20
                    ),
                    child: Center(
                      child: Text(
                        "Enter verification code",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87
                        ),
                      ),
                    ),
                  ),
                  new Container(
                    padding: EdgeInsets.only(
                      top: 10
                    ),
                    child: Center(
                      child: Text(
                        "We have sent you a 6 digit verification code on",
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.black45
                        ),
                      ),
                    ),
                  ),
                   new Container(
                    padding: EdgeInsets.only(
                      top: 5
                    ),
                    child: Center(
                      child: Text(
                        mobiletxt.text,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.black,
                          fontWeight : FontWeight.bold
                        ),
                      ),
                    ),
                  ),
                  Container(
                    padding : EdgeInsets.only(
                      left : 20,
                      right : 20,
                      bottom: 10,
                      top : 20
                    ),
                  //   child:PinCodeTextField(
                  //   appContext: context,
                  //   pastedTextStyle: TextStyle(
                  //           color: Colors.green.shade600,
                  //           fontWeight: FontWeight.bold,
                  //         ),
                  //   length: 6,
                  //   obscureText: false,
                  //   obscuringCharacter: '*',
                  //   animationType: AnimationType.fade,
                  //   cursorColor: Colors.black,
                  //   keyboardType: TextInputType.number,
                  //   pinTheme: PinTheme(
                  //           shape: PinCodeFieldShape.box,
                  //           borderRadius: BorderRadius.circular(5),
                  //           fieldHeight: 50,
                  //           fieldWidth: MediaQuery.of(context).size.width/8,
                  //           activeColor: Colors.black,
                  //           activeFillColor: Colors.black38,
                  //           borderWidth: 1,
                  //           inactiveColor: Colors.black38
                  //   ),
                  //   onCompleted: (res){
                  //     otpVerified();
                  //   },
                  //   controller: otp,
                  // )
                    child: PinCodeTextField(
                      length: 6,
                      autoDismissKeyboard: false,
                      obsecureText: false,
                      // animationType: AnimationType.fade,
                      // shape: PinCodeFieldShape.underline,
                      animationDuration: Duration(milliseconds: 300),
                      borderRadius: BorderRadius.circular(5),
                      fieldHeight: 50,
                      fieldWidth: 50,
                      controller: otp,
                      activeFillColor: Colors.grey,
                      activeColor: Colors.greenAccent,
                      inactiveColor: Color.fromRGBO(0, 186, 142, 1),
                      selectedColor: Colors.redAccent,
                      textInputType: TextInputType.number,
                      // onChanged: (value) {
                      //   if (value.length == 6) {
                      //     setState(() {
                      //       // otpset = true;
                      //       otpget = value;
                      //       //(value);
                      //     });
                      //   } else if (value.length < 6) {
                      //     setState(() {
                      //       // otpset = false;
                      //     });
                      //   }
                      // },
                      onCompleted: (value){
                        otpVerified();
                      },
                    ),
                  ),
                ],
              ),
            
              )
            ):Container()
              )
            )
          ],
        ),
      ),
    );
  }


}
