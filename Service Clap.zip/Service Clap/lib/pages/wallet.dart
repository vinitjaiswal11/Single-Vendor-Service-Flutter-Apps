import 'package:flutter/material.dart';
import 'package:flutter_icons/flutter_icons.dart';
import 'package:service_app/pages/giftcards.dart';
import 'package:service_app/animators/navianimator.dart';
import 'package:http/http.dart' as http;
//import 'package:flare_flutter/flare_actor.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import 'dart:convert';
import 'package:service_app/pages/walletrecharge.dart';
import 'package:service_app/pages/wallethistory.dart';
import 'package:service_app/utils/apis.dart';
import 'dart:io';
import 'package:intl/intl.dart';
import 'dart:core';

class WalletPage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return WalletLoader();
  }

}

class WalletLoader extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return WalltView();
  }

}

class WalltView extends State<WalletLoader>{

  var balance = "0";

  Future _getBalance() async{
    var url = Apis.BASE_URL+"Wallet/getWalletBalance";
    var sp = await SharedPreferences.getInstance();
    var userid = sp.getString("userid");
    var data = {
      "user_id":userid
    };
    var res = await apiPostRequest(url,data);
    print(json.decode(res)['wallet_balance']);
    setState(() {
      balance = double.parse(json.decode(res)['wallet_balance'][0]['Balance']).round().toString();
    });
    
  }

  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  @override
  void initState(){
    super.initState();
    _getBalance();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          title: Text(
              "SOD Wallet",
            style: TextStyle(
              fontFamily: "opensan",
              color: Colors.black,
//              fontWeight: FontWeight.bold
            ),
          ),
//          centerTitle: true,
          elevation: 0,
        ),
        backgroundColor: Color.fromRGBO(236, 239, 241, 1),
        body: new SingleChildScrollView(
          child: new Column(
            children: <Widget>[
              new Container(
                color : Colors.white,
                child: new ListTile(
                  leading: SizedBox(
                    width: 45,
                    height: 45,
                    child: CircleAvatar(
                      backgroundColor: Colors.black,
                      child: Icon(
                        MaterialIcons.account_balance_wallet,
                        size: 30,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  title: Text(
                    "Balance",
                    style: TextStyle(
                      fontFamily: "opensan",
                    ),
                  ),
                  subtitle: Text(
                    "\u20B9 "+balance,
                    style: TextStyle(
                      fontFamily: "opensan",
                      fontSize: 19,
                      fontWeight: FontWeight.bold,
                      color: Colors.black
                    ),
                  ),
                  trailing: Material(
                    child: InkWell(
                      onTap: (){
                        Navigator.push(context, SlideTopRoute(page: WalletrechargePage())).then((value){
                          _getBalance();
                        });
                      },
                      child: Text(
                        "Reacharge",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.blueAccent,
                            fontFamily: "opensan"
                        ),
                      ),
                    ),
                  ),
                ),
              ),
//              new Container(
//                padding: EdgeInsets.only(
//                  top: 10
//                ),
//                child: new Container(
//                  color: Colors.white,
//                  child: Material(
//                    child: ListTile(
//                      onTap: (){
//                        Navigator.push(context, EnterExitRoute(enterPage: GiftcradPage()));
//                      },
//                      leading: Icon(
//                        MaterialIcons.card_giftcard,
//                        color: Colors.black,
//                      ),
//                      title: Text("Vouchers"),
//                      trailing: Icon(
//                        AntDesign.rightcircle,
//                        color: Colors.black,
//                      ),
//                    ),
//                  ),
//                ),
//              ),
              new Container(
                padding: EdgeInsets.only(
                    top: 10
                ),
                child: new Container(
                  color: Colors.white,
                  child: Material(
                    child: ListTile(
                      onTap: (){
                        Navigator.push(context, EnterExitRoute(enterPage: WallethistoryPage()));
                      },
                      leading: Icon(
                        MaterialIcons.history,
                        color: Colors.black,
                      ),
                      title: Text("Wallet History"),
                      trailing: Icon(
                        AntDesign.rightcircle,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

}