import 'dart:ffi';

import "package:flutter/material.dart";
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:service_app/animators/navianimator.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:geocoder/geocoder.dart';
import 'package:service_app/pages/settime.dart';
import 'package:service_app/pages/locations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
//import 'package:flare_flutter/flare_actor.dart';
import 'dart:async';
import 'dart:io';
import 'package:service_app/utils/apis.dart';
import 'dart:convert';

class AddressPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return AddressLoader();
  }
}

class AddressLoader extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return AddressView();
  }
}

class AddressView extends State<AddressLoader> {
  var location = TextEditingController();
  var housef = TextEditingController();
  var name = TextEditingController();
  var phone = TextEditingController();

  Future getCurrentLocation(lat, lang) async {
    final coordinates = new Coordinates(lat, lang);
    var addresses =
        await Geocoder.local.findAddressesFromCoordinates(coordinates);
    var first = addresses.first;
    print("${first.featureName} : ${first.addressLine}");
    setState(() {
      location.text = first.addressLine;
    });
    // Navigator.pop(context);
  }
  var lt = 0.0;
  var lo = 0.0;
  Future savedLocation() async {
    var sp = await SharedPreferences.getInstance();
    setState(() {
      lt = double.parse(sp.getString("lat"));
      lo = double.parse(sp.getString("log"));
      location.text = sp.getString("location");
      allMarks.add(Marker(
        markerId: MarkerId('mymarker'),
        draggable: true,
        onTap: () {
          print("Tapped");
        },
        icon: BitmapDescriptor.fromAsset("assets/icons/location.png"),
        position: LatLng(lt, lo),
        visible: true,
        infoWindow: InfoWindow(title: "Marker")));
    });
  }

  Completer<GoogleMapController> _controller = Completer();

  static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );

  static final CameraPosition _kLake = CameraPosition(
      bearing: 192.8334901395799,
      target: LatLng(37.43296265331129, -122.08832357078792),
      tilt: 59.440717697143555,
      zoom: 19.151926040649414
  );

  List<Marker> allMarks = [];
  // var locations =
  Future getLocation() async {
    var sp = await SharedPreferences.getInstance();
    var loc = sp.getString("location");
    print(loc);
    setState(() {
      location.text = loc;
    });
  }

  @override
  void initState() {
    super.initState();
    getLocation();
    savedLocation();

  }

  Set<Circle> circles = Set.from([
    Circle(
        circleId: CircleId('cir'),
        center: LatLng(0.0, 0.0),
        radius: 2000,
        fillColor: Colors.blueAccent)
  ]);

  Set<Polyline> poly = Set.from([]);

  final Set<Marker> _markers = {};
  final Set<Circle> _circle = {};
  double _radius = 100.0;
  double _zoom = 18.0;
  bool _showFixedGpsIcon = false;
  bool _isRadiusFixed = false;
  String error;
  static const LatLng _center = const LatLng(-25.4157807, -54.6166762);
  MapType _currentMapType = MapType.normal;
  LatLng _lastMapPosition;

  var addr_type = 0;
  Color selcol = Colors.blueAccent;

  Future changeAddrType() async{
    setState(() {
      if(addr_type == 0){
        addr_type = 1;
      }else{
        addr_type = 0;
      }
    });
  }



  Future saveAddress() async{
    var url = Apis.BASE_URL + "Address/addAddress";
    var sp = await SharedPreferences.getInstance();
    var userid = sp.getString("userid");
    var data = {"user_id":userid,
              "customer_name":name.text,
              "phone":phone.text,
              "house_no":housef.text,
              "society":"Jai",
              "landmark":location.text,
              "city":"noida",
              "postal_code":"201309",
              "addrss_type":"home",
              "latitude":"28.35678",
              "longitude":"75.2354678",
              "geo_address":"homefsfhb,news stagiuojn "};
    var res = await apiPostRequest(url,data);
    Navigator.pop(context);
    print(res);
  }

  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  @override
  Widget build(BuildContext context) {
    double mapWidth = MediaQuery.of(context).size.width;
    double mapHeight = MediaQuery.of(context).size.height - 215;
    double iconSize = 60.0;

    // TODO: implement build
    return new Scaffold(
      // appBar: AppBar(
      //   backgroundColor: Colors.white,
      //   title: Text(
      //     "Set address",
      //     style: TextStyle(
      //       color: Colors.black,
      //       fontFamily: "opensan"
      //     ),
      //   ),
      //   leading: ,
      // ),
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              height: MediaQuery.of(context).size.height / 1.4,
              child: new Stack(
                children: <Widget>[
                  new Container(
                    child: GoogleMap(
                      // mapType: MapType.normal,
                      polylines: poly,
                      initialCameraPosition: CameraPosition(
                          target: LatLng(28.5355, 77.3910), zoom: 12.0),
                      onMapCreated: (GoogleMapController controller) {
                        _controller.complete(controller);
                      },
                      compassEnabled: true,
                      mapToolbarEnabled: true,
                      zoomGesturesEnabled: true,
                      myLocationButtonEnabled: true,
                      // circles: circles,
                      myLocationEnabled: true,
                      // markers: Set.from(allMarks),
                      onCameraIdle: () {
                        print(_lastMapPosition);
                        getCurrentLocation(_lastMapPosition.latitude,
                            _lastMapPosition.longitude);
                      },
                      onCameraMove: (CameraPosition position) {
                        // print(position.target);
                        setState(() {
                          _lastMapPosition = position.target;
                        });
                        // getCurrentLocation(
                        //     _lastMapPosition.latitude, _lastMapPosition.longitude);
                      },
                    ),
                  ),
                  new Positioned(
                    top: (mapHeight - 100) / 2.5,
                    right: (mapWidth - 100) / 2,
                    child: Image(
                      image: AssetImage(
                        "assets/icons/location.png",
                      ),
                      width: 100,
                      height: 100,
                    ),
                  )
                ],
              ),
            ),
            Container(
              child: DraggableScrollableSheet(
                initialChildSize: 0.26,
                minChildSize: 0.26,
                maxChildSize: 0.74,
                builder: (BuildContext context, myscrollController) {
                  return SafeArea(
                    child: CustomScrollView(
                        controller: myscrollController,
                        slivers: <Widget>[
                          SliverAppBar(
                            centerTitle: true,
                            title: SizedBox(
                              width: 20,
                              child: Icon(
                                FontAwesomeIcons.minus,
                                color: Colors.black38,
                              ),
                            ),
                            backgroundColor: Colors.white,
                            leading: IconButton(
                              icon: Icon(FontAwesomeIcons.arrowLeft),
                              color: Colors.black38,
                              onPressed: () {
                                Navigator.pop(context);
                              },
                            ),
                            pinned: true,
                            elevation: 0,
                          ),
                          SliverToBoxAdapter(
                            child: new Container(
                              padding: EdgeInsets.only(left: 20, right: 20),
                              color: Colors.white,
                              child: Column(
                                children: <Widget>[
                                  new Container(
                                    color: Colors.white,
                                    child: new TextField(
                                      controller: location,
                                      decoration: InputDecoration(
                                          labelText: "Location",
                                          labelStyle: TextStyle(
                                              fontFamily: "opensan",
                                              fontSize: 16)),
                                      maxLines: 2,
                                      style: TextStyle(
                                        fontFamily: "opensan",
                                      ),
                                      onTap: (){
                                        Navigator.push(context, FadeRoute(page: LocationPage())).then((val) {
                                          getLocation();
                                        });
                                      },
                                      readOnly: true,
                                    ),
                                  ),
                                  new Container(
                                    color: Colors.white,
                                    child: new TextField(
                                      controller: housef,
                                      decoration: InputDecoration(
                                          labelText: "House/Flat/Street",
                                          labelStyle: TextStyle(
                                              fontFamily: "opensan",
                                              fontSize: 16)),
                                      maxLines: 2,
                                    ),
                                  ),
                                  new Container(
                                    color: Colors.white,
                                    child: new TextField(
                                      controller: name,
                                      decoration: InputDecoration(
                                          labelText: "Name",
                                          labelStyle: TextStyle(
                                              fontFamily: "opensan",
                                              fontSize: 16)),
                                      maxLines: 2,
                                    ),
                                  ),
                                  new Container(
                                    color: Colors.white,

                                    child: new TextField(
                                      controller: phone,

                                      decoration:
                                          InputDecoration(
                                            labelText: "Phone",
                                            counterText: "",
                                          ),


                                      maxLength: 10,
                                      keyboardType: TextInputType.number,
                                    ),

                                  ),
                                  new Container(
                                    padding:
                                        EdgeInsets.only(top: 20, bottom: 20),
                                    color: Colors.white,
                                    child: new Column(
                                      children: <Widget>[
                                        new Container(
                                          padding: EdgeInsets.only(
                                              left: 20,
                                              right: 20,
                                              bottom: 10,
                                              top: 15),
                                          child: Align(
                                            alignment: Alignment.center,
                                            child: Text("Save as"),
                                          ),
                                        ),
                                        new Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: <Widget>[
                                            new Material(
                                              color: addr_type == 0 ? Colors.blueAccent : Colors.white,
                                              child: InkWell(
                                                onTap: () {
                                                  changeAddrType();
                                                },
                                                child: Container(
                                                  width: 50,
                                                  height: 50,
                                                  child: Icon(
                                                        FontAwesomeIcons.home,
                                                        color: addr_type == 0 ? Colors.white : Colors.blueAccent,
                                                      ),
                                                ),
                                              ),
                                            ),
                                            new Material(
                                              color: addr_type == 1 ? Colors.blueAccent : Colors.white,
                                              child: InkWell(
                                                onTap: () {
                                                  changeAddrType();
                                                },
                                                child: Container(
                                                  width: 50,
                                                  height: 50,
                                                  child: Icon(
                                                    FontAwesomeIcons
                                                      .building,
                                                      color: addr_type == 1 ? Colors.white : Colors.blueAccent,
                                                  ),
                                                ),
                                              ),
                                            )
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )
                        ]),
                  );
                },
              ),
            )
          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        elevation: 1,
        child: new Container(
          padding: EdgeInsets.only(top: 10, bottom: 10, left: 20, right: 20),
          child: new FlatButton(
            color: Colors.black,
            child: Padding(
              padding: EdgeInsets.only(top: 15, bottom: 15),
              child: Text(
                "Save",
                style: TextStyle(color: Colors.white, fontFamily: "opensan"),
              ),
              // child : Container(
              //   height: 50,
              //   child: FlareActor(
              //               "assets/animations/Loader.flr",
              //               animation: "Untitled",
              //               color: Colors.blueAccent.withOpacity(0.5),
              //             ),
              // )
            ),
            onPressed: () {
              // Navigator.push(context, EnterExitRoute(enterPage: SettimePage()));
              saveAddress();
            },
          ),
        ),
      ),
    );
  }
}
