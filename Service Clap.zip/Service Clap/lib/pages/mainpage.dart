import 'package:flutter/material.dart';
import 'package:bottom_personalized_dot_bar/bottom_personalized_dot_bar.dart';
import 'package:service_app/pages/home.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:service_app/pages/profile.dart';
import 'package:service_app/pages/orders.dart';
//import 'package:curved_navigation_bar/curved_navigation_bar.dart';
//import 'package:curved_navigation_bar/curved_navigation_bar.dart';
//import 'package:ff_navigation_bar/ff_navigation_bar.dart';
import 'package:flutter_icons/flutter_icons.dart';
import 'package:service_app/pages/wallet.dart';
import 'package:firebase_messaging/firebase_messaging.dart';


class MainpagePage extends StatelessWidget{
  final pageview;
  MainpagePage({Key key,this.pageview}):super(key:key);
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MainpageLoader(pageview: this.pageview,);
  }

}

class MainpageLoader extends StatefulWidget{
  final pageview;
  MainpageLoader({Key key,this.pageview}):super(key:key);
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return MainpageView();
  }

}

class MainpageView extends State<MainpageLoader>{
  var appupdate = false;
  final FirebaseMessaging _messaging = FirebaseMessaging();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  String _itemSelected = 'item-1';
  var page;
  Future selectItem(item) async{
    debugPrint(item);
    setState(() {
      _itemSelected = item;
      page = HomePage();
    });
  }

  var _currentIndex;
  _curreIndexget() async{
    setState(() {
      _currentIndex = widget.pageview;
    });
  }

  Future setPage(index) async{
    if(index == 0){
      setState(() {
        page = HomePage();
        _currentIndex = index;
      });
    }
    else if(index == 3){
      setState(() {
        page = ProfilePage();
        _currentIndex = index;
      });
    }
    else if(index == 2){
      setState(() {
         page = WalletPage();
        _currentIndex = index;
      });
    }
    else if(index == 1){
      setState(() {
        page = OrderPage();
        _currentIndex = index;
      });
    }
  }

  @override
  void initState(){
    super.initState();
    _curreIndexget();
    if(_currentIndex == 0){
      setState(() {
        page = HomePage();
      });
    }else if(_currentIndex == 1){
      setState(() {
        page = OrderPage();
      });
    }
    else if(_currentIndex == 2){
      setState(() {
        page = WalletPage();
        _currentIndex = _currentIndex;
      });
    }
    _messaging.configure(
        onMessage: (Map<String, dynamic> message) async{
//          Fluttertoast.showToast(msg: "$message");
          print(message);
//          _scaffoldKey.currentState.showSnackBar(new SnackBar(
//            content: new Text(message['data']['notitype'].toString()),
//            duration: Duration(hours: 1),
//            action: new SnackBarAction(label: 'Ok',
//              onPressed: (){
//              },
//            ),
//            backgroundColor: Colors.black,
//          ));
          setState(() {
            appupdate = true;
          });
        }
    );
  }

  _appupdatedilog() async{
    setState(() {
      appupdate = false;
    });
  }

  GlobalKey _bottomNavigationKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        key: _scaffoldKey,
        body: Stack(
          children: <Widget>[
            page,
            new Positioned(
                top : 0,
                bottom: 0,
                left: 0,
                right : 0,
                child : appupdate == true ? new Container(
                  color : Colors.black.withOpacity(0.3),
                  padding: EdgeInsets.only(
                    left: 20,
                    right: 20
                  ),
                  child: new Center(
                    child: new Container(
                      width: MediaQuery.of(context).size.width,
                      height: 150,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(
                          Radius.circular(5)
                        ),
                        color: Colors.white,
                      ),
                      padding: EdgeInsets.only(
                        left: 20,
                        right: 20,
                        top: 20
                      ),
                      child: new Column(
                        children: <Widget>[
                          new Container(
                            padding : EdgeInsets.only(
                              bottom: 5
                            ),
                            child: new Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                "App update avilable",
                                style: TextStyle(
                                    fontFamily: "opensan",
                                    fontWeight: FontWeight.bold,
                                  fontSize: 18
                                ),
                              ),
                            ),
                          ),
                          new Container(
                            padding : EdgeInsets.only(
                                bottom: 5
                            ),
                            child: new Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                "kjdshfjk dkjfshkjsdhfkjhsdkjfh kjsdhfkjhsdkjfh kjsd hfkjh sdkfhkjsdh fkjsfdhksd hfk",
                                style: TextStyle(
                                    fontFamily: "opensan",
                                ),
                              ),
                            ),
                          ),
                          new Container(
                            padding : EdgeInsets.only(
                                bottom: 5
                            ),
                            child: new Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: <Widget>[
                                new FlatButton(
                                    onPressed: (){
                                      _appupdatedilog();
                                    },
                                    child:Text(
                                      "Later",
                                      style: TextStyle(
                                          fontFamily: "opensan",
                                          fontSize: 16,
                                        color: Colors.redAccent
                                      ),
                                    )
                                ),
                                new FlatButton(
                                    onPressed: (){},
                                    child:Text(
                                      "Update",
                                      style: TextStyle(
                                          fontFamily: "opensan",
                                          fontSize: 16,
                                      ),
                                    )
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ) : Container()
            )
          ],
        ),
        bottomNavigationBar: BottomAppBar(
          child: Container(
            height: 55,

            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Material(
                    color: Colors.white,
                    child: InkWell(
                      splashColor: Colors.black38,
                      radius: 120,
                      onTap: (){
                        setPage(0);
                      },
                      child: Container(
                        padding: EdgeInsets.only(
                            top: 5
                        ),
                        child: Column(
                          children: [
                            Icon(AntDesign.home, size: 30, color: _currentIndex == 0 ?Colors.black : Colors.black38),
                            Expanded(
                              child: Center(
                                child: Text("Home",
                                  style: TextStyle(
                                      fontSize: 11,
                                      color: _currentIndex == 0 ?Colors.black : Colors.black38
                                  ),),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Material(
                    color: Colors.white,
                    child: InkWell(
                      splashColor: Colors.black38,
                      radius: 120,
                      onTap: (){
                        setPage(1);
                      },
                      child: Container(
                        padding: EdgeInsets.only(
                          top :5
                        ),
                        child: Column(
                          children: [
                            Icon(AntDesign.profile,size: 30, color: _currentIndex == 1 ?Colors.black : Colors.black38),
                            Expanded(
                              child: Center(
                                child: Text("Bookings",
                                  style: TextStyle(
                                      fontSize: 11,
                                      color: _currentIndex == 1 ?Colors.black : Colors.black38
                                  ),),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Material(
                    color: Colors.white,
                    child: InkWell(
                      splashColor: Colors.black38,
                      radius: 120,
                      onTap: (){
                        setPage(2);
                      },
                      child: Container(
                        padding: EdgeInsets.only(
                          top: 5
                        ),
                        child: Column(
                          children: [
                            Icon(AntDesign.wallet, size: 30, color: _currentIndex == 2 ?Colors.black : Colors.black38),
                            Expanded(
                              child: Center(
                                child: Text("Wallet",
                                  style: TextStyle(
                                      fontSize: 11,
                                      color: _currentIndex == 2 ?Colors.black : Colors.black38
                                  ),),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Material(
                    color: Colors.white,
                    child: InkWell(
                      splashColor: Colors.black38,
                      radius: 120,
                      onTap: (){
                        setPage(3);
                      },
                      child: Container(
                        padding: EdgeInsets.only(
                          top :5
                        ),
                        child: Column(
                          children: [
                            Icon(AntDesign.user, size: 30, color: _currentIndex == 3 ?Colors.black : Colors.black38),
                            Expanded(
                              child: Center(
                                child: Text(
                                  "Profile",
                                  style: TextStyle(
                                      fontSize: 11,
                                      color: _currentIndex == 3 ?Colors.black : Colors.black38
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

}