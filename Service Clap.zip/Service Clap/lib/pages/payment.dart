import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:service_app/utils/apis.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
// import 'dart:io' as io;
import 'dart:ui' as ui;
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:service_app/pages/orderdetails.dart';
import 'package:service_app/animators/navianimator.dart';
import 'dart:io';

// import 'package:path/path.dart';
import 'package:service_app/database/vendorcart.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io' as io;
import 'package:service_app/database/vendordb_helper.dart';

class PaymentsPage extends StatelessWidget {
  final vendorid;
  final dateget;
  final time;
  final List datas;
  final priceget;
  final mrp;
  PaymentsPage({Key key,this.vendorid,this.dateget,this.datas,this.time,this.priceget,this.mrp}):super(key : key);
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    // return PaymentsLoader(

    // );
    return PaymentsLoader(vendordid: this.vendorid,dateget:this.dateget,datas:this.datas,time:this.time,priceget:this.priceget,mrp:this.mrp);
  }
}

class PaymentsLoader extends StatefulWidget {
  final vendordid;
  final dateget;
  final List datas;
  final time;
  final priceget;
  final mrp;
  PaymentsLoader({Key key,this.vendordid,this.dateget,this.datas,this.time,this.priceget,this.mrp}):super(key : key);
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return PaymentsView();
  }
}

class PaymentsView extends State<PaymentsLoader> {
  Future<List<Vendorcart>> cart;
  Future<dynamic> price;
  var dbHelper;
//   static Database _db;
//   static const SERVICE_ID = "service_id";
//   static const CATEGORY_ID = "category_id";
//   static const VENDOR_ID = "vendor_id";
//   static const SUBCAT_ID = "subcat_id";
//   static const SERVICE_NAME = "service_name";
//   static const MRP = "mrp";
//   static const PRICE = "price";
//   static const QTY = "qty";
//   static const TABLE_NAME = "cart";
//   static const DB_NAME = "cart.db";

//   Future<Database> get db async{
//     // if(_db != null){
//     //   return _db;
//     // }
//     // _db = await initDb();
//     return _db;
//   }

//   initDb() async{
//     io.Directory documentDiretory = await getApplicationDocumentsDirectory();
//     String path = join(documentDiretory.path, DB_NAME);
//     var db = await openDatabase(path, version: 1, onCreate: _onCreate);
//     return db;
//   }

//   _onCreate(Database db, int version) async{
//     String sql = "CREATE TABLE $TABLE_NAME "
//         "($SERVICE_ID INTEGER,$CATEGORY_ID INTEGER, $VENDOR_ID INTEGER, $SUBCAT_ID INTEGER, $SERVICE_NAME TEXT, $MRP INTEGER, $PRICE INTEGER ,$QTY INTEGER)";
//     await db.execute(sql);
//   }

//   Future<List<Vendorcart>> getCart(int catid) async{
//     var dbClient = await db;
//     List<Map> map = await dbClient.rawQuery("SELECT * FROM $TABLE_NAME WHERE $VENDOR_ID = $catid");
// //    print(map.length);
//     List<Vendorcart> cart = [];
//     if(map.length > 0){
// //      print(map.length);
//       for(int i = 0; i < map.length; i++){
//         cart.add(Vendorcart.fromMap(map[i]));
//       }
//     }
//     print(cart.length);
//     // return cart; 
//   }


  deleteallCart() async {
    dbHelper.deleteAll(int.parse(widget.vendordid));
  }

  

  Razorpay _razorpay;
  var loading = false;

  getCartsdata() async{
    setState(() {
      cart = dbHelper.getCartval(int.parse(widget.vendordid));
      // liststate = true;
    });
  }

  @override
  void initState() {
    super.initState();
    dbHelper = VendorDbHelper();
    getCartsdata();
    // getCart(widget.vendordid);
//    _placeOrder();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  var transid = "";

  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    setState(() {
      transid = response.paymentId.toString();
    });
    _setPayment();
    Fluttertoast.showToast(
        msg: "SUCCESS: " + response.paymentId, timeInSecForIos: 4);
  }

  @override
  void dispose() {
    super.dispose();
    _razorpay.clear();
  }

  var paymode = "";

  Future _setPayment() async{
    setState(() {
      loading = true;
    });
    var sp = await SharedPreferences.getInstance();
    var token = sp.getString("token");
//    var addressid = sp.getString("addressid");
//    print(addressid);
    
    if(radioset.toString() == '1'){
      paymode = "pos";
      transid = "pos";
    }
    else if(radioset.toString() == '2'){
      paymode = "cash";
      transid = "cash";
      _placeOrder();
    }
    else if(radioset.toString() == '3'){
      paymode = "Online";
      _placeOrder();
    }
    else if(radioset.toString() == '4'){
      paymode = "Wallet";
    }
    var map = Map<String, dynamic>();
//     map['cart_id'] = widget.cartid.toString();
//     map['payment_mode'] = paymode;
//     map['transaction_id'] = transid;
//     var url = "http://serveondoor.com/servernew/Restapi/payment";
//     http.Response res = await http.post(url,
//         headers: <String, String>{'token': token}, body: map);
// //    print(json.decode(res.body)['APICODERESULT'].toString());
//     if(json.decode(res.body)['APICODERESULT'].toString() == "Data Insert Succesfully"){
//       Fluttertoast.showToast(
//           msg: "Payment Successful"
//       );
//       _placeOrder();
//     }else{

//     }
  }

  void _onLoading() {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext context) {
      return WillPopScope(
        onWillPop: () async => false,
        child : Dialog(
        child: Padding(
          padding: EdgeInsets.only(
            left:20,
            right:20,
            top : 20,
            bottom: 20
          ),
          child : new Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              new CircularProgressIndicator(
              ),
              new Container(
                padding : EdgeInsets.only(
                  left:30
                ),
                child: new Text("Placing your order..."),
              )
            ],
          )
        ),
      )
      );
    },
  );
}

  Future _placeOrder() async{
    _onLoading();
    var url = Apis.BASE_URL + "Orders/placed";
    var sp = await SharedPreferences.getInstance();
    var userid = sp.getString("userid");
    var mrp = sp.getString("mrp");
    var price = sp.getString("price");
    var addressid = sp.getString("addressid");
    var data = {
      "user_id" : userid,
      "address_id": addressid,
      "product_mrp": mrp,
      "product_salling" : price,
      "paid_amount" : price,
      "total_amount" : price,
      "delivery_type" : "Standard",
      "delivery_charge": "0",
      "express_delivey_charge": "0",
      "delivery_date": widget.dateget,
      "delivery_time": widget.time,
      "coupon_id": "",
      "coupon_discount": "0",
      "membership_id": "",
      "membership_amount": "0",
      "payment_method": paymode,
      "device_name": "android",
      "product_array": cartdatas
    };
    print(cartdatas.toString());
    var res = await apiPostRequest(url,data);
    var orderid = json.decode(res)['order_id'];
    print(res);
    deleteallCart();
    Navigator.pop(context);
    Navigator.push(context, FadeRoute(page: OrderdetailPage(bookingid: orderid,index: "0",)));
  }

  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  void openCheckout() async {
    if(radioset == 3){
      var options = {
        'key': Apis.PAYTM_KEY,
        'amount': int.parse(widget.priceget)*100,
        'name': 'Acme Corp.',
        'description': 'Service Purchasing',
//        'prefill': {'contact': '8178616459', 'email': 'test@razorpay.com'},
        'external': {
          'wallets': ['paytm']
        }
      };

    try {
      _razorpay.open(options);
    } catch (e) {
      debugPrint(e);
    }
    }
    else if(radioset == 2){
      _placeOrder();
    }
    else if(radioset == 4){
      _modalBottomSheetMenu();
    }
    else if(radioset == 5){
      _modalBottomSheetMenu();
    }
    else{
      _setPayment();
    }
  }



Future<void> _ackAlert(BuildContext context) {
  return showDialog<void>(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Something went wrong'),
        content: const Text('You may have cancel the payment or there is internet problem'),
        actions: <Widget>[
          FlatButton(
            child: Text('Try again'),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}


  void _handlePaymentError(PaymentFailureResponse response) {
    // Fluttertoast.showToast(
    //     msg: "ERROR: " + response.code.toString() + " - " + response.message,
    //     timeInSecForIos: 4);
    _ackAlert(context);
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    Fluttertoast.showToast(
        msg: "EXTERNAL_WALLET: " + response.walletName, timeInSecForIos: 4);
  }

  var radioset = 0;
  _setRadio(radioval) async{
    setState(() {
      radioset = radioval;
    });
  }

  void _modalBottomSheetMenu(){
    showModalBottomSheet(
        context: context,
        builder: (builder){
          return new Container(
            height: 350.0,
            color: Colors.transparent, //could change this to Color(0xFF737373),
            //so you don't have to change MaterialApp canvasColor
            child: new Container(
                decoration: new BoxDecoration(
                    color: Colors.white,
                    borderRadius: new BorderRadius.only(
                        topLeft: const Radius.circular(10.0),
                        topRight: const Radius.circular(10.0))),
                child: new Center(
                  child: new Text("This is a modal sheet"),
                )),
          );
        }
    );
  }

    List<dynamic> cartdatas = [];
  var liststate = false;

    addtoLists(productId,name,productType,proSetQtn,mrpPrice,secPrice,vendor_id) async{
    var data = {
          "productId" : productId,
          "variantId" : "",
          "productCode" : "",
          "name" : name,
          "productType" : "productType",
          "proSetQtn" : proSetQtn,
          "mrpPrice" : mrpPrice,
          "secPrice" : secPrice,
          "unit" : "",
          "vendor_id" : vendor_id
        };
        setState(() {
            cartdatas.add(data);
        });
    
  }

  _listReviews() {
      return SliverToBoxAdapter(
        child: Container(
            child: FutureBuilder(
              future: cart,
              builder: (context, AsyncSnapshot<List<Vendorcart>> snapshot){
//                print("Name : "+snapshot.data[0].service_name.toString());
                print("id get: "+snapshot.data[0].category_id.toString());
                return ListView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: snapshot.data.length,
                  itemBuilder: (context, i){
                    print(snapshot.data.length);
                    // for(var i = 0; i < snapshot.data.length;i++){
                      print(snapshot.data[i].service_name);
                    // }
                    var qty = snapshot.data[i].qty.toString();
                    var productId = snapshot.data[i].service_id;
                    var name = snapshot.data[i].service_name;
                    var productType = snapshot.data[i].type;
                    var proSetQtn = snapshot.data[i].qty;
                    var mrpPrice = snapshot.data[i].mrp;
                    var secPrice = snapshot.data[i].price;
                    var vendors_id = snapshot.data[i].vendor_id;
                    if(cartdatas.length < snapshot.data.length){
                      addtoLists(productId,name,productType,proSetQtn,mrpPrice,secPrice,vendors_id);
                    }
                    print(cartdatas.toString());
                    return Card(
                      child: Container(
                        padding:EdgeInsets.only(
                          bottom: 10,
                          top : 10,
                        ),
                        child: ListTile(
                          title: Padding(
                            padding: EdgeInsets.only(
                              top: 0,
                            ),
                            child: Text(
                              snapshot.data[i].service_name.toString(),
                              style: TextStyle(
                                  fontFamily: "opensan",
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                          subtitle: new Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Padding(
                                  padding: EdgeInsets.only(top: 5),
                                  child: new Container(
                                      child: new Container(
                                        padding: EdgeInsets.only(
                                          left: 10,
                                          right: 10,
                                          top: 2,
                                          bottom: 2,
                                        ),
                                        color: Colors.red[50],
                                        child: Text(
                                          "\u20B9 "+snapshot.data[i].price.toString(),
                                          style: TextStyle(
                                              fontFamily: "opensan",
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      )),
                                ),
                              ),
                              SizedBox(
                                  width: 90,
                                  height: 35,
                                  child:
                                  // packs[index]['quantity'] == 0
                                  //     ?
                                  Material(
                                    color: Colors.white,
                                    borderRadius:
                                    BorderRadius.all(
                                        Radius
                                            .circular(
                                            5)),
                                    child: InkWell(
                                      borderRadius:
                                      BorderRadius
                                          .all(Radius
                                          .circular(
                                          5)),
                                      // child:
                                      // new Container(
                                      //   decoration: BoxDecoration(
                                      //       border: Border.all(
                                      //           color: Color.fromRGBO(
                                      //               79,
                                      //               155,
                                      //               247,
                                      //               1),
                                      //           width: 1),
                                      //       borderRadius:
                                      //       BorderRadius.all(
                                      //           Radius.circular(
                                      //               5))),
                                      //   child: new Row(
                                      //     mainAxisAlignment:
                                      //     MainAxisAlignment
                                      //         .spaceBetween,
                                      //     children: <Widget>[
                                      //       Expanded(
                                      //         child : Material(
                                      //           color: Color.fromRGBO(
                                      //               79,
                                      //               155,
                                      //               247,
                                      //               1),
                                      //           borderRadius:
                                      //           BorderRadius.only(
                                      //             topLeft: Radius.circular(3),
                                      //             bottomLeft: Radius.circular(3)
                                      //           ),
                                      //           child: InkWell(
                                      //             borderRadius:
                                      //             BorderRadius.all(
                                      //                 Radius
                                      //                     .circular(
                                      //                     5)),
                                      //             onTap: (){
                                      //             int qty = snapshot.data[0].qty - 1;
                                      //             var mrp = snapshot.data[i].mrp;
                                      //             var price = snapshot.data[i].price;
                                      //             if(qty > 0){
                                      //               updateCart(
                                      //                   snapshot.data[i].service_id
                                      //                   ,snapshot.data[i].category_id
                                      //                   ,snapshot.data[i].vendor_id
                                      //                   ,snapshot.data[i].subcat_id
                                      //                   ,snapshot.data[i].service_name
                                      //                   ,snapshot.data[i].type
                                      //                   ,mrp
                                      //                   ,price
                                      //                   ,qty);
                                      //             }else{
                                      //               deleteCart(snapshot.data[i].service_id, snapshot.data[i].category_id);
                                      //             }
                                      //             },
                                      //             child: new Container(
                                      //               width: 25,
                                      //               height: MediaQuery.of(
                                      //                   context)
                                      //                   .size
                                      //                   .height,
                                      //               decoration: BoxDecoration(

                                      //                   borderRadius:
                                      //                   BorderRadius.all(Radius.circular(5))),
                                      //               child:
                                      //               Center(
                                      //                 child:
                                      //                 Icon(
                                      //                   Icons.remove,
                                      //                   color: Colors.white,
                                      //                   size: 15,

                                      //                 ),
                                      //               ),
                                      //             ),
                                      //           ),
                                      //         )
                                      //       ),
                                      //       Expanded(
                                      //         child: Center(
                                      //           child: new Container(
                                      //             // padding: EdgeInsets
                                      //             //     .only(
                                      //             //     left:
                                      //             //     10),
                                      //             child: Text(snapshot.data[i].qty.toString(),
                                      //               style: TextStyle(
                                      //                   fontFamily:
                                      //                   "opensan",
                                      //                   fontWeight: FontWeight
                                      //                       .w600,
                                      //                   fontSize: 13,
                                      //                   color: Color.fromRGBO(
                                      //                       79,
                                      //                       155,
                                      //                       247,
                                      //                       1)),
                                      //             ),
                                      //           ),
                                      //         ),
                                      //       ),
                                      //       Expanded(
                                      //         child : new Material(
                                      //           color: Color.fromRGBO(
                                      //               79,
                                      //               155,
                                      //               247,
                                      //               1),
                                      //           borderRadius:
                                      //           BorderRadius.only(
                                      //               topRight: Radius.circular(3),
                                      //             bottomRight: Radius.circular(3)
                                      //           ),
                                      //           child: InkWell(
                                      //             borderRadius:
                                      //             BorderRadius.all(
                                      //                 Radius
                                      //                     .circular(
                                      //                     5)),
                                      //             onTap: (){
                                      //             int qty = snapshot.data[i].qty + 1;
                                      //             var mrp = snapshot.data[i].mrp;
                                      //             var price = snapshot.data[i].price;
                                      //             updateCart(
                                      //                 snapshot.data[i].service_id
                                      //                 ,snapshot.data[i].category_id
                                      //                 ,snapshot.data[i].vendor_id
                                      //                 ,snapshot.data[i].subcat_id
                                      //                 ,snapshot.data[i].service_name
                                      //                 ,snapshot.data[i].type
                                      //                 ,mrp
                                      //                 ,price
                                      //                 ,qty);
                                      //             },
                                      //             child: Container(
                                      //               width: 25,
                                      //               height: MediaQuery.of(
                                      //                   context)
                                      //                   .size
                                      //                   .height,
                                      //               decoration: BoxDecoration(
                                      //                   borderRadius:
                                      //                   BorderRadius.all(Radius.circular(5))),
                                      //               child:
                                      //               Center(
                                      //                 child:
                                      //                 Icon(
                                      //                   Icons.add,
                                      //                   color: Colors.white,
                                      //                   size: 15,

                                      //                 ),
                                      //               ),
                                      //             ),
                                      //           ),
                                      //         )
                                      //       )
                                      //     ],
                                      //   ),
                                      // ),
                                    ),
                                  )
                              )
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            )
        ),
      );
    }

  @override
  Widget build(BuildContext context) {

    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Payment methods",
          style: TextStyle(color: Colors.black, fontFamily: "opensan"),
        ),
        backgroundColor: Colors.white,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(FontAwesomeIcons.arrowLeft, color: Colors.black),
        ),
        elevation: 0.5,
      ),
      body: new SafeArea(
        child: new Container(
          child: new Stack(
            children: <Widget>[
              new Container(
                child: CustomScrollView(
                  slivers: <Widget>[
                    SliverToBoxAdapter(
                      child: new Container(
                        padding: EdgeInsets.only(top: 10),
                        child: Container(
                          color: Colors.white,
                          child: new Column(
                            children: <Widget>[
                              new Container(
                                padding: EdgeInsets.only(top: 10, bottom: 5),
                                child: new Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Text(
                                      "Online/Cash",
                                      style: TextStyle(
                                          fontFamily: "opensan",
                                          fontSize: 20,
                                          fontWeight: FontWeight.w500),
                                    )
                                  ],
                                ),
                              ),
                              new ListTile(
                                onTap: () {
                                  _setRadio(1);
                                },
                                title: Text(
                                  "Pay online after service",
                                  style: TextStyle(fontSize: 18),
                                ),
                                leading: Radio(
                                  value: 1,
                                  groupValue: radioset,
                                  activeColor: Colors.blue,
                                  onChanged: (val) {
                                    // print(address[index]['address_id']);
                                    _setRadio(1);
                                  },
                                ),
                              ),
                              new Container(
                                padding: EdgeInsets.only(left: 20, right: 20),
                                child: Divider(),
                              ),
                              new ListTile(
                                onTap: () {
                                  _setRadio(2);
                                },
                                title: Text(
                                  "Cash",
                                  // style: TextStyle(fontSize: 18),
                                ),
                                leading: SizedBox(
                                  child: Radio(
                                    value: 2,
                                    groupValue: radioset,
                                    activeColor: Colors.blue,
                                    onChanged: (val) {
                                      // print(address[index]['address_id']);
                                      _setRadio(2);
                                    },
                                  ),
                                ),
                                trailing: IconButton(
                                  onPressed: () {},
                                  icon: Icon(FontAwesomeIcons.infoCircle),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: new Container(
                        padding: EdgeInsets.only(top: 10),
                        child: Container(
                          color: Colors.white,
                          child: new Column(
                            children: <Widget>[
                              new Container(
                                padding: EdgeInsets.only(top: 10, bottom: 5),
                                child: new Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Text(
                                      "Other methods",
                                      style: TextStyle(
                                          fontFamily: "opensan",
                                          fontSize: 20,
                                          fontWeight: FontWeight.w500),
                                    )
                                  ],
                                ),
                              ),
                              new ListTile(
                                onTap: () async{
                                  setState((){
                                    liststate = true;
                                  });
                                  _setRadio(3);
                                },
                                title: Text(
                                  "Debit/Credit card,UPI,Wallets etc.",
                                  // style: TextStyle(fontSize: 18),
                                ),
                                leading: Radio(
                                  value: 3,
                                  groupValue: radioset,
                                  activeColor: Colors.blue,
                                  onChanged: (val) {
                                    // print(val);
                                    _setRadio(val);
                                  },
                                ),
                              ),
//                              new ListTile(
//                                onTap: (){
//                                  _setRadio(4);
//                                },
//                                title: Text("SOD Wallet"),
//                                leading: Radio(
//                                  value: 4,
//                                  groupValue: radioset,
//                                  activeColor: Colors.blue,
//                                  onChanged: (val) {
//                                    print(val);
//                                    _setRadio(val);
//                                  },
//                                ),
//                              ),
//                              new ListTile(
//                                onTap: (){
//                                  _setRadio(5);
//                                },
//                                title: Text("Apply Promocode"),
//                                leading: Radio(
//                                  value: 5,
//                                  groupValue: radioset,
//                                  activeColor: Colors.blue,
//                                  onChanged: (val) {
//                                    print(val);
//                                    _setRadio(val);
//                                  },
//                                ),
//                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                    _listReviews(),
                  ],
                ),
              ),
              
              new Positioned(
                top: 0,
                left: 0,
                right : 0,
                bottom: 0,
                child: loading == true ? new Container(
                  decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.5)
                  ),
                  child: new Center(
                    child: new SizedBox(
                        width: 50,
                        height: 50,
                        child : CircularProgressIndicator()
                    ),
                  ),
                ) : new Container(),
              )
            ],
          ),
        ),
      ),
      bottomNavigationBar: new Container(
        color: Colors.white,
        height: 60,
        padding: EdgeInsets.only(top: 5),
        child: new Column(
          children: <Widget>[
            new Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.only(left: 20),
                  child: new Text(
                    "\u20B9 "+widget.priceget.toString(),
                    style: TextStyle(
                      fontWeight: FontWeight.bold, 
                      fontSize: 20
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(right: 10),
                  child: new SizedBox(
                    height: 50,
                    child: FlatButton(
                      color: Colors.blueAccent,
                      onPressed: () async {
                        openCheckout();
                      },
                      child: Text(
                        "Place order",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: Colors.white
                        ),
                      ),
                    ),
                  ),
                ),
                
              ],
            )
          ],
        ),
      ),
    );
  }
}
