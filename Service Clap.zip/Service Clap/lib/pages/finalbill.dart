import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:service_app/animators/navianimator.dart';
import 'package:service_app/components/saperator.dart';
import 'package:service_app/pages/addressadd.dart';
import 'dart:io';
import 'dart:convert';
import 'dart:ui' as ui;
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:service_app/utils/apis.dart';
import 'package:shared_preferences/shared_preferences.dart';
//import 'package:flare_flutter/flare_actor.dart';
import 'package:service_app/pages/settime.dart';
import 'package:service_app/database/vendorcart.dart';
import 'package:service_app/database/vendordb_helper.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:sms_autofill/sms_autofill.dart';
import 'package:service_app/pages/alladdress.dart';

class FinalbillPage extends StatelessWidget {
  // final catid;
  // FinalbillPage({Key key, this.catid}) : super(key: key);

  final vendorid;
  FinalbillPage({Key key, this.vendorid}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return FinalbillLoader(vendorid: this.vendorid);
  }
}

class FinalbillLoader extends StatefulWidget {

  final vendorid;
  FinalbillLoader({Key key, this.vendorid}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return FinalbillView();
  }
}

class FinalbillView extends State<FinalbillLoader> with CodeAutoFill{

  String appSignature;
  String otpCode;
  String otpget;

  var login = false;

  checkLogin() async{
    var sp = await SharedPreferences.getInstance();
    if(sp.containsKey("login")){
      setState(() {
        login = true;
      });
    }
  }
  Future<List<Vendorcart>> cart;
  Future<dynamic> price;
  var dbHelper;
  var cartlen = 0;

  bool loading = false;
  List packs;
  int totalprice = 0;
  var listlen = 0;
  var cartid = 0;


  getPrice(){
    setState(() {
      price = dbHelper.getPrice(int.parse(widget.vendorid));
    });
  }

  var userid = false;
  Future getUserchk() async{
    var sp = await SharedPreferences.getInstance();
    if(sp.containsKey("userid")){
      setState(() {
        userid = true;
      });
    }
  }

  List<dynamic> cartdata = [];
  var liststate = false;

  addtoLists(productId,name,productType,proSetQtn,mrpPrice,secPrice,vendor_id) async{
    var data = {
          "productId" : productId,
          "variantId" : "",
          "productCode" : "",
          "name" : name,
          "productType" : "productType",
          "proSetQtn" : proSetQtn,
          "mrpPrice" : mrpPrice,
          "secPrice" : secPrice,
          "unit" : "",
          "vendor_id" : vendor_id
        };
        setState(() {
            cartdata.add(data);
        });
    
  }


  refreshList() {
    setState(() {
      cart = dbHelper.getCart(int.parse(widget.vendorid));
    });
  }

  updateCart(serviceid,categoryid,vendorid,subcatid,servicename,type,mrp,price,qty) async{
    cartdata.clear();
    Vendorcart c = Vendorcart(serviceid,categoryid,vendorid,subcatid,servicename,type,mrp,price,qty);
    dbHelper.update(c);
    getPrice();
    refreshList();
  }

  deleteCart(serviceid,categoryid) async{
    // setState(() {
      cartdata.clear();
    dbHelper.delete(serviceid);
//    Vibration.vibrate();
    getPrice();
    refreshList();
  }

  @override
  void codeUpdated() {
    setState(() {
      otpCode = code;
      otp.text = otpCode;
    });
  }

  void initState() {
    super.initState();
    listenForCode();
    SmsAutoFill().getAppSignature.then((signature) {
      //("signatures " + signature);
      setState(() {
        appSignature = signature;
      });
      print(appSignature);
    });
    dbHelper = VendorDbHelper();
    checkLogin();
    getPrice();
    refreshList();
  }


  
  void _onLoading() {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext context) {
      return Dialog(
        child: Padding(
          padding: EdgeInsets.only(
            left:20,
            right:20,
            top : 20,
            bottom: 20
          ),
          child : new Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              new CircularProgressIndicator(
              ),
              new Container(
                padding : EdgeInsets.only(
                  left:30
                ),
                child: new Text("Please wait..."),
              )
            ],
          )
        ),
      );
    },
  );
}

  var fillmobile = true;
  var mobile = TextEditingController();
  var otp = TextEditingController();
  var useridget = "";

  Future register() async{
    _onLoading();
    var url = Apis.BASE_URL + "Login/signup";
    var data = {"mobile" : mobile.text,"referral_code":"asdfggg","email":"","first_name":"","last_name":""};
    var res = await apiPostRequest(url,data);
    setState((){
      fillmobile = false;
      useridget = json.decode(res)['user_id'];
    });
    Navigator.pop(context);
    print(res);
  }

  Future loginUser() async{
    if( mobile.text == ""){

    }else{
      _onLoading();
      var url = Apis.BASE_URL + "Login";
      var data = {"mobile" : mobile.text, "message_key":appSignature};
      var res = await apiPostRequest(url,data);
      setState((){
        fillmobile = false;
        useridget = json.decode(res)['user_id'];
      });
      Navigator.pop(context);
      print(res);
    }

  }

  Future otpVerified() async{
    _onLoading();
    var sp = await SharedPreferences.getInstance();
    var url = Apis.BASE_URL + "Login/verifyOTP";
    var data = {"user_id" : useridget,"otp":otp.text,"device_type":"Android","device_id":"adssget35464","device_name":"Pixel 4"};
    print(data);
    var res = await apiPostRequest(url,data);
    if(json.decode(res)['status'].toString() == "1"){
        setState((){
          sp.setString("login", "true");
          sp.setString("userid", useridget.toString());
          login = true;
        });
    }else{

    }

    Navigator.pop(context);
    print(res);
  }

  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  @override
  Widget build(BuildContext context) {
    _getProducts(index, List lir) {
      return ListView.builder(
          itemCount: lir.length,
          physics: NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemBuilder: (BuildContext ctxt, int ind) {
            return new Align(
              alignment: Alignment.centerLeft,
              child: new Container(
                padding: EdgeInsets.only(bottom: 10),
                child: new Text(
                    packs[index]['products'][ind]['product_name'].toString()),
              ),
            );
          });
      // }
    }

  var mindelivery = "0";
  var delivercharge = "FREE";
  var minorders = "";

  Future _setCheckouts(price, mainprice) async {
    var sp = await SharedPreferences.getInstance();
    // var deliver = "0";
    // if ((int.parse(mindelivery) - int.parse(price)) <= 0) {
    //   deliver = "0";
    // } else {
    //   deliver = delivercharge;
    // }
    sp.setString("price", mainprice);
    sp.setString("mrp", price);
    Navigator.push(context, EnterExitRoute(enterPage: SettimePage(vendorid: widget.vendorid,price: mainprice,)));
  }
  
  checkoutbutton(){
    return FutureBuilder(
        future: price,
        builder: (context, AsyncSnapshot snapshot) {
          if (snapshot.data != null) {
            return new Container(
              child: new Container(
                        padding: EdgeInsets.only(top: 10),
                        child: new OutlineButton(
                          color: Colors.black,
                          onPressed: () {
                            _setCheckouts(
                              snapshot.data[0]["Price"].toString(),
                              snapshot.data[0]["discount_price"].toString());
                          },
                          child: new Container(
                            padding: EdgeInsets.only(top: 15, bottom: 15),
                            child: new Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                          "\u20B9 "+snapshot.data[0]['discount_price'].toString(),
                                          style: TextStyle(
                                              fontFamily: "opensan",
                                              fontSize: 17,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black),
                                        ),
                                new Row(
                                  children: <Widget>[
                                    new Text(
                                      "Proceed",
                                      style: TextStyle(
                                          fontSize: 17,
                                          fontFamily: "opensan",
                                          fontWeight: FontWeight.bold),
                                    ),
                                    new Padding(
                                      padding: EdgeInsets.only(left: 10),
                                      child: Icon(FontAwesomeIcons.arrowRight,
                                          size: 16),
                                    )
                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
            );
          } else if (snapshot.data == null) {
            return new Container(
              height: 10,
            );
          }

          return new Container(
            height: 10,
          );
        });
  }

    _listReviews() {
      return SliverToBoxAdapter(
        child: Container(
            child: FutureBuilder(
              future: cart,
              builder: (context, AsyncSnapshot<List<Vendorcart>> snapshot){
//                print("Name : "+snapshot.data[0].service_name.toString());
                print("id get: "+snapshot.data[0].category_id.toString());
                return ListView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: snapshot.data.length,
                  itemBuilder: (context, i){
                    print(snapshot.data.length);
                    // for(var i = 0; i < snapshot.data.length;i++){
                      print(snapshot.data[i].service_name);
                    // }
                    var qty = snapshot.data[i].qty.toString();
                    var productId = snapshot.data[i].service_id;
                    var name = snapshot.data[i].service_name;
                    var productType = snapshot.data[i].type;
                    var proSetQtn = snapshot.data[i].qty;
                    var mrpPrice = snapshot.data[i].mrp;
                    var secPrice = snapshot.data[i].price;
                    var vendors_id = snapshot.data[i].vendor_id;
                    if(cartdata.length < snapshot.data.length){
                      addtoLists(productId,name,productType,proSetQtn,mrpPrice,secPrice,vendors_id);
                    }
                    // setCartprice(snapshot.data[0]['Price'].toString(),snapshot.data[0]['mrp'].toString());
                    print(cartdata.toString());
                    return Card(
                      child: Container(
                        padding:EdgeInsets.only(
                          bottom: 10,
                          top : 10,
                        ),
                        child: ListTile(
                          title: Padding(
                            padding: EdgeInsets.only(
                              top: 0,
                            ),
                            child: Text(
                              snapshot.data[i].service_name.toString(),
                              style: TextStyle(
                                  fontFamily: "opensan",
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                          subtitle: new Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Padding(
                                  padding: EdgeInsets.only(top: 5),
                                  child: new Container(
                                      child: new Container(
                                        padding: EdgeInsets.only(
                                          left: 10,
                                          right: 10,
                                          top: 2,
                                          bottom: 2,
                                        ),
                                        color: Colors.red[50],
                                        child: Text(
                                          "\u20B9 "+snapshot.data[i].price.toString(),
                                          style: TextStyle(
                                              fontFamily: "opensan",
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      )),
                                ),
                              ),
                              SizedBox(
                                  width: 90,
                                  height: 35,
                                  child:
                                  // packs[index]['quantity'] == 0
                                  //     ?
                                  Material(
                                    color: Colors.white,
                                    borderRadius:
                                    BorderRadius.all(
                                        Radius
                                            .circular(
                                            5)),
                                    child: InkWell(
                                      borderRadius:
                                      BorderRadius
                                          .all(Radius
                                          .circular(
                                          5)),
                                      child:
                                      new Container(
                                        decoration: BoxDecoration(
                                            border: Border.all(
                                                color: Color.fromRGBO(
                                                    79,
                                                    155,
                                                    247,
                                                    1),
                                                width: 1),
                                            borderRadius:
                                            BorderRadius.all(
                                                Radius.circular(
                                                    5))),
                                        child: new Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment
                                              .spaceBetween,
                                          children: <Widget>[
                                            Expanded(
                                              child : Material(
                                                color: Color.fromRGBO(
                                                    79,
                                                    155,
                                                    247,
                                                    1),
                                                borderRadius:
                                                BorderRadius.only(
                                                  topLeft: Radius.circular(3),
                                                  bottomLeft: Radius.circular(3)
                                                ),
                                                child: InkWell(
                                                  borderRadius:
                                                  BorderRadius.all(
                                                      Radius
                                                          .circular(
                                                          5)),
                                                  onTap: (){
                                                  int qty = snapshot.data[0].qty - 1;
                                                  var mrp = snapshot.data[i].mrp;
                                                  var price = snapshot.data[i].price;
                                                  if(qty > 0){
                                                    updateCart(
                                                        snapshot.data[i].service_id
                                                        ,snapshot.data[i].category_id
                                                        ,snapshot.data[i].vendor_id
                                                        ,snapshot.data[i].subcat_id
                                                        ,snapshot.data[i].service_name
                                                        ,snapshot.data[i].type
                                                        ,mrp
                                                        ,price
                                                        ,qty);
                                                  }else{
                                                    deleteCart(snapshot.data[i].service_id, snapshot.data[i].category_id);
                                                  }
                                                  },
                                                  child: new Container(
                                                    width: 25,
                                                    height: MediaQuery.of(
                                                        context)
                                                        .size
                                                        .height,
                                                    decoration: BoxDecoration(

                                                        borderRadius:
                                                        BorderRadius.all(Radius.circular(5))),
                                                    child:
                                                    Center(
                                                      child:
                                                      Icon(
                                                        Icons.remove,
                                                        color: Colors.white,
                                                        size: 15,

                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              )
                                            ),
                                            Expanded(
                                              child: Center(
                                                child: new Container(
                                                  // padding: EdgeInsets
                                                  //     .only(
                                                  //     left:
                                                  //     10),
                                                  child: Text(snapshot.data[i].qty.toString(),
                                                    style: TextStyle(
                                                        fontFamily:
                                                        "opensan",
                                                        fontWeight: FontWeight
                                                            .w600,
                                                        fontSize: 13,
                                                        color: Color.fromRGBO(
                                                            79,
                                                            155,
                                                            247,
                                                            1)),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Expanded(
                                              child : new Material(
                                                color: Color.fromRGBO(
                                                    79,
                                                    155,
                                                    247,
                                                    1),
                                                borderRadius:
                                                BorderRadius.only(
                                                    topRight: Radius.circular(3),
                                                  bottomRight: Radius.circular(3)
                                                ),
                                                child: InkWell(
                                                  borderRadius:
                                                  BorderRadius.all(
                                                      Radius
                                                          .circular(
                                                          5)),
                                                  onTap: (){
                                                  int qty = snapshot.data[i].qty + 1;
                                                  var mrp = snapshot.data[i].mrp;
                                                  var price = snapshot.data[i].price;
                                                  updateCart(
                                                      snapshot.data[i].service_id
                                                      ,snapshot.data[i].category_id
                                                      ,snapshot.data[i].vendor_id
                                                      ,snapshot.data[i].subcat_id
                                                      ,snapshot.data[i].service_name
                                                      ,snapshot.data[i].type
                                                      ,mrp
                                                      ,price
                                                      ,qty);
                                                  },
                                                  child: Container(
                                                    width: 25,
                                                    height: MediaQuery.of(
                                                        context)
                                                        .size
                                                        .height,
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                        BorderRadius.all(Radius.circular(5))),
                                                    child:
                                                    Center(
                                                      child:
                                                      Icon(
                                                        Icons.add,
                                                        color: Colors.white,
                                                        size: 15,

                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              )
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  )
                              )
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            )
        ),
      );
    }

    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "Cart",
            style: TextStyle(
                color: Colors.black,
                fontFamily: "opensan",
                fontWeight: FontWeight.bold),
          ),
          backgroundColor: Colors.white,
          elevation: 1,
          leading: IconButton(
              icon: Icon(
                FontAwesomeIcons.arrowLeft,
                color: Colors.black,
              ),
              onPressed: () {
                Navigator.pop(context);
              }),
        ),
        body: Stack(
          children: <Widget>[
            new Container(
              child: CustomScrollView(
                slivers: <Widget>[
                  new SliverPadding(
                    padding: EdgeInsets.only(top: 0),
                    sliver: new SliverToBoxAdapter(
                      child: FutureBuilder(
                        future: price,
                        builder : (context, snapshot){
                          if(snapshot.data != null){
                            return snapshot.data[0]['Price'].toString() != "null"
                                ?new Container(
                              color: Colors.white,
                              padding: EdgeInsets.only(
                                  left: 20, right: 20, top: 20, bottom: 20),
                              child: Column(
                                children: [
                                 Container(
                                   padding: EdgeInsets.only(
                                     bottom: 10
                                   ),
                                   child :  new Row(
                                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                     children: <Widget>[
                                       new Text(
                                         "Item MRP",
                                         style: TextStyle(
                                             fontFamily: "opensan",
                                             fontSize: 15,
//                                            fontWeight: FontWeight.bold,
                                             color: Colors.black54),
                                       ),
                                       new Text(
                                         "\u20B9 "+snapshot.data[0]['Price'].toString(),
                                         style: TextStyle(
                                             fontFamily: "opensan",
                                             fontSize: 15,
//                                            fontWeight: FontWeight.bold,
                                             color: Colors.black54),
                                       )
                                     ],
                                   ),
                                 ),
                                  Container(
                                    padding: EdgeInsets.only(
                                        bottom: 10
                                    ),
                                    child: new Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                        new Text(
                                          "Item total",
                                          style: TextStyle(
                                              fontFamily: "opensan",
                                              fontSize: 15,
//                                            fontWeight: FontWeight.bold,
                                              color: Colors.black54),
                                        ),
                                        new Text(
                                          "\u20B9 "+snapshot.data[0]['discount_price'].toString(),
                                          style: TextStyle(
                                              fontFamily: "opensan",
                                              fontSize: 15,
//                                            fontWeight: FontWeight.bold,
                                              color: Colors.black54),
                                        )
                                      ],
                                    ),
                                  ),
                                  Divider(
                                    color: Colors.black38,
                                  ),
                                  Container(
                                    padding: EdgeInsets.only(
                                        top: 10
                                    ),
                                    child: new Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                        new Text(
                                          "Total",
                                          style: TextStyle(
                                              fontFamily: "opensan",
                                              fontSize: 17,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black),
                                        ),
                                        new Text(
                                          "\u20B9 "+snapshot.data[0]['discount_price'].toString(),
                                          style: TextStyle(
                                              fontFamily: "opensan",
                                              fontSize: 17,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black),
                                        )
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            )
                                :Container();
                          }
                          else if(snapshot.data == null){
                            return new  Container(
                              height: 10,
                            );
                          }
                          return new  Container(
                            height: 10,
                          );
                        },
                      ),
                    ),
                  ),
                  SliverPadding(
                    padding: EdgeInsets.only(top: 10, bottom: 10),
                    sliver: _listReviews(),
                  )
                ],
              ),
            ),
            Positioned(
              top: 0,
              bottom: 0,
              left: 0,
              right: 0,
              child: loading == true
                  ? new Container(
                      color: Colors.white.withOpacity(0.8),
                      child: new Center(
                        child: new Container(
                          // color: Colors.black26,
                          width: 200,
                          height: 200,
//                          child: FlareActor(
//                            "assets/animations/loadKnife.flr",
//                            animation: "Untitled",
//                            // color: Colors.blueAccent,
//                            // isPaused: true,
//                          ),
                        ),
                      ),
                    )
                  : new Container(),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right : 0,
              child: BottomAppBar(
              child: login == true?new Container(
              // height: 200,
              child: new Column(
              children: <Widget>[
                new Container(
                  // height: 200,
                  padding:
                      EdgeInsets.only(left: 20, right: 20, top: 0, bottom: 10),
                  child: new Column(
                    children: <Widget>[
                      checkoutbutton()
                    ],
                  ),
                )
              ],
            ),
          ): fillmobile == true ?Container(
              height: 200,
              child: Column(
                children: [
                  new Container(
                    padding: EdgeInsets.only(
                      top: 20
                    ),
                    child: Center(
                      child: Text(
                        "Please Login to proceed",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87
                        ),
                      ),
                    ),
                  ),
                  new Container(
                    padding: EdgeInsets.only(
                      top : 20,
                      left: 20,
                      right : 20
                    ),
                    child: Container(
                      height: 50,
                      child: Row(
                        children: [
                          Expanded(
                            flex: 1,
                            child: Container(
                              decoration: BoxDecoration(
                                border: Border(
                                  left: BorderSide(
                                    color: Colors.black12
                                  ),
                                  bottom: BorderSide(
                                    color: Colors.black12
                                  ),
                                  top: BorderSide(
                                    color: Colors.black12
                                  ),
                                  right: BorderSide(
                                    color: Colors.black12
                                  ),
                                ),
                                borderRadius: BorderRadius.only(
                                  topLeft : Radius.circular(5),
                                  bottomLeft : Radius.circular(5)
                                )
                              ),
                              child: Center(
                                child : Text(
                                  "+91",
                                  style: TextStyle(
                                    color: Colors.black
                                  ),
                                )
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 4,
                            child: Container(
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: Colors.black12
                                ),
                                borderRadius: BorderRadius.only(
                                  topRight : Radius.circular(5),
                                  bottomRight : Radius.circular(5)
                                )
                              ),
                              child: Center(
                                child : TextField(

                                  controller: mobile,
                                  decoration: InputDecoration(
                                    contentPadding: EdgeInsets.only(
                                      left: 20
                                    ),
                                      counterText: "",
                                    hintText: "Mobile Number",
                                    border: InputBorder.none
                                  ),
                                  keyboardType: TextInputType.number,
                                  maxLength: 10,
                                )
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  
                  new Container(
                    padding: EdgeInsets.only(
                      left:20,
                      right : 20,
                      top: 15
                    ),
                    child: SizedBox(
                      height: 50,
                      width: MediaQuery.of(context).size.width,
                      child: FlatButton(
                      onPressed: (){
                        loginUser();
                      },
                      color: Colors.black,
                      child : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "Login / SignUp",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16
                            ),  
                          ),
                          Container(
                            child: Icon(
                              Icons.chevron_right,
                              color: Colors.white
                            ),
                          )
                        ],
                      )
                      ),
                    ),
                  )
                ],
              ),
            ):Container(
              height: 200,
              child: Column(
                children: [
                  new Container(
                    padding: EdgeInsets.only(
                      top: 20
                    ),
                    child: Center(
                      child: Text(
                        "Enter verification code",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87
                        ),
                      ),
                    ),
                  ),
                  new Container(
                    padding: EdgeInsets.only(
                      top: 10
                    ),
                    child: Center(
                      child: Text(
                        "We have sent you a 6 digit verification code on",
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.black45
                        ),
                      ),
                    ),
                  ),
                   new Container(
                    padding: EdgeInsets.only(
                      top: 5
                    ),
                    child: Center(
                      child: Text(
                        mobile.text,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.black,
                          fontWeight : FontWeight.bold
                        ),
                      ),
                    ),
                  ),
                  Container(
                    padding : EdgeInsets.only(
                      left : 20,
                      right : 20,
                      bottom: 10,
                      top : 20
                    ),
                  //   child:PinCodeTextField(
                  //   appContext: context,
                  //   pastedTextStyle: TextStyle(
                  //           color: Colors.green.shade600,
                  //           fontWeight: FontWeight.bold,
                  //         ),
                  //   length: 6,
                  //   obscureText: false,
                  //   obscuringCharacter: '*',
                  //   animationType: AnimationType.fade,
                  //   cursorColor: Colors.black,
                  //   keyboardType: TextInputType.number,
                  //   pinTheme: PinTheme(
                  //           shape: PinCodeFieldShape.box,
                  //           borderRadius: BorderRadius.circular(5),
                  //           fieldHeight: 50,
                  //           fieldWidth: MediaQuery.of(context).size.width/8,
                  //           activeColor: Colors.black,
                  //           activeFillColor: Colors.black38,
                  //           borderWidth: 1,
                  //           inactiveColor: Colors.black38
                  //   ),
                  //   onCompleted: (res){
                  //     otpVerified();
                  //   },
                  //   controller: otp,
                  // )
                      child: PinCodeTextField(
                        length: 6,
                        autoDismissKeyboard: false,
                        obsecureText: false,
                        // animationType: AnimationType.fade,
                        // shape: PinCodeFieldShape.underline,
                        animationDuration: Duration(milliseconds: 300),
                        borderRadius: BorderRadius.circular(5),
                        fieldHeight: 50,
                        fieldWidth: 50,
                        controller: otp,
                        activeFillColor: Colors.grey,
                        activeColor: Colors.greenAccent,
                        inactiveColor: Color.fromRGBO(0, 186, 142, 1),
                        selectedColor: Colors.redAccent,
                        textInputType: TextInputType.number,
                        // onChanged: (value) {
                        //   if (value.length == 6) {
                        //     setState(() {
                        //       // otpset = true;
                        //       otpget = value;
                        //       //(value);
                        //     });
                        //   } else if (value.length < 6) {
                        //     setState(() {
                        //       // otpset = false;
                        //     });
                        //   }
                        // },
                        onCompleted: (value){
                          otpVerified();
                        },
                      )
                  ),
                ],
              ),
            ),
        ),
            )
          ],
        ),
        // bottomNavigationBar: 
      ),
    );
  }
}
