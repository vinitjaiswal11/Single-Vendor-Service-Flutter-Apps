import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:service_app/animators/navianimator.dart';
import 'package:service_app/pages/mainpage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:service_app/utils/apis.dart';
import 'dart:io';
import 'package:intl/intl.dart';
import 'dart:core';

class OrderdetailPage extends StatelessWidget {

  final bookingid;
  final index;
  OrderdetailPage({Key key,this.bookingid,this.index}):super(key : key);
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return OrderdetailLoader(bookingid:this.bookingid,index: index);
  }
}

class OrderdetailLoader extends StatefulWidget {
  final bookingid;
  final index;
  OrderdetailLoader({Key key,this.bookingid,this.index}):super(key : key);
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return OrderdetailView();
  }
}

class OrderdetailView extends State<OrderdetailLoader> {
  var orderlen = 0;
  var loading = false;
  List orders = [];
  var d_date = "";
  var d_time = "";
  var d_loc = "";
  List packages = [];
  var packagelen = 0;
  var partnernae = "";
  var partner_mobile = "";
  var partlen = 0;
  var packlen = 0;
  var address = "";
  var discountprice = "";
  var mrp = "";
  var sell_price = "";
  var paid_ammount = "";
  var payment_method = "";
  var categoryname = "";
  var order_status = '';
  Future _orders() async{
    // _onLoading();
    setState((){
      loading = true;
    });
    var sp = await SharedPreferences.getInstance();
    var userid = sp.getString("userid");
    var url = Apis.BASE_URL +"Orders/details";
    var datas = {
      "order_id" : widget.bookingid
    };
    // print(datas);
    var res = await apiPostRequest(url,datas);
    print(res);
    if(json.decode(res)['status'] ==  "1"){
      setState((){
        order_status = json.decode(res)['user_details']['order_status'];
        discountprice = json.decode(res)['user_details']['product_discount'];
        mrp = json.decode(res)['user_details']['mrp'];
        sell_price = json.decode(res)['user_details']['sel_price'];
        paid_ammount = json.decode(res)['user_details']['paid_amount'];
        payment_method = json.decode(res)['user_details']['payment_method'];
        d_date = json.decode(res)['user_details']['delivery_date'];
        d_time = json.decode(res)['user_details']['delivery_time'];
        partnernae = json.decode(res)['user_details']['vendor_name'];
        partner_mobile = json.decode(res)['user_details']['vendor_phone'];
        categoryname = json.decode(res)['user_details']['category_name'];

        address = json.decode(res)['user_details']['geo_address'];
        packages = json.decode(res)['product_details'];
        packagelen = packages.length;
        loading = false;
      });
      // setState((){
      //   loading = false;
      //   orders = json.decode(res)['user_details'];
      //   orderlen = orders.length;
      // });
    }
    // Navigator.pop(context);
    print(json.decode(res)['user_details']['order_status']);
  }

  cancelOrder() async{
    _onLoading();
    var url = Apis.BASE_URL+"Orders/canceled";
    var data = {
      "order_id" : widget.bookingid
    };
    var res = await apiPostRequest(url,data);
    Navigator.pop(context);
    _orders();
    cancelDailog("Your order have been canceled");

  }

  void _onLoading() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Dialog(
          child: Padding(
              padding: EdgeInsets.only(
                  left:20,
                  right:20,
                  top : 20,
                  bottom: 20
              ),
              child : new Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  new CircularProgressIndicator(
                  ),
                  new Container(
                    padding : EdgeInsets.only(
                        left:30
                    ),
                    child: new Text("Please wait..."),
                  )
                ],
              )
          ),
        );
      },
    );
  }

  alertDailog(text) async{
    showDialog(
        context: context,
        builder:(context){
          return AlertDialog(
            title: Text("Alert"),
            content: Text(text),
            actions: [
              FlatButton(
                onPressed: (){
                  Navigator.pop(context);
                  cancelOrder();

                },
                child: Text("Yes"),
              ),
              FlatButton(
                onPressed: (){
                  Navigator.pop(context);
                },
                child: Text("No"),
              )
            ],
          );
        }
    );
  }
  cancelDailog(text) async{
    showDialog(
        context: context,
        builder:(context){
          return AlertDialog(
            title: Text("Alert"),
            content: Text(text,
              style:TextStyle(
                  fontSize: 15
              ) ,),
            actions: [
              FlatButton(
                onPressed: (){
                  Navigator.pop(context);
                },
                child: Text("Ok"),
              ),

            ],
          );
        }
    );
  }
  
  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.API_KEY);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  @override
  void initState(){
    super.initState();
    _orders();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return WillPopScope(
      onWillPop: (){
        Navigator.of(context).pushAndRemoveUntil(FadeRoute(page: MainpagePage(pageview: 1,)), (Route<dynamic> route) => false);
      },
      child: SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          iconTheme: IconThemeData(
            color : Colors.black
          ),
        ),
        backgroundColor: Color.fromRGBO(236, 239, 241, 1),
        body: Stack(
          children: <Widget>[
            new Container(
              child: loading == false ?new CustomScrollView(
                slivers: <Widget>[
                  SliverToBoxAdapter(
                      child: Material(
                    child: Hero(
                      child: new Container(
                        // padding: EdgeInsets.only(bottom: 10),
                        child: new Container(
                          width: 100,
                          height: 60,
                          child: Stack(
                            children: <Widget>[
                              order_status == '1' ? Shimmer.fromColors(
                                baseColor: Color.fromRGBO(0, 150, 136, 1),
                                highlightColor: Color.fromRGBO(77, 182, 172, 1),
                                child: new Container(
                                  decoration: BoxDecoration(
                                    color: Colors.green,
                                    // borderRadius: BorderRadius.all(
                                    //   const Radius.circular(3)
                                    // )
                                  ),
                                  padding: EdgeInsets.only(
                                      left: 10, right: 10, bottom: 5),
                                ),
                              ):Shimmer.fromColors(
                                baseColor: Colors.redAccent,
                                highlightColor: Colors.redAccent,
                                child: new Container(
                                  decoration: BoxDecoration(
                                    color: Colors.redAccent,
                                    // borderRadius: BorderRadius.all(
                                    //   const Radius.circular(3)
                                    // )
                                  ),
                                  padding: EdgeInsets.only(
                                      left: 10, right: 10, bottom: 5),
                                ),
                              ),
                              Positioned(
                                  child: order_status == '1' ? new Center(
                                child: new Text(
                                  "Booking Accepted",
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                      fontFamily: "opensan"),
                                  textAlign: TextAlign.center,
                                ),
                              ):Center(
                                    child: new Text(
                                      "Booking Canceled",
                                      style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white,
                                          fontFamily: "opensan"),
                                      textAlign: TextAlign.center,
                                    ),
                                  )
                              )
                            ],
                          ),
                        ),
                      ),
                      tag: "sim"+widget.index.toString(),
                    ),
                  )),
                  new SliverToBoxAdapter(
                    child: new Container(
                      // padding: EdgeInsets.only(
                      //  top: 10
                      // ),
                      child: new Container(
                          padding: EdgeInsets.only(
                              left: 20, right: 20, top: 10, bottom: 10),
                          decoration: BoxDecoration(color: Colors.white),
                          child: new ListTile(
                            title: Center(
                              child: Text(
                                "Service Booked for",
                                style: TextStyle(
                                  fontFamily: "opensan",
                                ),
                              ),
                            ),
                            subtitle: Center(
                              child: Text(
                                categoryname,
                                style: TextStyle(
                                    fontFamily: "opensan",
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.black),
                              ),
                            ),
                          )),
                    ),
                  ),
                  new SliverToBoxAdapter(
                    child: new Container(
                      child: Container(
                        child: new Column(
                          children: <Widget>[
                            new Hero(
                              tag: "part"+widget.index.toString(),
                              child: Material(
                                child: new Container(
                                  // height: 80,
                                  padding: EdgeInsets.only(top: 10, bottom: 10),
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border(
                                          bottom: BorderSide(
                                              color: Colors.black45,
                                              width: 0.4),
                                          top: BorderSide(
                                              color: Colors.black45,
                                              width: 0.4))),
                                  child: SizedBox(
                                    child: partnernae != "" ? new ListTile(
                                      leading: new Container(
                                          width: 60.0,
                                          height: 60.0,
                                          child: CircleAvatar(
                                            child: Icon(
                                                FontAwesomeIcons.user
                                            ),
                                          ),
//                                          decoration: new BoxDecoration(
//                                              shape: BoxShape.rectangle,
//                                              image: new DecorationImage(
//                                                  fit: BoxFit.fill,
//                                                  image: new NetworkImage(
//                                                      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTp0bwUxYW5jRkv9nDhaXCGyAo6BekDenATQUZgeFu0A8g_-n66"))
//                                          )
                                      ),
                                      title: Text(
                                        partnernae.toString().toUpperCase(),
                                        style: TextStyle(
                                            fontFamily: "opensan",
                                            fontSize: 17,
                                            fontWeight: FontWeight.bold),
                                      ),
//                                       subtitle: new Padding(
//                                         padding: EdgeInsets.only(top: 5),
//                                         child: new Row(
//                                           children: <Widget>[
// //                                            new Padding(
// //                                              padding:
// //                                                  EdgeInsets.only(left: 10),
// //                                              child: Text(
// //                                                "120 Rattings",
// //                                                style: TextStyle(
// //                                                    fontFamily: "opensan",
// //                                                    color: Colors.black54,
// //                                                    fontSize: 12
// //                                                ),
// //                                              ),
// //                                            )
//                                           ],
//                                         ),
//                                       ),
                                      trailing: SizedBox(
                                        width: 40,
                                        height: 40,
                                        child: Material(
                                          borderRadius: BorderRadius.all(
                                              const Radius.circular(120)),
                                          color:
                                          Color.fromRGBO(79, 195, 247, 0.4),
                                          child: InkWell(
                                            onTap: () async {
                                              var number =
                                                  "$partner_mobile"; //set the number here
                                              bool res =
                                              await FlutterPhoneDirectCaller
                                                  .callNumber(number);
                                            },
                                            splashColor: Color.fromRGBO(
                                                79, 195, 247, 0.7),
                                            borderRadius: BorderRadius.all(
                                                const Radius.circular(120)),
                                            child: Center(
                                              child: Icon(
                                                FontAwesomeIcons.phoneAlt,
                                                color: Color.fromRGBO(
                                                    30, 136, 229, 1),
                                                size: 20,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ):new Container(
                                      child: new Center(
                                        child : Text(
                                          "Partner yet to assign",
                                            style: TextStyle(
                                                fontFamily:
                                                "opensan",
                                                color: Color
                                                    .fromRGBO(
                                                    0,
                                                    150,
                                                    136,
                                                    1),
                                                fontWeight:
                                                FontWeight
                                                    .bold)
                                        )
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            new Container(
                                width: MediaQuery.of(context).size.width,
                                decoration: BoxDecoration(color: Colors.white),
                                child: ListTile(
                                  leading: Container(
                                      width: 40,
                                      height: 40,
                                      child: Center(
                                        child: Icon(
                                          FontAwesomeIcons.locationArrow,
                                          size: 15,
                                        ),
                                      )),
                                  title: new Text(
                                      "Arriving on",
                                      style: TextStyle(
                                        fontFamily: "opensan",
                                        color: Colors.black,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14
                                      ),
                                  ),
                                  subtitle: Padding(
                                    padding: EdgeInsets.only(top: 5),
                                    child: Text(
                                      getdays(d_date)+" on "+d_time,
                                      style: TextStyle(
                                          fontFamily: "opensan",
                                          color: Colors.black54,
                                          fontSize: 14
                                        ),
                                    ),
                                  ),
                                  // trailing: IconButton(
                                  //   onPressed: () {},
                                  //   icon: Icon(
                                  //     FontAwesomeIcons.sync,
                                  //     size: 15,
                                  //   ),
                                  // ),
                                )),
                            new Container(
                                width: MediaQuery.of(context).size.width,
                                decoration: BoxDecoration(color: Colors.white),
                                child: ListTile(
                                  leading: Container(
                                      width: 40,
                                      height: 40,
                                      child: Center(
                                        child: Icon(
                                          Icons.my_location,
                                          size: 15,
                                        ),
                                      )),
                                      title: Text(
                                    "Service Location",
                                      style: TextStyle(
                                        fontFamily: "opensan",
                                        color: Colors.black,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14
                                      ),
                                  ),
                                  subtitle: Text(
                                    address,
                                    style: TextStyle(
                                        fontFamily: "opensan",
                                        color: Colors.black54,
                                        fontSize: 14
                                        ),
                                  ),
                                ))
                          ],
                        ),
                      ),
                    ),
                  ),
                  new SliverToBoxAdapter(
                    child: new Container(
                      padding: EdgeInsets.only(top: 10),
                      child: new Container(
                          padding: EdgeInsets.only(
                              left: 20, right: 20, top: 10, bottom: 10),
                          decoration: BoxDecoration(color: Colors.white),
                          child: new Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              new Container(
                                padding: EdgeInsets.only(
                                  bottom: 10
                                ),
                                  child: Text(
                                "Invoice",
                                style: TextStyle(
                                  fontFamily: "opensan",
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold
                                ),
                              )),
                              ListView.builder(
                                shrinkWrap: true,
                                physics: NeverScrollableScrollPhysics(),
                                itemCount: packagelen,
                                itemBuilder: (context, i){
                                  return Container(
                                    padding: EdgeInsets.only(
                                          top: 10,
                                          right: 10,
                                        ),
                                    child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsets.only(
                                                      left: 0,
                                                      right: 10,
                                                      top: 5
                                                  ),
                                                  child: Text(
                                                    packages[i]['product_name']+" ",
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        color: Colors.black,
                                                        fontWeight: FontWeight.w500
                                                    ),),


                                                ),

                                                Text(
                                                  "₹"+(double.parse(packages[i]['sel_price'])).round().toString(),
                                                  style: TextStyle(
                                                      fontSize: 11,
                                                      color: Colors.black,
                                                      fontWeight: FontWeight.w500
                                                  ),)


                                              ],
                                            ),
                                  );
                                },
                              ),
                              ListView.builder(
                                shrinkWrap: true,
                                physics: NeverScrollableScrollPhysics(),
                                itemCount: 1,
                                itemBuilder: (context, i) {
                                  return  new Container(
                                    color: Colors.white,
                                    child: Container(
                                        padding: EdgeInsets.only(
                                          top: 10,
                                          right: 10,
                                          left: 0,
                                          bottom: 10,
                                        ),
                                        child:Column(
                                          children: [
                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Padding(padding: EdgeInsets.only(
                                                    left: 0,
                                                    right: 10,
                                                    top: 10
                                                ),
                                                  child: Text("MRP",
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        color: Colors.black,
                                                        fontWeight: FontWeight.w500
                                                    ),),
                                                ),
                                                Text("₹"+double.parse(mrp).round().toString(),
                                                  style: TextStyle(
                                                      fontSize: 11,
                                                      color: Colors.black,
                                                      fontWeight: FontWeight.w500
                                                  ),)

                                              ],
                                            ),
                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Padding(padding: EdgeInsets.only(
                                                    left: 0,
                                                    right: 10,
                                                    top: 10
                                                ),
                                                  child: Text("Sell price",
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        color: Colors.black,
                                                        fontWeight: FontWeight.w500
                                                    ),),
                                                ),
                                                Text("₹"+double.parse(sell_price).round().toString(),
                                                  style: TextStyle(
                                                      fontSize: 11,
                                                      color: Colors.black,
                                                      fontWeight: FontWeight.w500
                                                  ),)

                                              ],
                                            ),
                                            // Row(
                                            //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            //   children: [
                                            //     Padding(padding: EdgeInsets.only(
                                            //         left: 0,
                                            //         right: 10,
                                            //         top: 10
                                            //     ),
                                            //       child: Text("Safety Amount",
                                            //         style: TextStyle(
                                            //             fontSize: 11,
                                            //             color: Colors.black,
                                            //           fontWeight: FontWeight.w500
                                            //         ),),
                                            //     ),

                                            //     Text("₹50",
                                            //       style: TextStyle(
                                            //           fontSize: 11,
                                            //           color: Colors.black,
                                            //           fontWeight: FontWeight.w500
                                            //       ),)

                                            //   ],
                                            // ),
                                            // Row(
                                            //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            //   children: [
                                            //     Padding(
                                            //       padding: EdgeInsets.only(
                                            //           left: 0,
                                            //           right: 10,
                                            //           top: 5
                                            //       ),
                                            //       child: Text("This helps us implement the best hygiene standards",
                                            //         style: TextStyle(
                                            //             fontSize: 10,
                                            //             color: Colors.black45,
                                            //             fontWeight: FontWeight.w500
                                            //         ),),


                                            //     ),




                                            //   ],
                                            // ),
                                            Divider(),
                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Padding(padding: EdgeInsets.only(
                                                    left: 0,
                                                    right: 10,
                                                    top: 0
                                                ),
                                                  child: Text(
                                                    payment_method == "Cash" ?"Amount Paid":"Amount to Pay",
                                                    style: TextStyle(
                                                        fontSize: 13,
                                                        fontWeight: FontWeight.w500,
                                                        color: Colors.black
                                                    ),),
                                                ),
                                                Text("₹"+double.parse(paid_ammount).round().toString(),style: TextStyle(
                                                    fontSize: 13,
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.black
                                                ),)


                                              ],
                                            ),
                                          ],
                                        )


                                    ),
                                  );
                                },
                              ),
                            ],
                          )),
                    ),
                  )
                ],
              )
                  :Container(
                child: Center(
                  child: SizedBox(
                    width: 30,
                    height : 30,
                    child:CircularProgressIndicator(

                    ),
                  ),
                ),
              )
            )
          ],
        ),
        bottomNavigationBar: BottomAppBar(
          elevation: 0,
          child: new Container(
            height: 55,
            decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                    top: BorderSide(
                  color: Colors.black38,
                  width: 0.5,
                ))),
            child: new Row(
              children: <Widget>[
                Flexible(
                    child: new Material(
                  color: Colors.white,
                  child: InkWell(
                    onTap: () {
//                      Navigator.push(context, FadeRoute(page: Main));
                      Navigator.of(context).pushAndRemoveUntil(FadeRoute(page: MainpagePage(pageview: 1,)), (Route<dynamic> route) => false);
                    },
                    child: new Container(
                      child: Center(
                        child: new Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Padding(
                              padding: EdgeInsets.only(right: 5),
                              child: Icon(
                                FontAwesomeIcons.times,
                                size: 18,
                                color: Color.fromRGBO(84, 110, 122, 1),
                              ),
                            ),
                            new Text(
                              "Close",
                              style: TextStyle(
                                fontFamily: "opensan",
                                fontWeight: FontWeight.w600,
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                )),
//                Flexible(
//                    child: new Material(
//                  color: Colors.white,
//                  child: InkWell(
//                    onTap: () {},
//                    child: new Container(
//                      decoration: BoxDecoration(
//                          // color: Colors.white,
//                          border: Border(
//                              left: BorderSide(
//                                color: Colors.black38,
//                                width: 0.5,
//                              ),
//                              right: BorderSide(
//                                color: Colors.black38,
//                                width: 0.5,
//                              ))),
//                      child: Center(
//                        child: new Row(
//                          mainAxisAlignment: MainAxisAlignment.center,
//                          children: <Widget>[
//                            // Padding(
//                            //   padding: EdgeInsets.only(right: 5),
//                            //   child: Icon(
//                            //     FontAwesomeIcons.hireAHelper,
//                            //     size: 18,
//                            //     color: Color.fromRGBO(84, 110, 122, 1),
//                            //   ),
//                            // ),
//                            new Text(
//                              "Need Help?",
//                              style: TextStyle(
//                                fontFamily: "opensan",
//                                fontWeight: FontWeight.w600,
//                              ),
//                            )
//                          ],
//                        ),
//                      ),
//                    ),
//                  ),
//                )),
                order_status == '1'?Flexible(
                    child: new Material(
                  color: Colors.white,
                  child: InkWell(
                    onTap: () {
                      alertDailog("Do yo want to cancel this order");
                    },
                    child: new Container(
                      child: Center(
                        child: new Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Padding(
                              padding: EdgeInsets.only(right: 5),
                              child: Icon(
                                FontAwesomeIcons.trash,
                                size: 18,
                                color: Color.fromRGBO(216, 27, 96, 1),
                              ),
                            ),
                            new Text(
                              "Cancel",
                              style: TextStyle(
                                fontFamily: "opensan",
                                fontWeight: FontWeight.w600,
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                )):Container()
              ],
            ),
          ),
        ),
      ),
    )
    );
  }
  
  getdays(String text) {
    var string = text;
//    var now = new DateTime.now();
    var formatter = new DateFormat('d MMM');
    String formatted = formatter.format(DateTime.parse(string));
    return formatted.toUpperCase();
  }

  getTime(String text){
    var string = text;
    var formatter = new DateFormat().add_jm();
    String formatted = formatter.format(DateTime.parse(string));
    return formatted;
  }
}
