import 'package:flutter/material.dart';
import 'package:in_app_update/in_app_update.dart';
import 'dart:async';
import 'dart:convert';
//import 'package:webview_flutter/webview_flutter.dart';
//import 'dart:async';
//import 'dart:convert';
//import 'package:flutter/material.dart';
//import 'package:webview_flutter/webview_flutter.dart';
////import 'package:http/http.dart' as http;
//import 'dart:async';
//import 'dart:convert';
//import 'package:service_app/pages/home.dart';
import 'package:service_app/pages/login.dart';
//import 'package:service_app/animators/navianimator.dart';
//import 'package:shared_preferences/shared_preferences.dart';
import 'package:service_app/pages/mainpage.dart';
import 'package:service_app/pages/splashscreen.dart';
//import 'package:service_app/pages/setlocation.dart';
//import 'package:firebase_messaging/firebase_messaging.dart';
//import 'package:fluttertoast/fluttertoast.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Bipin Video Lab',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
//      home: MainpagePage(pageview: 0,),
      home: Splashscreen(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  AppUpdateInfo _updateInfo;
  GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey();

  Future<void> checkForUpdate() async {
    InAppUpdate.checkForUpdate().then((info) {
      print(json.decode(info.toString())['InAppUpdateState']['updateAvailable:']);
      // setState(() {
      //   _updateInfo = info;
      // });
    }).catchError((e) => _showError(e));
  }
  void _showError(dynamic exception) {
    _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text(exception.toString())));
  }
//  final FirebaseMessaging _messaging = FirebaseMessaging();
//
//
//
//  Future getStart() async{
//    SharedPreferences sp = await SharedPreferences.getInstance();
//    sp.getString("userid");
//    Timer(Duration(seconds: 1), (){
//      if(sp.containsKey("userid") == true){
//        Navigator.of(context).pushAndRemoveUntil(FadeRoute(page: HomePage()), (Route<dynamic> route) => false);
//      }else{
//        Navigator.of(context).pushAndRemoveUntil(FadeRoute(page: LoginPage()), (Route<dynamic> route) => false);
//      }
//    });
//  }
//
//  Future checkUser() async{
//    var sp = await SharedPreferences.getInstance();
//    Timer(Duration(seconds: 1), (){
//    if(sp.containsKey("token")){
//      if(sp.containsKey("location")){
//        Navigator.of(context).pushAndRemoveUntil(
//          FadeRoute(page: MainpagePage(pageview: 0,)), (Route<dynamic> route) => false);
//      }else{
//        Navigator.of(context).pushAndRemoveUntil(
//          FadeRoute(page: SetlocationPage()), (Route<dynamic> route) => false);
//      }
//    }else{
//      Navigator.of(context).pushAndRemoveUntil(
//          FadeRoute(page: LoginPage()), (Route<dynamic> route) => false);
//    }
//    });
//  }

  @override
  void initState(){
    super.initState();
    checkForUpdate();
//    _messaging.getToken().then((token){
//    });
//    checkUser();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: SafeArea(
        child: Container(
          height: MediaQuery.of(context).size.height,
          child: new Center(
            child: new Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
//                new Hero(
//                  tag: 'logo',
//                  child: Container(
//                    // height: 220,
//                    child: Align(
//                      alignment: Alignment.center,
//                      child: Container(
//                        width: 80,
//                        height: 80,
//                        child: Center(
////                          child: Image(
////                            image: AssetImage("assets/image/logo.png"),
////                          ),
//                        ),
//                      ),
//                    ),
//                  ),
//                ),
                new Container(
                  padding: EdgeInsets.only(top: 20),
                  child: new Center(
                    child: new Text(
                      "Why to vist, We will visit",
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          fontFamily: "opensan"
                      ),
                    ),
                  ),
                ),
                new Container(
                  padding: EdgeInsets.only(top: 5, bottom: 20),
                  width: 200,
                  child: new Center(
                    child: new Text(
                      "Fast & accurate service",
                      style: TextStyle(
                          fontSize: 18,
                          // fontWeight: FontWeight.bold,
                          fontFamily: "opensan"
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                new Container(
                  padding: EdgeInsets.only(left: 20, right: 20),
                  child: new Container(
                    height: 50,
                    decoration: BoxDecoration(
                        border:
                        Border.all(color: Colors.black.withOpacity(0.2)),
                        color: Colors.white.withOpacity(0.8),
                        borderRadius: BorderRadius.all(Radius.circular(6))),
                    child: new Row(
                      children: <Widget>[
                        Flexible(
                          flex: 3,
                          child: new Container(
//                              color: Colors.black,
                            height: MediaQuery.of(context).size.height,
                            width: 70,
                            decoration: BoxDecoration(
                                border: Border(
                                    right: BorderSide(
                                        width: 1,
                                        color:
                                        Colors.black.withOpacity(0.2)))),
                            child: Center(
                                child: SizedBox(
                                  height: 20,
                                  child: Image.asset('icons/flags/png/in.png', package: 'country_icons'),
                                )
                            ),
                          ),
                        ),
                        Flexible(
                          flex: 2,
                          child: new TextField(
                            keyboardType: TextInputType.number,
//                              controller: mobile,
                            decoration: InputDecoration(
                                hintText: "Mobile Number",
                                border: InputBorder.none,
                                contentPadding: EdgeInsets.only(left: 10),
                                hintStyle: TextStyle(
                                    fontFamily: "opensan",
                                    fontWeight: FontWeight.w400
                                )
                            ),
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontFamily: "opensan",
                                fontWeight: FontWeight.bold
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                new Container(
                  padding: EdgeInsets.only(left: 20, right: 20, top: 20),
                  child: new SizedBox(
                    width: MediaQuery.of(context).size.width,
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Material(
                        color: Color.fromRGBO(19, 211, 252, 1),
                        animationDuration: Duration(seconds: 1),
                        borderRadius: BorderRadius.all(Radius.circular(6)),
                        child: InkWell(
                          onTap: () {
                            // getLogin();
//                              Navigator.of(context).pushAndRemoveUntil(FadeRoute(page: MainpagePage(pageview:0)), (Route<dynamic> route) => false);
                          },
                          borderRadius: BorderRadius.all(Radius.circular(6)),
                          child: Padding(
                            padding: EdgeInsets.only(
                                top: 15, bottom: 15, left: 50, right: 50),
                            child: Text(
                              "Login / Sign up",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                  fontFamily: "opensan"
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
