class Vendorcart{
  int service_id;
  int category_id;
  int vendor_id;
  int subcat_id;
  String service_name;
  String type;
  int mrp;
  int price;
  int qty;

  Vendorcart(this.service_id,this.category_id,this.vendor_id,this.subcat_id,this.service_name,this.type,this.mrp,this.price,this.qty);

  Map<String, dynamic> toMap(){
    var map = <String, dynamic>{
      'service_id':service_id,
      'category_id':category_id,
      'vendor_id':vendor_id,
      'subcat_id':subcat_id,
      'service_name':service_name,
      'type' : type,
      'mrp':mrp,
      'price':price,
      'qty':qty
    };
    return map;
  }

  Vendorcart.fromMap(Map<String, dynamic> map){
    service_id = map['service_id'];
    category_id = map['category_id'];
    vendor_id = map['vendor_id'];
    subcat_id = map['subcat_id'];
    service_name = map['service_name'];
    type = map['type'];
    mrp = map['mrp'];
    price = map['price'];
    qty = map['qty'];
  }




}