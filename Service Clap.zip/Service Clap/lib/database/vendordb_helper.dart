import 'dart:async';
import 'dart:convert';
import 'dart:io' as io;
import 'package:flutter/material.dart';
import 'package:path/path.dart';
import 'package:service_app/database/vendorcart.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';
//import 'package:service_app/Utils/AppColors.dart';

class VendorDbHelper{
  static Database _db;
  static const SERVICE_ID = "service_id";
  static const CATEGORY_ID = "category_id";
  static const VENDOR_ID = "vendor_id";
  static const SUBCAT_ID = "subcat_id";
  static const SERVICE_NAME = "service_name";
  static const TYPE = "type";
  static const MRP = "mrp";
  static const PRICE = "price";
  static const QTY = "qty";
  static const TABLE_NAME = "cart";
  static const DB_NAME = "cart.db";


  Future<Database> get db async{
    if(_db != null){
      return _db;
    }
    _db = await initDb();
    return _db;
  }

  initDb() async{
    io.Directory documentDiretory = await getApplicationDocumentsDirectory();
    String path = join(documentDiretory.path, DB_NAME);
    var db = await openDatabase(path, version: 1, onCreate: _onCreate);
    return db;
  }

  _onCreate(Database db, int version) async{
    String sql = "CREATE TABLE $TABLE_NAME "
        "($SERVICE_ID INTEGER,$CATEGORY_ID INTEGER, $VENDOR_ID INTEGER, $SUBCAT_ID INTEGER, $SERVICE_NAME TEXT, $TYPE TEXT, $MRP INTEGER, $PRICE INTEGER ,$QTY INTEGER)";
    await db.execute(sql);
  }

  Future<Vendorcart> save(Vendorcart cart) async{
    print(cart);
    var dbClient = await db;
    cart.vendor_id = await dbClient.insert(TABLE_NAME, cart.toMap());
    print(cart.service_name);
    return cart;
  }


  Future<List<Vendorcart>> getCart(int catid) async{
    var dbClient = await db;
    List<Map> map = await dbClient.rawQuery("SELECT * FROM $TABLE_NAME WHERE $VENDOR_ID = $catid");
//    print(map.length);
    List<Vendorcart> cart = [];
    if(map.length > 0){
//      print(map.length);
      for(int i = 0; i < map.length; i++){
        cart.add(Vendorcart.fromMap(map[i]));
      }
    }
    print(cart.length);
    return cart;
  }

  getProduct(int serviceid) async{
    print(serviceid);
    var dbClient = await db;
    List<Map> map = await dbClient.rawQuery("SELECT $QTY FROM $TABLE_NAME WHERE $SERVICE_ID = $serviceid");
//    print("data get: "+map[0]['qty'].toString());
    List<Vendorcart> cart  = [];
    if(map.length > 0){
      cart.add(Vendorcart.fromMap(map[0]));
      print(cart);
      return cart;
    }else{
      return "0";
    }
  }

  Future<int> delete(int id) async{
    var dbClient = await db;
    return await dbClient.delete(TABLE_NAME, where: '$SERVICE_ID = ?',whereArgs: [id]);
  }

  Future<int> update(Vendorcart cart) async{
    var dbClient = await db;
    return await dbClient.update(TABLE_NAME, cart.toMap(), where: '$SERVICE_ID = ?', whereArgs: [cart.service_id]);
  }


  Future closedb() async{
    var dbClient = await db;
    dbClient.close();
  }

  Future<List<Vendorcart>> getCartval(int vendorid) async{
    var dbClient = await db;
    List<Map> map = await dbClient.rawQuery("SELECT * FROM $TABLE_NAME  where $VENDOR_ID = $vendorid");
//    print(map.length);
    List<Vendorcart> cart = [];
    if(map.length > 0){
//      print(map.length);
      for(int i = 0; i < map.length; i++){
        cart.add(Vendorcart.fromMap(map[i]));
      }
    }
    return cart;
  }

  Future<List> getCartvalList(int vendorid) async{
    print(vendorid);
    var dbClient = await db;
    var map = await dbClient.rawQuery("SELECT * FROM $TABLE_NAME  where $VENDOR_ID = $vendorid");

    return map;
  }


  Future getPrice(int vendorid) async{
    var dbClient = await db;
    List<Map> map = await dbClient.rawQuery("SELECT SUM($MRP * $QTY) AS Price , SUM($PRICE * $QTY) AS discount_price FROM $TABLE_NAME where $VENDOR_ID = $vendorid");
//    print(map[0]);
//    List<Cart> cart  = [];
    if(map.length > 0){
//      cart.add(Cart.fromMap(map[0]));
//      print(map[0].toString());
      return map;
    }else{
      return "0";
    }
  }


//  Future<List<Vendorcart>> getCart() async{
//    var dbClient = await db;
//    List<Map> map = await dbClient.rawQuery("SELECT * FROM $TABLE_NAME");
////    print(map.length);
//    List<Vendorcart> cart = [];
//    if(map.length > 0){
////      print(map.length);
//      for(int i = 0; i < map.length; i++){
//        cart.add(Vendorcart.fromMap(map[i]));
//      }
//    }
//    return cart;
//  }

  Future<int> deleteAll(int vendorid) async{
    var dbClient = await db;
    return await dbClient.delete(TABLE_NAME, where: '$VENDOR_ID = ?',whereArgs: [vendorid]);
  }

}