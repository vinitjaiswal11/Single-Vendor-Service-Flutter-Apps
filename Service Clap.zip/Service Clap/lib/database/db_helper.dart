import 'dart:async';
import 'dart:convert';
import 'dart:io' as io;
import 'package:flutter/material.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';
import 'package:service_app/database/cart.dart';
//import 'package:service_app/Utils/AppColors.dart';

class DBHelper{
  static Database _db;
//  static const String ID = 'id';
  static const String PRODUCT_ID = 'product_id';
  static const String VARIENT_ID = 'varient_id';
  static const String PRODUCT_NAME = 'product_name';
  static const String PRODUCT_IMAGE = 'product_image';
  static const String PRODUCT_PRICE = 'product_price';
  static const String MRP = 'mrp';
  static const String DISCOUNT_PERCENT = 'discount_percent';
  static const String QTY = 'qty';
  static const String UNIT = 'unit';
  static const String UNIT_NAME = 'unit_name';
  static const String TABLE_NAME = 'cart';
  static const String DB_NAME = 'cart.db';


  Future<Database> get db async{
    if(_db != null){
      return _db;
    }
    _db = await initDb();
    return _db;
  }

  initDb() async{
    io.Directory documentDiretory = await getApplicationDocumentsDirectory();
    String path = join(documentDiretory.path, DB_NAME);
    var db = await openDatabase(path, version: 1, onCreate: _onCreate);
    return db;
  }

  _onCreate(Database db, int version) async{
    String sql = "CREATE TABLE $TABLE_NAME "
        "($PRODUCT_ID INTEGER, $PRODUCT_NAME TEXT, $VARIENT_ID INTEGER, $PRODUCT_IMAGE TEXT, $PRODUCT_PRICE INTEGER, $MRP INTEGER ,$DISCOUNT_PERCENT INTEGER ,$QTY INTEGER, $UNIT INTEGER, $UNIT_NAME TEXT)";
    await db.execute(sql);

  }

  Future<Cart> save(Cart cart) async{
    var dbClient = await db;
    cart.product_id = await dbClient.insert(TABLE_NAME, cart.toMap());
    print(cart.product_name);
    return cart;
  }

  Future<List<Cart>> getCart() async{
    var dbClient = await db;
    List<Map> map = await dbClient.rawQuery("SELECT * FROM $TABLE_NAME");
//    print(map.length);
    List<Cart> cart = [];
    if(map.length > 0){
//      print(map.length);
      for(int i = 0; i < map.length; i++){
        cart.add(Cart.fromMap(map[i]));
      }
    }
    return cart;
  }

  getProduct(int varientid) async{
    var dbClient = await db;
    List<Map> map = await dbClient.rawQuery("SELECT $QTY FROM $TABLE_NAME WHERE $VARIENT_ID = $varientid");
//    print("data get: "+map[0]['qty'].toString());
    List<Cart> cart  = [];
    if(map.length > 0){
      cart.add(Cart.fromMap(map[0]));
      print(cart);
      return cart;
    }else{
      return "0";
    }

  }

  Future<int> delete(int id) async{
    var dbClient = await db;
    return await dbClient.delete(TABLE_NAME, where: '$VARIENT_ID = ?',whereArgs: [id]);
  }

  Future<int> update(Cart cart) async{
    var dbClient = await db;
    return await dbClient.update(TABLE_NAME, cart.toMap(), where: '$VARIENT_ID = ?', whereArgs: [cart.varient_id]);
  }

  Future closedb() async{
    var dbClient = await db;
    dbClient.close();
  }

  Future getPrice() async{
    var dbClient = await db;
    List<Map> map = await dbClient.rawQuery("SELECT SUM($MRP * $QTY) AS Price , SUM($PRODUCT_PRICE * $QTY) AS discount_price FROM $TABLE_NAME");
//    print(map[0]);
//    List<Cart> cart  = [];
    if(map.length > 0){
//      cart.add(Cart.fromMap(map[0]));
      print(map[0].toString());
      return map;
    }else{
      return "0";
    }
  }

}