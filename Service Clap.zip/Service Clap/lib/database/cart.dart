class Cart{
  int product_id;
  int varient_id;
  String product_name;
  String product_image;
  int product_price;
  int mrp;
  int discount_percent;
  int qty;
  int unit;
  String unit_name;

  Cart(this.product_id,this.varient_id,this.product_name,this.product_image,this.product_price,this.mrp,this.discount_percent,this.qty,this.unit,this.unit_name);

  Map<String, dynamic> toMap(){
    var map = <String, dynamic>{
      'product_id': product_id,
      'varient_id' : varient_id,
      'product_name': product_name,
      'product_image' : product_image,
      'product_price': product_price,
      'mrp' : mrp,
      'discount_percent' : discount_percent,
      'qty': qty,
      'unit': unit,
      'unit_name': unit_name
    };
    return map;
  }

  Cart.fromMap(Map<String,dynamic> map){
    product_id = map['product_id'];
    varient_id = map['varient_id'];
    product_name = map['product_name'];
    product_image = map['product_image'];
    product_price = map['product_price'];
    mrp = map['mrp'];
    discount_percent = map['discount_percent'];
    qty = map['qty'];
    unit = map['unit'];
    unit_name = map['unit_name'];
  }

}